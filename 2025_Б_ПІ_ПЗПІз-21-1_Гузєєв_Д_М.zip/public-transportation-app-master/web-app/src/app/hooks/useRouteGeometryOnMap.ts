import { Route } from "@/types";
import { Feature, Map } from "ol";
import { LineString } from "ol/geom";
import VectorLayer from "ol/layer/Vector";
import { fromLonLat } from "ol/proj";
import VectorSource from "ol/source/Vector";
import Stroke from "ol/style/Stroke";
import Style from "ol/style/Style";
import { useEffect } from "react";
import {
  ROUTE_COLOR_ON_MAP,
  ROUTE_WIDTH_ON_MAP,
  ROUTE_Z_INDEX_ON_MAP,
} from "../constants";
import { useRouteGeometry } from "./useRouteGeometry";
import { focusRouteOnMap } from "../helpers";

export const useRouteGeometryOnMap = (route: Route | null, map: Map | null) => {
  const { data: geometry } = useRouteGeometry(route);

  useEffect(() => {
    if (!map) {
      return;
    }

    const existingRouteLayer = map
      .getLayers()
      .getArray()
      .find((layer) => layer.get("name") === "routeLayer");

    if (existingRouteLayer) {
      map.removeLayer(existingRouteLayer);
    }

    if (
      !geometry ||
      !geometry.coordinates ||
      geometry.coordinates.length === 0
    ) {
      return;
    }

    const routeCoordinates = geometry?.coordinates?.map((coord) =>
      fromLonLat(coord)
    );

    if (!routeCoordinates) {
      console.error("No route coordinates available");
      return;
    }

    const routeFeature = new Feature({
      geometry: new LineString(routeCoordinates),
    });

    const routeStyle = new Style({
      stroke: new Stroke({
        color: ROUTE_COLOR_ON_MAP,
        width: ROUTE_WIDTH_ON_MAP,
      }),
    });

    const routeSource = new VectorSource({
      features: [routeFeature],
    });

    const routeLayer = new VectorLayer({
      source: routeSource,
      style: routeStyle,
      zIndex: ROUTE_Z_INDEX_ON_MAP,
    });

    routeLayer.set("name", "routeLayer");

    map.addLayer(routeLayer);

    focusRouteOnMap(routeFeature, map);
  }, [geometry, map]);
};
