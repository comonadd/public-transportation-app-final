import { Map, View } from "ol";
import { Feature } from "ol";
import { Point } from "ol/geom";
import { Vector as VectorLayer } from "ol/layer";
import { Vector, Vector as VectorSource } from "ol/source";
import { Style, Circle as CircleStyle, Fill, Stroke, Icon } from "ol/style";
import { useEffect, useRef, useState } from "react";
import { Route, TooltipState } from "@/types";
import { fromLonLat } from "ol/proj";
import { useVehicleWebSocket } from "./useVehicleUpdatesWebsocket";
import { VEHICLE_Z_INDEX_ON_MAP } from "../constants";
import busLive from "../bus-live.svg";
import { pointerMove } from "ol/events/condition";
import { Select } from "ol/interaction";
import { findAndRemoveLayer } from "../helpers";

const UPDATE_INTERVAL_MS = 1000;
const LAYER_NAME = "vehicleUpdatesLayer";

export const useVehicleUpdatesOnMapForRoute = (
  route: Route | null,
  map: Map | null
) => {
  const vehicleUpdates = useVehicleWebSocket(route?.route_id ?? null);
  const layerRef = useRef<VectorLayer<any>>(null);
  const sourceRef = useRef<VectorSource<Feature> | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const [tooltip, setTooltip] = useState<TooltipState | null>(null);
  const hoverInteractionRef = useRef<Select | null>(null);

  useEffect(() => {
    if (!map || !route) return;

    const source = new VectorSource();

    const busStyle = [
      new Style({
        image: new Icon({
          src: busLive.src,
          scale: 0.15,
          anchor: [0.5, 0.5],
        }),
      }),
    ];

    const layer = new VectorLayer({
      source,
      style: busStyle,
      zIndex: VEHICLE_Z_INDEX_ON_MAP,
    });

    layer.set("name", LAYER_NAME);
    findAndRemoveLayer(map, LAYER_NAME);

    const hover = new Select({
      condition: pointerMove,
      layers: [layer],
      style: null,
    });

    hover.on("select", (e) => {
      const target = map.getTargetElement();
      if (e.selected.length > 0) {
        const feature = e.selected[0];
        const busName = feature.get("name");
        const pixel = map.getEventPixel(e.mapBrowserEvent.originalEvent);
        target.style.cursor = "pointer";
        setTooltip({ content: busName, x: pixel[0], y: pixel[1] });
      } else {
        target.style.cursor = "";
        setTooltip(null);
      }
    });

    map.addInteraction(hover);
    hoverInteractionRef.current = hover;

    map.addLayer(layer);
    layerRef.current = layer;
    sourceRef.current = source;

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (layerRef.current) {
        map.removeLayer(layerRef.current);
      }
      if (hoverInteractionRef.current) {
        map.removeInteraction(hoverInteractionRef.current);
        hoverInteractionRef.current = null;
      }
      layerRef.current = null;
      sourceRef.current = null;
    };
  }, [route, map]);

  useEffect(() => {
    if (!sourceRef.current || !vehicleUpdates) return;

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    const updateFeatures = () => {
      const source = sourceRef.current;
      if (!source) return;

      const existingFeatures = source.getFeatures();
      const currentIds = new Set(vehicleUpdates.map((v) => v.vehicle_id));

      existingFeatures.forEach((feature) => {
        if (!currentIds.has(feature.getId()!.toString())) {
          source.removeFeature(feature);
        }
      });

      vehicleUpdates.forEach((vehicle) => {
        const existingFeature = source.getFeatureById(vehicle.vehicle_id);
        const newPoint = new Point(
          fromLonLat([vehicle.longitude, vehicle.latitude])
        );

        if (existingFeature) {
          existingFeature.setGeometry(newPoint);
        } else {
          const feature = new Feature({
            name: `Автобус #${vehicle.vehicle_id}.\nОновлено ${new Date(vehicle.timestamp).toLocaleTimeString()}`,
            geometry: newPoint,
          });
          feature.setId(vehicle.vehicle_id);
          source.addFeature(feature);
        }
      });
    };

    // Initial update
    updateFeatures();

    // Set up interval for continuous updates
    intervalRef.current = setInterval(updateFeatures, UPDATE_INTERVAL_MS);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [vehicleUpdates]);

  return { tooltip };
};
