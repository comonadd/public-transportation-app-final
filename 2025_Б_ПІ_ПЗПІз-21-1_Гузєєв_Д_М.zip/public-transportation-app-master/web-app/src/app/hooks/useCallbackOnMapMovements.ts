import { useEffect } from "react";
import { Map } from "ol";

export const useCallbackOnMapMovements = (
  map: Map | null,
  callback: () => void
) => {
  // Update position during ALL map movements
  useEffect(() => {
    if (!map) return;

    // Add event listeners for various map interactions
    map.on("movestart", callback);
    map.on("moveend", callback);
    map.on("pointerdrag", callback);
    map.on("pointermove", callback);

    // For smoother updates during interactions
    const moveHandler = () => {
      window.requestAnimationFrame(callback);
    };

    map.on("postrender", moveHandler);

    // Clean up all listeners when component unmounts
    return () => {
      map.un("movestart", callback);
      map.un("moveend", callback);
      map.un("pointerdrag", callback);
      map.un("pointermove", callback);
      map.un("postrender", moveHandler);
    };
  }, [map, callback]);
};
