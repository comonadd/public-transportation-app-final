"use client";

import { PartialStop } from "@/types";
import { useLocalStorage } from "@uidotdev/usehooks";
import { useCallback } from "react";

interface PathBuilderHistoryItem {
  stopA: PartialStop;
  stopB: PartialStop;
}

interface UsePathBuilderHistoryReturn {
  history: PathBuilderHistoryItem[];
  addItemToHistory: (item: PathBuilderHistoryItem) => void;
  removeItemFromHistory: (item: PathBuilderHistoryItem) => void;
}

const HISTORY_KEY = "pathBuilderHistory";
const MAX_HISTORY_SIZE = 5;

export function usePathBuilderHistory(): UsePathBuilderHistoryReturn {
  const [history, setHistory] = useLocalStorage<PathBuilderHistoryItem[]>(
    HISTORY_KEY,
    []
  );

  const addItemToHistory = useCallback(
    (newItem: PathBuilderHistoryItem) => {
      setHistory((currentHistory) => {
        const existingIndex = currentHistory.findIndex(
          (item) =>
            item.stopA.stop_id === newItem.stopA.stop_id &&
            item.stopB.stop_id === newItem.stopB.stop_id
        );

        let updatedHistory =
          existingIndex !== -1
            ? currentHistory.filter((_, index) => index !== existingIndex)
            : currentHistory;

        updatedHistory = [newItem, ...updatedHistory];

        if (updatedHistory.length > MAX_HISTORY_SIZE) {
          updatedHistory = updatedHistory.slice(0, MAX_HISTORY_SIZE);
        }

        return updatedHistory;
      });
    },
    [setHistory]
  );

  const removeItemFromHistory = useCallback(
    (itemToRemove: PathBuilderHistoryItem) => {
      setHistory((currentHistory) =>
        currentHistory.filter(
          (item) =>
            item.stopA.stop_id !== itemToRemove.stopA.stop_id ||
            item.stopB.stop_id !== itemToRemove.stopB.stop_id
        )
      );
    },
    [setHistory]
  );

  return {
    history,
    addItemToHistory,
    removeItemFromHistory,
  };
}
