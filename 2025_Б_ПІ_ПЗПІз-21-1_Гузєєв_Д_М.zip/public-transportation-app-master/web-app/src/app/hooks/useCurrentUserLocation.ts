import { Coords } from "@/types";

const MOCK_LVIV_COORDS: Coords = {
    lat: 49.8462075,
    lon: 24.0210454,
}

export const useCurrentUserLocation = () => {
    // NOTE: This is a mock for now, we will use the real location when we have it
    return MOCK_LVIV_COORDS
}