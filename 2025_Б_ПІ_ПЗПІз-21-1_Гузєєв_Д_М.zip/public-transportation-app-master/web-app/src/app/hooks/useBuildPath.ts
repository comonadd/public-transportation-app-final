import { useQuery } from "@tanstack/react-query";
import { QUERY_KEYS } from "../queryKeys";
import { API } from "../api";
import { RouteGeometry, Path, PointGeometry, Stop } from "@/types";
import { AxiosResponse } from "axios";

export type StopId = string;

export enum EdgeType {
  WALK = "walking",
  TRANSIT = "transit",
  TRANSFER = "transfer",
}

interface Params {
  pointA: StopId | undefined;
  pointB: StopId | undefined;
}

export interface RoutePart {
  seq: number;
  stop_id: StopId;
  stop: Stop;
  route_id: string | null;
  geometry: RouteGeometry | null;
  approximate_enter_time: string | null;
  approximate_exit_time: string | null;
  duration: number | null;
  distance: number | null;
  stop_geometry: PointGeometry | null;
  route_long_name: string | null;
  edge_type: EdgeType | null;
  instruction: string | null;
}

export interface BuildResponse {
  parts: RoutePart[];
  enter_stop: Stop;
  exit_stop: Stop;
}

export const useBuildPath = ({ pointA, pointB }: Params) => {
  return useQuery({
    queryKey: [QUERY_KEYS.PATH_BUILD, pointA, pointB],
    queryFn: async () => {
      if (!pointA || !pointB) {
        return null;
      }
      const response = await API.get<never, AxiosResponse<BuildResponse>>(
        `build-path?point_a=${pointA}&point_b=${pointB}`
      );
      return response.data;
    },
    enabled: !!pointA && !!pointB,
  });
};
