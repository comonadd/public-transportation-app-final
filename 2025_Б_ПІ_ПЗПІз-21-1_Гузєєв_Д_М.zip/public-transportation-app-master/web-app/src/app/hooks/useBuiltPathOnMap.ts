import { Feature, Map } from "ol";
import { LineString, Point } from "ol/geom";
import VectorLayer from "ol/layer/Vector";
import { fromLonLat } from "ol/proj";
import VectorSource from "ol/source/Vector";
import Stroke from "ol/style/Stroke";
import Style from "ol/style/Style";
import Text from "ol/style/Text";
import Fill from "ol/style/Fill";
import { useEffect } from "react";
import { Path } from "@/types";
import {
  BUILT_PATH_ROUTE_LAYER_NAME,
  BUILT_PATH_STOP_LAYER_NAME,
} from "../constants";
import {
  builtPathColorForPart,
  builtRoutePartFeatureId,
  findAndRemoveLayer,
  focusRouteOnMap,
} from "../helpers";

const BUILT_PATH_LABEL_LAYER_NAME = "built-path-labels";

const buildFeaturesForRouteParts = (
  routeParts: Path["routeParts"]
): [Feature[], Feature[], Feature[]] | null => {
  const routeFeatures: Feature[] = [];
  const stopFeatures: Feature[] = [];
  const labelFeatures: Feature[] = [];

  for (const part of routeParts) {
    if (!part.geometry) {
      continue;
    }
    let partCoordinates = [];
    console.log("got route part with seq:", part.seq);
    if (part?.geometry?.type === "MultiLineString") {
      for (const coordLine of part.geometry.coordinates) {
        const transformedCoords = coordLine.map((coord) =>
          fromLonLat(coord as any)
        );
        partCoordinates.push(...transformedCoords);
      }
    } else {
      partCoordinates = part?.geometry?.coordinates?.map((coord) =>
        fromLonLat(coord)
      );
    }

    if (!partCoordinates) {
      console.error("No route coordinates available");
      continue;
    }

    const routeFeature = new Feature({
      geometry: new LineString(partCoordinates),
    });
    routeFeature.setId(builtRoutePartFeatureId(part));

    if (part.stop_geometry && part.stop_geometry.coordinates) {
      const stopFeature = new Feature({
        geometry: new LineString([fromLonLat(part.stop_geometry.coordinates)]),
      });
      stopFeatures.push(stopFeature);
    }

    const strokeStyle = new Stroke({
      color: builtPathColorForPart(part),
      width: 4,
    });

    const isWalking = part.edge_type === "walking";
    if (isWalking) {
      strokeStyle.setLineDash([8, 8]);
      strokeStyle.setLineDashOffset(0);
    }

    routeFeature.setStyle(
      new Style({
        stroke: strokeStyle,
      })
    );
    routeFeatures.push(routeFeature);

    // Create label feature for route name and sequence
    if (part.route_long_name || part.seq) {
      // Calculate the midpoint of the route segment for label placement
      const lineString = new LineString(partCoordinates);
      const midpoint = lineString.getCoordinateAt(0.5);

      const labelText = [
        part.seq ? `${part.seq}` : "",
        part.route_long_name ?? (part.edge_type === "walking" ? "Пішки" : ""),
      ]
        .filter(Boolean)
        .join(": ");

      if (!labelText) {
        continue;
      }

      const labelFeature = new Feature({
        geometry: new Point(midpoint),
      });

      labelFeature.setStyle(
        new Style({
          text: new Text({
            text: labelText,
            font: "12px Arial, sans-serif",
            fill: new Fill({
              color: "#000000",
            }),
            stroke: new Stroke({
              color: "#ffffff",
              width: 3,
            }),
            offsetY: -15, // Position above the line
            textAlign: "center",
            textBaseline: "bottom",
            backgroundFill: new Fill({
              color: "rgba(255, 255, 255, 0.8)",
            }),
            padding: [2, 4, 2, 4],
          }),
        })
      );

      labelFeatures.push(labelFeature);
    }
  }

  return [routeFeatures, stopFeatures, labelFeatures];
};

export const useBuiltPathOnMap = (path: Path | null, map: Map | null) => {
  const routeParts = path?.routeParts || null;

  useEffect(() => {
    if (!map) {
      return;
    }

    findAndRemoveLayer(map, BUILT_PATH_ROUTE_LAYER_NAME);
    findAndRemoveLayer(map, BUILT_PATH_STOP_LAYER_NAME);
    findAndRemoveLayer(map, BUILT_PATH_LABEL_LAYER_NAME);

    if (!routeParts) {
      return;
    }

    const result = buildFeaturesForRouteParts(routeParts);
    if (!result) {
      return;
    }

    const [routeFeatures, stopFeatures, labelFeatures] = result;

    // Create stop layer
    const stopSource = new VectorSource({
      features: stopFeatures,
    });
    const stopStyle = new Style({
      stroke: new Stroke({
        width: 4,
        color: "#ffffff",
      }),
    });
    const stopLayer = new VectorLayer({
      source: stopSource,
      style: stopStyle,
      zIndex: 10,
    });
    stopLayer.set("name", BUILT_PATH_STOP_LAYER_NAME);
    map.addLayer(stopLayer);

    // Create route layer
    const routeSource = new VectorSource({
      features: routeFeatures,
    });
    const routeStyle = new Style({
      stroke: new Stroke({
        width: 4,
      }),
    });
    const routeLayer = new VectorLayer({
      source: routeSource,
      style: routeStyle,
      zIndex: 1, // Place below the stops layer
    });
    routeLayer.set("name", BUILT_PATH_ROUTE_LAYER_NAME);
    map.addLayer(routeLayer);

    // Create label layer
    if (labelFeatures.length > 0) {
      const labelSource = new VectorSource({
        features: labelFeatures,
      });
      const labelLayer = new VectorLayer({
        source: labelSource,
        zIndex: 15, // Place above everything else
      });
      labelLayer.set("name", BUILT_PATH_LABEL_LAYER_NAME);
      map.addLayer(labelLayer);
    }

    const firstRouteFeature = routeFeatures[0];
    focusRouteOnMap(firstRouteFeature, map);
  }, [routeParts, map]);
};
