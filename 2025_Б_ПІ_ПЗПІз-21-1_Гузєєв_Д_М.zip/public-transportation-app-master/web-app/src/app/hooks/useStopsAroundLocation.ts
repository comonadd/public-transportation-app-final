import { Coords, Stop } from "@/types";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { API } from "../api";
import { QUERY_KEYS } from "../queryKeys";
import { coordsFromGeometryPointType } from "../helpers";
import { AxiosResponse } from "axios";

interface CachedStopsData {
  stops: Stop[];
  centerLat: number;
  centerLon: number;
  radius: number;
  timestamp: number;
}

const CACHE_CONFIG = {
  LOCATION_THRESHOLD: 100,
  CACHE_TTL: 5 * 60 * 1000,
  MAX_CACHE_ENTRIES: 10,
} as const;

function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function isPointInRadius(
  pointLat: number,
  pointLon: number,
  centerLat: number,
  centerLon: number,
  radius: number
): boolean {
  const distance = calculateDistance(pointLat, pointLon, centerLat, centerLon);
  return distance <= radius;
}

function generateCacheKey(lat: number, lon: number, radius: number): string {
  const roundedLat = Math.round(lat * 10000) / 10000;
  const roundedLon = Math.round(lon * 10000) / 10000;
  const roundedRadius = Math.round(radius / 100) * 100;

  return `${QUERY_KEYS.STOPS_CACHE_PREFIX}-${roundedLat}-${roundedLon}-${roundedRadius}`;
}

class StopsLocationCache {
  private queryClient: ReturnType<typeof useQueryClient>;

  constructor(queryClient: ReturnType<typeof useQueryClient>) {
    this.queryClient = queryClient;
  }

  findUsableCache(
    lat: number,
    lon: number,
    radius: number
  ): CachedStopsData | null {
    const now = Date.now();

    const cacheEntries = this.queryClient.getQueriesData({
      queryKey: [QUERY_KEYS.STOPS_CACHE_PREFIX],
    });

    for (const [queryKey, data] of cacheEntries) {
      if (!data || !Array.isArray(queryKey)) continue;

      const cachedData = data as CachedStopsData;

      if (now - cachedData.timestamp > CACHE_CONFIG.CACHE_TTL) {
        continue;
      }

      const distanceFromCache = calculateDistance(
        lat,
        lon,
        cachedData.centerLat,
        cachedData.centerLon
      );

      if (
        distanceFromCache <= CACHE_CONFIG.LOCATION_THRESHOLD &&
        radius <= cachedData.radius
      ) {
        return cachedData;
      }

      if (
        isPointInRadius(
          lat,
          lon,
          cachedData.centerLat,
          cachedData.centerLon,
          cachedData.radius
        ) &&
        radius <= cachedData.radius
      ) {
        return cachedData;
      }
    }

    return null;
  }

  filterStopsForRadius(
    cachedData: CachedStopsData,
    requestLat: number,
    requestLon: number,
    requestRadius: number
  ): Stop[] {
    return cachedData.stops.filter((stop) => {
      const coords = coordsFromGeometryPointType(stop.geometry.coordinates);
      return isPointInRadius(
        coords.lat,
        coords.lon,
        requestLat,
        requestLon,
        requestRadius
      );
    });
  }

  setCachedData(lat: number, lon: number, radius: number, stops: Stop[]): void {
    const cacheKey = generateCacheKey(lat, lon, radius);
    const cachedData: CachedStopsData = {
      stops,
      centerLat: lat,
      centerLon: lon,
      radius,
      timestamp: Date.now(),
    };

    this.queryClient.setQueryData(
      [QUERY_KEYS.STOPS_CACHE_PREFIX, cacheKey],
      cachedData
    );

    this.cleanupCache();
  }

  private cleanupCache(): void {
    const cacheEntries = this.queryClient.getQueriesData({
      queryKey: [QUERY_KEYS.STOPS_CACHE_PREFIX],
    });

    if (cacheEntries.length <= CACHE_CONFIG.MAX_CACHE_ENTRIES) {
      return;
    }

    const sortedEntries = cacheEntries
      .map(([queryKey, data]) => ({
        queryKey,
        timestamp: (data as CachedStopsData)?.timestamp || 0,
      }))
      .sort((a, b) => a.timestamp - b.timestamp);

    const entriesToRemove = sortedEntries.slice(
      0,
      sortedEntries.length - CACHE_CONFIG.MAX_CACHE_ENTRIES
    );

    entriesToRemove.forEach(({ queryKey }) => {
      this.queryClient.removeQueries({ queryKey: queryKey });
    });
  }

  invalidateAll(): void {
    this.queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.STOPS_CACHE_PREFIX],
    });
  }
}

export const useStopsAroundLocation = (
  loc: Coords | null,
  radius: number = 1000
) => {
  const queryClient = useQueryClient();
  const cache = new StopsLocationCache(queryClient);

  return useQuery({
    queryKey: [QUERY_KEYS.STOPS_AROUND_LOCATION, loc?.lat, loc?.lon, radius],
    queryFn: async (): Promise<Stop[]> => {
      if (!loc) {
        throw new Error("Location is not defined");
      }

      const cachedData = cache.findUsableCache(loc.lat, loc.lon, radius);

      if (cachedData) {
        return cache.filterStopsForRadius(cachedData, loc.lat, loc.lon, radius);
      }

      const fetchRadius = Math.max(radius, 1000);
      const result = await API.get<never, AxiosResponse<Stop[]>>(
        `/stops-in-radius?lat=${loc.lat}&lon=${loc.lon}&radius=${fetchRadius}`
      );

      cache.setCachedData(loc.lat, loc.lon, fetchRadius, result.data);

      return cache.filterStopsForRadius(
        {
          stops: result.data,
          centerLat: loc.lat,
          centerLon: loc.lon,
          radius: fetchRadius,
          timestamp: Date.now(),
        },
        loc.lat,
        loc.lon,
        radius
      );
    },
    enabled: Boolean(loc && radius && loc.lat && loc.lon),
    staleTime: CACHE_CONFIG.CACHE_TTL,
    gcTime: CACHE_CONFIG.CACHE_TTL * 2,
  });
};
