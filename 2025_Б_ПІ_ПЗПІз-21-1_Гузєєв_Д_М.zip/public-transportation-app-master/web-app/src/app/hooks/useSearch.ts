import { useQuery } from "@tanstack/react-query";
import { API } from "../api";
import { QUERY_KEYS } from "../queryKeys";
import { Coords, Route, Stop } from "@/types";
import { AxiosResponse } from "axios";

type SearchType = "stop" | "route";

export interface SearchParams {
  query: string;
  type: SearchType | null;
  coords: Coords | null;
}

export interface SearchResult {
  id: string;
  name: string;
  type: string;
  route: Route | null;
  stop: Stop | null;
  distance_to_m?: number | null;
}

export interface SearchResponse {
  items: SearchResult[];
}

const MIN_QUERY_LENGTH = 3;

export const useSearch = (searchParams: SearchParams) => {
  return useQuery<SearchResponse>({
    queryKey: [QUERY_KEYS.SEARCH, searchParams.query],
    queryFn: async () => {
      const items: Record<string, string> = {
        query: searchParams.query,
      };
      if (searchParams.type) {
        items.type = searchParams.type;
      }
      if (searchParams.coords) {
        items.lat = searchParams.coords.lat.toString();
        items.lng = searchParams.coords.lon.toString();
      }
      const queryParams = new URLSearchParams(items);
      const url = `/search?${queryParams.toString()}`;
      const response = await API.get<never, AxiosResponse<SearchResponse>>(url);
      return response.data;
    },
    enabled:
      Boolean(searchParams.query) &&
      searchParams.query.length >= MIN_QUERY_LENGTH,
  });
};
