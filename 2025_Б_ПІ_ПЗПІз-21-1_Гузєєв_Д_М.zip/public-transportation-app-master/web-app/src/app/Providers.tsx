"use client";

import Map from "ol/Map";
import { Route, Stop, Path } from "@/types";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import React from "react";
import { MapContext } from "./mapContext";

export const Providers: React.FC<React.PropsWithChildren> = ({ children }) => {
  const [queryClient] = React.useState(() => new QueryClient());
  const [selectedStop, setSelectedStop] = React.useState<Stop | null>(null);
  const [selectedRoute, setSelectedRoute] = React.useState<Route | null>(null);
  const [pointA, setPointA] = React.useState<Stop | null>(null);
  const [pointB, setPointB] = React.useState<Stop | null>(null);
  const [selectedBuiltPath, setSelectedBuiltPath] = React.useState<Path | null>(
    null
  );
  const [map, setMap] = React.useState<Map | null>(null);
  return (
    <QueryClientProvider client={queryClient}>
      <MapContext.Provider
        value={{
          selectedStop,
          setSelectedStop,
          selectedRoute,
          setSelectedRoute,
          pointA,
          setPointA,
          pointB,
          setPointB,
          selectedBuiltPath,
          setSelectedBuiltPath,
          map,
          setMap,
        }}
      >
        {children}
      </MapContext.Provider>
      <ReactQueryDevtools />
    </QueryClientProvider>
  );
};
