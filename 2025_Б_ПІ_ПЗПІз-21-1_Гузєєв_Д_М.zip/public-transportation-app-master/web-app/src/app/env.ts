export const ENV = {
  API_URL: 'http://localhost:8002',
}