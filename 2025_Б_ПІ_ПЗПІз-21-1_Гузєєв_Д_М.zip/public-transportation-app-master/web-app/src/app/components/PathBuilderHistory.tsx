import React from "react";
import { usePathBuilderHistory } from "../hooks/usePathBuilderHistory";
import DepartureBoardIcon from "@mui/icons-material/DepartureBoard";
import { useMapContext } from "../mapContext";
import CloseIcon from "@mui/icons-material/Close";

export const PathBuilderHistory = () => {
  const { history, removeItemFromHistory } = usePathBuilderHistory();
  const ctx = useMapContext();

  return (
    <div className="flex flex-col w-full h-full p-0">
      <div className="flex-1 overflow-y-auto p-0">
        {history.length > 0 ? (
          <ul className="list-none p-0 m-0">
            {history.map((item, index) => (
              <li
                key={`built-path-${item.stopA}-${item.stopB}-${index}`}
                className="px-0 py-4 hover:bg-gray-50 cursor-pointer flex flex-row items-center justify-between flex-nowrap"
                onClick={() => {
                  ctx.setPointA(item.stopA);
                  ctx.setPointB(item.stopB);
                }}
              >
                <div className="pointer-events-none flex flex-row items-center p-0 gap-0">
                  <div className="px-4 flex items-center justify-center">
                    <DepartureBoardIcon
                      className="inline-block align-middle"
                      style={{ fontSize: "1.2rem" }}
                    />
                  </div>
                  <div>
                    <span className="font-medium">{item.stopA.stop_name}</span>{" "}
                    -{" "}
                    <span className="text-gray-600">
                      {item.stopB.stop_name}
                    </span>
                  </div>
                </div>
                <div className="hover:bg-transparent">
                  <button
                    title="Видалити з історії"
                    className="btn btn-ghost btn-xs p-0 box-content 
               hover:bg-transparent hover:scale-100 hover:border-transparent hover:text-current
               active:bg-transparent active:scale-100 active:border-transparent active:text-current
               focus:bg-transparent focus:scale-100 focus:border-transparent focus:text-current focus:outline-none focus:ring-0
               focus-visible:outline-none focus-visible:ring-0"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      removeItemFromHistory(item);
                    }}
                  >
                    <div className="pointer-events-none">
                      <CloseIcon className="text-gray-500 hover:text-gray-500 active:text-gray-500 focus:text-gray-500" />
                    </div>
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500 p-4">
            Історія побудови маршрутів поки що порожня.
          </p>
        )}
      </div>
    </div>
  );
};
