"use client";

import { useMapContext } from "../mapContext";
import { PathBuilder } from "./PathBuilder";
import { RouteDropdown } from "./RouteDropdown";
import { SearchBar } from "./SearchBar";
import { StopDropdown } from "./StopDropdown";

export const Sidebar = () => {
  const { selectedRoute, selectedStop, pointA, pointB } = useMapContext();

  if (selectedRoute) {
    return <RouteDropdown route={selectedRoute} />;
  }
  if (selectedStop) {
    return <StopDropdown stop={selectedStop} />;
  }

  const buildingPath = Boolean(pointA || pointB);
  if (buildingPath) {
    return <PathBuilder />;
  }

  return <SearchBar />;
};
