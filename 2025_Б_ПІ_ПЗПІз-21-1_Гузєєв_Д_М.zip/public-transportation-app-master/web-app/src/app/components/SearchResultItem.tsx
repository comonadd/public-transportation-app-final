import React from "react";
import { focusOnStop, formatDistanceMeters } from "../helpers";
import { SearchResult } from "../hooks/useSearch";
import { useMapContext } from "../mapContext";
import DirectionsBusIcon from "@mui/icons-material/DirectionsBus";
import ForkRightIcon from "@mui/icons-material/ForkRight";

interface Props {
  result: SearchResult;
  onClick?: (result: SearchResult) => void;
}

export const SearchResultItem: React.FC<Props> = ({
  result,
  onClick: externalOnClick,
}) => {
  const ctx = useMapContext();

  const onClick = (resultItem: SearchResult) => {
    if (externalOnClick) {
      return externalOnClick(resultItem);
    }
    if (resultItem.type === "route") {
      ctx.setSelectedRoute(resultItem.route!);
    } else if (resultItem.type === "stop") {
      ctx.setSelectedStop(resultItem.stop);
      if (!ctx.map || !resultItem.stop) {
        return;
      }
      focusOnStop(resultItem?.stop, ctx.map);
    }
  };

  return (
    <li
      key={result.id}
      className="hover:bg-gray-100 py-2 px-0 cursor-pointer w-full flex flex-row"
      onClick={() => onClick(result)}
    >
      <div className="pointer-events-none px-0 py-0 w-full flex flex-row">
        <div className="flex flex-row items-center px-0 justify-between w-full">
          <div className="flex flex-row flex-1">
            <div className="px-4 flex items-center justify-center">
              {result.type === "stop" ? (
                <DirectionsBusIcon
                  className="inline-block align-middle"
                  style={{ fontSize: "1.2rem" }}
                />
              ) : (
                result.type === "route" && (
                  <ForkRightIcon
                    className="inline-block align-middle"
                    style={{ fontSize: "1.2rem" }}
                  />
                )
              )}
            </div>
            <div className="flex flex-col">
              <span>{result.name}</span>
              {result.type === "stop" && (
                <span className="text-gray-400 text-sm">
                  {result.stop?.stop_desc}
                </span>
              )}
            </div>
          </div>
          {result.distance_to_m && (
            <div className="text-gray-400 text-sm flex items-center px-4">
              {formatDistanceMeters(result.distance_to_m)}
            </div>
          )}
        </div>
      </div>
    </li>
  );
};
