import { useRenderStopsOnMap } from "../hooks/useRenderStopsOnMap";
import { useStopsAroundLocation } from "../hooks/useStopsAroundLocation";
import { useMapContext } from "../mapContext";
import { MapTooltip } from "./MapTooltip";
import { useMapCenter } from "../hooks/useMapCenter";

export const StopsOnMap = () => {
  const ctx = useMapContext();
  const { selectedStop, setSelectedStop, selectedBuiltPath } = ctx;
  const mapCenter = useMapCenter();
  const { data: stopsAround } = useStopsAroundLocation(mapCenter, 10000);
  const { tooltip } = useRenderStopsOnMap(
    ctx.map,
    stopsAround,
    selectedStop,
    setSelectedStop,
    selectedBuiltPath
  );
  if (!tooltip) {
    return null;
  }
  return <MapTooltip {...tooltip} />;
};
