import { Route } from "@/types";
import { useRouteDetails } from "../hooks/useRouteDetails";
import { useMapContext } from "../mapContext";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import CloseIcon from "@mui/icons-material/Close";
import { focusOnStop } from "../helpers";

export const RouteDropdown: React.FC<{ route: Route }> = ({ route }) => {
  const mapContext = useMapContext();
  const { data: routeDetails } = useRouteDetails(route?.route_id);
  const prevScreenIsStop = mapContext.selectedStop !== null;
  return (
    <div className="card bg-base-100 shadow-md flex flex-col">
      <div className="card-header flex items-center justify-between p-4 flex-row">
        <div>
          <h5 className="text-grey text-sm mb-1">Маршрут</h5>
          <h2 className="card-title p-0">{route?.route_long_name}</h2>
        </div>
        {prevScreenIsStop ? (
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => {
              mapContext?.setSelectedRoute(null);
              if (!mapContext?.map || !mapContext?.selectedStop) {
                return;
              }
              focusOnStop(mapContext?.selectedStop, mapContext?.map);
            }}
            title="Назад до зупинки"
          >
            <ArrowBackIcon />
          </button>
        ) : (
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => {
              mapContext?.setSelectedStop(null);
              mapContext?.setSelectedRoute(null);
            }}
            title="Закрити"
          >
            <CloseIcon />
          </button>
        )}
      </div>
      <div className="card-body w-full py-0 px-0">
        <div className="list bg-base-100 rounded-box w-full px-4 pb-4">
          <div className="mb-2">
            <span className="font-bold mr-1">Початок:</span>
            <span>{routeDetails?.start_stop?.stop_desc}</span>
          </div>
          <div>
            <span className="font-bold mr-1">Кінець:</span>
            <span>{routeDetails?.end_stop?.stop_desc}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
