"use client";

import { useEffect, useState } from "react";
import { SearchResult, useSearch } from "../hooks/useSearch";
import { useMapContext } from "../mapContext";
import { useBuildPath } from "../hooks/useBuildPath";
import { PathDetails } from "./PathDetails";
import { CloseButton } from "./CloseButton";
import { usePathBuilderHistory } from "../hooks/usePathBuilderHistory";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { SearchResultItem } from "./SearchResultItem";

type InputType = "pointA" | "pointB";

export const PathBuilder = () => {
  const ctx = useMapContext();
  const { pointA, pointB, setPointA, setPointB } = ctx;
  const [focusedInput, setFocusedInput] = useState<InputType | null>(null);
  const [inputValues, setInputValues] = useState<Record<InputType, string>>({
    pointA: "",
    pointB: "",
  });
  const { data: buildResult } = useBuildPath({
    pointA: pointA?.stop_id,
    pointB: pointB?.stop_id,
  });

  const shouldSearch =
    focusedInput &&
    ((focusedInput === "pointA" && !pointA && inputValues.pointA) ||
      (focusedInput === "pointB" && !pointB && inputValues.pointB));

  const query = shouldSearch ? inputValues[focusedInput] : "";

  const { addItemToHistory } = usePathBuilderHistory();

  useEffect(() => {
    if (buildResult) {
      ctx.setSelectedRoute(null);
      ctx.setSelectedStop(null);
      ctx.setSelectedBuiltPath({
        routeParts: buildResult.parts,
        enter_stop: buildResult.enter_stop,
        exit_stop: buildResult.exit_stop,
      });
      addItemToHistory({
        stopA: buildResult.enter_stop,
        stopB: buildResult.exit_stop,
      });
    } else {
      ctx.setSelectedBuiltPath(null);
    }
  }, [buildResult]);

  const { data: searchResults } = useSearch({
    query: shouldSearch ? query : "",
    type: "stop",
    coords: null,
  });

  const handleInputFocus = (inputType: InputType) => {
    setFocusedInput(inputType);
  };

  const handleInputBlur = () => {
    setTimeout(() => setFocusedInput(null), 150);
  };

  const handleInputChange = (inputType: InputType, value: string) => {
    setInputValues((prev) => ({
      ...prev,
      [inputType]: value,
    }));

    // If user changes input and there's a selected stop, deselect it
    if (inputType === "pointA" && pointA) {
      setPointA(null);
    } else if (inputType === "pointB" && pointB) {
      setPointB(null);
    }
  };

  const handleStopSelect = (result: SearchResult) => {
    if (focusedInput === "pointA") {
      setPointA(result.stop);
      setInputValues((prev) => ({ ...prev, pointA: "" }));
    } else if (focusedInput === "pointB") {
      setPointB(result.stop);
      setInputValues((prev) => ({ ...prev, pointB: "" }));
    }
    setFocusedInput(null);
  };

  const getInputValue = (inputType: InputType) => {
    if (inputType === "pointA") {
      return pointA ? pointA.stop_name : inputValues.pointA;
    } else {
      return pointB ? pointB.stop_name : inputValues.pointB;
    }
  };

  const isInputReadOnly = (inputType: InputType) => {
    if (focusedInput === inputType) {
      return false;
    }
    return inputType === "pointA" ? !!pointA : !!pointB;
  };
  const searchItemsAmount = searchResults?.items.length || 0;
  const showDropdown = shouldSearch && searchItemsAmount > 0;

  return (
    <div className="bg-white rounded shadow dropdown p-0">
      <CloseButton
        onClick={() => {
          setPointA(null);
          setPointB(null);
          setInputValues({ pointA: "", pointB: "" });
          ctx.setSelectedBuiltPath(null);
        }}
      />

      <div className="px-4 pt-4">
        <h2 className="text-lg font-bold mb-1">Побудувати маршрут</h2>
        <h5 className="text-sm text-gray">
          Вкажіть зупинки, між якими потрібно побудувати маршрут
        </h5>
      </div>
      <div className="flex gap-4 pb-4 align-center justify-center flex-row">
        <div className="mt-4 px-4 flex flex-row gap-4">
          <input
            type="text"
            value={getInputValue("pointA")}
            onChange={(e) => handleInputChange("pointA", e.target.value)}
            onFocus={() => handleInputFocus("pointA")}
            onBlur={handleInputBlur}
            readOnly={isInputReadOnly("pointA")}
            className={`input border p-2 rounded w-full ${
              isInputReadOnly("pointA") ? "cursor-pointer bg-gray-50" : ""
            }`}
            placeholder="Початок"
          />
          <div className="flex flex-row wrap-none flex flex-row align-center items-center justify-center">
            <ArrowForwardIcon
              className="text-gray-500"
              style={{ fontSize: "1.5rem" }}
            />
          </div>
          <input
            type="text"
            value={getInputValue("pointB")}
            onChange={(e) => handleInputChange("pointB", e.target.value)}
            onFocus={() => handleInputFocus("pointB")}
            onBlur={handleInputBlur}
            readOnly={isInputReadOnly("pointB")}
            className={`input border p-2 rounded w-full ${
              isInputReadOnly("pointB") ? "cursor-pointer bg-gray-50" : ""
            }`}
            placeholder="Кінець"
          />
        </div>
      </div>

      {showDropdown && (
        <ul
          className="bg-base-100 rounded-b-xl z-1 w-full p-2 shadow-sm"
          style={{ maxHeight: "300px", overflowY: "auto" }}
        >
          {searchResults?.items.length === 0 && (
            <li>
              <a className="text-gray-500">Нічого не знайдено</a>
            </li>
          )}
          {searchResults?.items.map((result) => (
            <SearchResultItem
              result={result}
              key={result.id}
              onClick={() => handleStopSelect(result)}
            />
          ))}
        </ul>
      )}
      {ctx.selectedBuiltPath && <PathDetails path={ctx.selectedBuiltPath} />}
    </div>
  );
};
