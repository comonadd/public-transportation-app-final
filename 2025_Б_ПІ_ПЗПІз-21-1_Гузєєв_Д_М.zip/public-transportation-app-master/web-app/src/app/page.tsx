"use client";

import { useIsClient } from "@uidotdev/usehooks";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import { XYZ } from "ol/source";
import { useEffect } from "react";
import { useBuiltPathOnMap } from "./hooks/useBuiltPathOnMap";
import { useLocationZoomForMap } from "./hooks/useLocationZoomForMap";
import { usePointerCursorForAllFeatures } from "./hooks/usePointerCursorForAllFeatures";
import { useRouteGeometry } from "./hooks/useRouteGeometry";
import { useRouteGeometryOnMap } from "./hooks/useRouteGeometryOnMap";
import { useMapContext } from "./mapContext";
import Zoom from "ol/control/Zoom.js";
import { useRenderCurrentUserLocation } from "./hooks/useRenderCurrentUserLocation";
import { StopsOnMap } from "./components/StopsOnMap";
import { useCurrentUserLocation } from "./hooks/useCurrentUserLocation";
import { MovingVehiclesOnMap } from "./components/MovingVehiclesOnMap";
import { Sidebar } from "./components/Sidebar";
import { useInitialStateFromUrl } from "./hooks/useInitialStateFromUrl";
import { useSyncMapStateToUrl } from "./hooks/useSyncMapStateToUrl";

export default function Index() {
  const ctx = useMapContext();
  const { map, setMap } = ctx;

  useEffect(() => {
    const initialMap = new Map({
      target: "map",
      layers: [
        new TileLayer({
          source: new XYZ({
            url: "https://{1-4}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
            attributions: "",
          }),
        }),
      ],
      view: new View({
        center: [0, 0],
        zoom: 2,
      }),
      controls: [
        new Zoom({
          className: "ol-zoom",
          target: undefined,
        }),
      ],
    });
    setMap(initialMap);
  }, []);

  const location = useCurrentUserLocation();
  useLocationZoomForMap(map, location);
  useRouteGeometryOnMap(ctx?.selectedRoute, map);
  useBuiltPathOnMap(ctx.selectedBuiltPath, map);
  usePointerCursorForAllFeatures(map);
  useRenderCurrentUserLocation(map, location);
  useInitialStateFromUrl();
  useSyncMapStateToUrl();

  const isClient = useIsClient();

  return (
    <div className="w-screen h-screen">
      {isClient && (
        <div
          className="absolute"
          style={{ zIndex: 1000, marginLeft: 20, marginTop: 20, width: 420 }}
        >
          <Sidebar />
        </div>
      )}
      <div id="map" style={{ width: "100%", height: "100%" }} />
      {isClient && <StopsOnMap />}
      {isClient && <MovingVehiclesOnMap />}
    </div>
  );
}
