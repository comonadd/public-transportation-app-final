import structlog
from sqladmin import Admin

logger = structlog.get_logger(__name__)


def setup_admin_for_app(app, engine):
    admin = Admin(app, engine, templates_dir="./app/admin_templates")