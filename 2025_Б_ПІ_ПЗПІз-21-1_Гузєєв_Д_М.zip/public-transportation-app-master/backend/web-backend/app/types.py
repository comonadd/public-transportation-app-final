from typing import NewType

StopId = NewType("StopId", str)