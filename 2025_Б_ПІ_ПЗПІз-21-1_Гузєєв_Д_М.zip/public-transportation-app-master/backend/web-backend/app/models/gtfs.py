import datetime
from typing import List, Optional, Any

from geoalchemy2 import Geometry, WKBElement
from geoalchemy2.shape import to_shape
from pydantic import field_serializer, BaseModel
from shapely.geometry.geo import mapping # type: ignore
from sqlalchemy import Column, Time
from sqlmodel import Field, Relationship, SQLModel

class LineStringGeometry(BaseModel):
    type: str
    coordinates: list[list[float]]

class MultiLineGeometry(BaseModel):
    type: str
    coordinates: Any

class PointGeometry(BaseModel):
    type: str
    coordinates: list[float]

def serialize_line_string_geometry(geometry: WKBElement | None) -> Optional[LineStringGeometry | MultiLineGeometry]:
    if geometry is None:
        return None
    shapely_geom = to_shape(geometry)
    geojson = mapping(shapely_geom)
    if geojson['type'] == 'LineString':
        return LineStringGeometry(type="LineString", coordinates=geojson["coordinates"])
    if geojson['type'] == 'MultiLineString':
        return MultiLineGeometry(type="MultiLineString", coordinates=geojson["coordinates"])
    raise ValueError("Geometry is not a LineString or MultiLineString")


def serialize_point_geometry(geometry: WKBElement | None) -> Optional[PointGeometry]:
    if geometry is None:
        return None
    shape = to_shape(geometry)
    geojson = mapping(shape)
    return PointGeometry(type="Point", coordinates=geojson["coordinates"])

class Shape(SQLModel, table=True):
    __tablename__ = "shapes"

    shape_id: str = Field(primary_key=True)
    geometry: object = Field(sa_column=Column(Geometry(geometry_type="LINESTRING", srid=4326), nullable=False))


class Agency(SQLModel, table=True):
    __tablename__ = "agencies"

    agency_id: str = Field(primary_key=True)
    agency_name: str
    agency_url: str
    agency_timezone: str
    agency_lang: Optional[str] = None
    agency_phone: Optional[str] = None
    agency_fare_url: Optional[str] = None


class Stop(SQLModel, table=True):
    __tablename__ = "stops"

    stop_id: str = Field(primary_key=True)
    stop_code: Optional[str] = None
    stop_name: str
    stop_desc: Optional[str] = None
    zone_id: Optional[str] = None
    stop_url: Optional[str] = None
    location_type: Optional[int] = None
    parent_station: Optional[str] = None
    stop_timezone: Optional[str] = None
    wheelchair_boarding: Optional[int] = None
    geometry: object = Field(sa_column=Column(Geometry(geometry_type="POINT", srid=4326), nullable=False))
    stop_times: List["StopTime"] = Relationship(back_populates="stop")

    @field_serializer("geometry")
    def serialize_geometry(self, geometry: WKBElement, _info):
        return serialize_point_geometry(geometry)


class Route(SQLModel, table=True):
    __tablename__ = "routes"

    route_id: str = Field(primary_key=True)
    route_short_name: Optional[str] = None
    route_long_name: Optional[str] = None
    route_desc: Optional[str] = None
    route_type: int
    route_url: Optional[str] = None
    route_color: Optional[str] = None
    route_text_color: Optional[str] = None
    route_sort_order: Optional[int] = None
    geometry: object = Field(sa_column=Column(Geometry(geometry_type="LINESTRING", srid=4326), nullable=False))

    trips: List["Trip"] = Relationship(back_populates="route")

    @field_serializer("geometry")
    def serialize_geometry(self, geometry: WKBElement, _info):
        return serialize_line_string_geometry(geometry)


class Trip(SQLModel, table=True):
    __tablename__ = "trips"

    trip_id: str = Field(primary_key=True)
    route_id: str = Field(foreign_key="routes.route_id")
    service_id: str
    trip_headsign: Optional[str] = None
    trip_short_name: Optional[str] = None
    direction_id: Optional[int] = None
    block_id: Optional[str] = None
    wheelchair_accessible: Optional[int] = None
    bikes_allowed: Optional[int] = None
    geometry: object = Field(sa_column=Column(Geometry(geometry_type="LINESTRING", srid=4326), nullable=False))

    route: "Route" = Relationship(back_populates="trips")
    stop_times: List["StopTime"] = Relationship(back_populates="trip")


class StopTime(SQLModel, table=True):
    __tablename__ = "stop_times"

    trip_id: str = Field(foreign_key="trips.trip_id", primary_key=True)
    arrival_time: Optional[datetime.time] = None
    departure_time: Optional[datetime.time] = None
    stop_id: str = Field(foreign_key="stops.stop_id", primary_key=True)
    stop_sequence: int
    stop_headsign: Optional[str] = None
    pickup_type: Optional[int] = None
    drop_off_type: Optional[int] = None
    shape_dist_traveled: Optional[float] = None
    timepoint: Optional[int] = None

    trip: "Trip" = Relationship(back_populates="stop_times")
    stop: "Stop" = Relationship(back_populates="stop_times")
