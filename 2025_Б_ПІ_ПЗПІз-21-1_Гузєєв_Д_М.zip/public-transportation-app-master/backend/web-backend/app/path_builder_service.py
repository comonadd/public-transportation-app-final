import datetime
from typing import List

from geoalchemy2 import WKBElement
from pydantic import BaseModel
from sqlalchemy import text
from sqlmodel import Session, select

from app.models import Stop
from app.models.gtfs import serialize_line_string_geometry, LineStringGeometry, PointGeometry, serialize_point_geometry, \
    MultiLineGeometry
from app.types import StopId


class RoutePart(BaseModel):
    seq: int
    route_id: str | None
    stop_id: StopId | None
    stop_name: str | None
    route_long_name: str | None
    distance: float | None

    edge_type: str | None
    stop: Stop

    stop_geometry: PointGeometry | None

    approximate_enter_time: datetime.datetime | None
    approximate_exit_time: datetime.datetime | None
    duration: datetime.timedelta | None

    # For display purposes
    geometry: LineStringGeometry | MultiLineGeometry | None

    instruction: str | None = None

class BuildResult(BaseModel):
    parts: list[RoutePart]
    enter_stop: Stop
    exit_stop: Stop

class PathBuilderService:
    def __init__(self, db: Session):
        self.db = db

    def initialize(self):
        pass

    def build_path(self, point_a: StopId, point_b: StopId) -> BuildResult:
        query = text('''

WITH routing_graph AS (
    SELECT
        edge_id as id,
        source_node as source,
        target_node as target,
        cost,
        base_cost,
        distance
    FROM routing_edges
    WHERE is_active = true
),
start_node AS (
    SELECT node_id
    FROM routing_nodes
    WHERE stop_id = :point_a
    AND node_type = 'stop'
    LIMIT 1
),
end_node AS (
    SELECT node_id
    FROM routing_nodes
    WHERE stop_id = :point_b
    AND node_type = 'stop'
    LIMIT 1
),
raw_path AS (
    SELECT
        path.seq,
        path.node,
        path.edge,
        path.cost,
        path.agg_cost
    FROM pgr_dijkstra(
        'SELECT edge_id as id, source_node as source, target_node as target, cost FROM routing_edges WHERE is_active = true',
        (SELECT node_id FROM start_node),
        (SELECT node_id FROM end_node),
        directed := true
    ) AS path
    WHERE path.edge IS NOT NULL
),
path_with_details AS (
    SELECT
        rp.seq,
        rp.node,
        rp.edge,
        rp.cost as penalized_cost,
        rp.agg_cost,
        re.base_cost,
        re.transfer_penalty,
        rn_source.stop_id as source_stop_id,
        s_source.stop_name as source_stop_name,
        s_source.geometry as source_stop_geometry,
        rn_target.stop_id as target_stop_id,
        s_target.stop_name as target_stop_name,
        s_target.geometry as target_stop_geometry,
        re.edge_type,
        re.route_id,
        re.distance,
        re.geom as edge_geom,
        r.route_long_name,
        r.route_short_name,
        r.route_type
    FROM raw_path rp
    LEFT JOIN routing_edges re ON rp.edge = re.edge_id
    LEFT JOIN routing_nodes rn_source ON re.source_node = rn_source.node_id
    LEFT JOIN routing_nodes rn_target ON re.target_node = rn_target.node_id
    LEFT JOIN stops s_source ON rn_source.stop_id = s_source.stop_id
    LEFT JOIN stops s_target ON rn_target.stop_id = s_target.stop_id
    LEFT JOIN routes r ON re.route_id = r.route_id
),
-- STEP 1: Identify redundant route patterns (simplified)
redundancy_analysis AS (
    SELECT 
        *,
        LAG(route_id, 1) OVER (ORDER BY seq) as prev_route,
        LAG(route_id, 2) OVER (ORDER BY seq) as prev_route_2,
        LEAD(route_id, 1) OVER (ORDER BY seq) as next_route,
        
        -- Simplified redundancy detection
        CASE 
            -- Classic pattern: A -> B -> A
            WHEN edge_type IN ('transit', 'transit_express', 'transit_multi')
                 AND route_id = LAG(route_id, 2) OVER (ORDER BY seq)
                 AND LAG(route_id, 1) OVER (ORDER BY seq) != route_id
            THEN 'RETURN_TO_PREVIOUS_ROUTE'
            
            -- Short interruption: long route A -> short route B -> long route A  
            WHEN edge_type IN ('transit', 'transit_express', 'transit_multi')
                 AND LAG(route_id, 1) OVER (ORDER BY seq) != route_id
                 AND LEAD(route_id, 1) OVER (ORDER BY seq) != route_id
                 AND LAG(route_id, 1) OVER (ORDER BY seq) = LEAD(route_id, 1) OVER (ORDER BY seq)
                 AND base_cost < 300  -- Less than 5 minutes
            THEN 'SHORT_INTERRUPTION'
            
            ELSE 'NORMAL'
        END as redundancy_pattern
    FROM path_with_details
),
-- STEP 2: Mark segments for removal or consolidation
consolidation_plan AS (
    SELECT 
        *,
        CASE 
            -- Remove short interruptions entirely
            WHEN redundancy_pattern = 'SHORT_INTERRUPTION' THEN 'REMOVE'
            
            -- Consolidate returns to previous route
            WHEN redundancy_pattern = 'RETURN_TO_PREVIOUS_ROUTE' THEN 'CONSOLIDATE'
            
            ELSE 'KEEP'
        END as action,
        
        -- For consolidation, use the dominant route in the area
        CASE 
            WHEN redundancy_pattern = 'RETURN_TO_PREVIOUS_ROUTE' 
            THEN prev_route_2  -- Use the route we're returning to
            ELSE route_id
        END as effective_route_id
    FROM redundancy_analysis
),
-- STEP 3: Filter and clean the path
filtered_path AS (
    SELECT 
        *,
        -- Renumber sequence after removals
        ROW_NUMBER() OVER (ORDER BY seq) as new_seq
    FROM consolidation_plan 
    WHERE action != 'REMOVE'  -- Remove short interruptions
),
-- STEP 4: Create route segments with consolidation
route_changes AS (
    SELECT
        *,
        CASE 
            -- Route change based on effective route (after consolidation)
            WHEN edge_type IN ('transit', 'transit_express', 'transit_multi') 
                 AND LAG(edge_type) OVER (ORDER BY new_seq) IN ('transit', 'transit_express', 'transit_multi')
                 AND LAG(effective_route_id) OVER (ORDER BY new_seq) IS DISTINCT FROM effective_route_id
            THEN 1
            
            -- Mode change
            WHEN LAG(edge_type) OVER (ORDER BY new_seq) IS DISTINCT FROM edge_type 
                 AND NOT (
                     edge_type IN ('transit', 'transit_express', 'transit_multi') 
                     AND LAG(edge_type) OVER (ORDER BY new_seq) IN ('transit', 'transit_express', 'transit_multi')
                 )
            THEN 1
            
            -- Walking continuation
            WHEN edge_type = 'walking' AND LAG(edge_type) OVER (ORDER BY new_seq) = 'walking' THEN 0
            
            -- Transfer
            WHEN edge_type = 'transfer' THEN 1
            
            ELSE 0 
        END as is_segment_start
    FROM filtered_path
),
-- STEP 5: Create segments
route_segments AS (
    SELECT
        *,
        SUM(is_segment_start) OVER (ORDER BY new_seq) as segment_id
    FROM route_changes
),
-- STEP 6: Aggregate segments
consolidated_segments AS (
    SELECT
        segment_id,
        ROW_NUMBER() OVER (ORDER BY MIN(new_seq)) as seq,
        (array_agg(edge_type ORDER BY new_seq))[1] as edge_type,
        -- Use effective route ID (post-consolidation)
        (array_agg(effective_route_id ORDER BY new_seq))[1] as route_id,
        (array_agg(route_long_name ORDER BY new_seq))[1] as route_long_name,
        (array_agg(route_short_name ORDER BY new_seq))[1] as route_short_name,
        (array_agg(route_type ORDER BY new_seq))[1] as route_type,
        (array_agg(source_stop_id ORDER BY new_seq))[1] as enter_stop_id,
        (array_agg(source_stop_name ORDER BY new_seq))[1] as enter_stop_name,
        (array_agg(source_stop_geometry ORDER BY new_seq))[1] as enter_stop_geometry,
        (array_agg(target_stop_id ORDER BY new_seq DESC))[1] as exit_stop_id,
        (array_agg(target_stop_name ORDER BY new_seq DESC))[1] as exit_stop_name,
        (array_agg(target_stop_geometry ORDER BY new_seq DESC))[1] as exit_stop_geometry,
        SUM(base_cost) as total_travel_time,
        SUM(penalized_cost) as total_penalized_cost,
        SUM(transfer_penalty) as total_penalties,
        SUM(distance) as total_distance,
        COUNT(*) as edge_count,
        -- Count consolidation actions
        COUNT(*) FILTER (WHERE action = 'CONSOLIDATE') as consolidated_edges,
        COUNT(*) FILTER (WHERE redundancy_pattern != 'NORMAL') as redundant_patterns_fixed,
        STRING_AGG(DISTINCT action, ', ') as actions_taken,

        -- Geometry aggregation
        CASE 
            WHEN COUNT(edge_geom) FILTER (WHERE edge_geom IS NOT NULL) > 0 THEN
                ST_LineMerge(
                    ST_Collect(
                        edge_geom ORDER BY new_seq
                    ) FILTER (WHERE edge_geom IS NOT NULL)
                )
            ELSE
                CASE 
                    WHEN (array_agg(source_stop_geometry ORDER BY new_seq))[1] IS NOT NULL 
                         AND (array_agg(target_stop_geometry ORDER BY new_seq DESC))[1] IS NOT NULL 
                    THEN
                        ST_MakeLine(
                            (array_agg(source_stop_geometry ORDER BY new_seq))[1],
                            (array_agg(target_stop_geometry ORDER BY new_seq DESC))[1]
                        )
                    ELSE NULL
                END
        END as merged_geometry
    FROM route_segments
    GROUP BY segment_id
)
SELECT
    seq,
    segment_id,
    edge_type,
    route_id,
    route_long_name,
    route_short_name,
    route_type,
    enter_stop_id as stop_id,
    enter_stop_name as stop_name,
    enter_stop_geometry as stop_geometry,
    exit_stop_id,
    exit_stop_name,
    exit_stop_geometry,
    total_travel_time as cost,
    total_distance as distance,
    edge_count,
    merged_geometry as geometry,
    CASE 
        WHEN edge_type = 'walking' THEN 
            CASE 
                WHEN total_travel_time <= 300 THEN 'Walk ' || ROUND(total_distance::numeric) || 'm'
                ELSE 'Walk from ' || COALESCE(enter_stop_name, 'unknown') || ' to ' || COALESCE(exit_stop_name, 'unknown')
            END
        WHEN edge_type IN ('transit', 'transit_express', 'transit_multi') THEN 
            CASE 
                WHEN route_type = 1 THEN 'Metro '  -- Subway
                WHEN route_type = 3 THEN 'Bus '    -- Bus
                WHEN route_type = 0 THEN 'Tram '   -- Tram
                ELSE 'Take '
            END || 
            COALESCE(route_short_name, route_long_name, 'Line') || 
            ' from ' || COALESCE(enter_stop_name, 'unknown') || ' to ' || COALESCE(exit_stop_name, 'unknown') ||
            ' (' || ROUND(total_travel_time/60.0, 1) || ' min)' ||
            -- Show consolidation info
            CASE 
                WHEN redundant_patterns_fixed > 0 THEN ' [Fixed ' || redundant_patterns_fixed || ' redundant patterns]'
                ELSE ''
            END
        WHEN edge_type = 'transfer' THEN 
            'Transfer (' || ROUND(total_travel_time/60.0, 1) || ' min)'
        ELSE 
            'Travel from ' || COALESCE(enter_stop_name, 'unknown') || ' to ' || COALESCE(exit_stop_name, 'unknown')
    END as instruction,
    total_penalties,
    CASE WHEN merged_geometry IS NULL THEN 'NO_GEOMETRY' ELSE 'HAS_GEOMETRY' END as geometry_status,
    actions_taken,
    consolidated_edges,
    redundant_patterns_fixed,
    CASE 
        WHEN redundant_patterns_fixed > 0 THEN 'REDUNDANCY_ELIMINATED'
        WHEN edge_count > 5 THEN 'EFFICIENT_SEGMENT'
        ELSE 'NORMAL_SEGMENT'
    END as segment_analysis
FROM consolidated_segments
ORDER BY seq;

        ''')

        result = self.db.execute(query, {"point_a": point_a, "point_b": point_b}).fetchall()
        parts: List[RoutePart] = []
        for item in result:
            geometry = item.geometry
            geometry_converted = WKBElement(geometry) if geometry is not None else None
            stop_geometry = WKBElement(item.stop_geometry) if item.stop_geometry is not None else None
            route_part = RoutePart(
                route_id=item.route_id,
                stop_id=item.stop_id or item.exit_stop_id,
                stop_name=item.stop_name,
                approximate_enter_time=None,
                approximate_exit_time=None,
                duration=None,
                seq=item.seq,
                route_long_name=item.route_long_name,
                distance=item.distance,
                geometry=serialize_line_string_geometry(geometry_converted),
                stop=Stop(stop_id=item.stop_id, stop_name=item.stop_name),
                stop_geometry=serialize_point_geometry(stop_geometry) if stop_geometry else None,
                edge_type=item.edge_type,
                instruction=item.instruction,
            )
            parts.append(route_part)

        enter_stop = self.db.execute(
            select(Stop).where(Stop.stop_id == point_a)
        ).fetchone()[0]

        exit_stop = self.db.execute(
            select(Stop).where(Stop.stop_id == point_b)
        ).fetchone()[0]

        return BuildResult(
            parts=parts,
            enter_stop=enter_stop,
            exit_stop=exit_stop,
        )

    def clean(self):
        pass