#!/bin/bash

# Wait for PostgreSQL to be ready
echo "Waiting for PostgreSQL to be ready..."
while ! nc -z postgres 5432; do
  sleep 0.1
done
echo "PostgreSQL is ready!"

# Wait for Kafka to be ready
echo "Waiting for Kafka to be ready..."
while ! nc -z kafka 9092; do
  sleep 0.1
done
echo "Kafka is ready!"

# Start the application with autoreload
echo "Starting the application with autoreload..."
cd /app && PYTHONPATH=. fastapi dev app/main.py --port 8000 --host 0.0.0.0
