const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const axios = require('axios');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "http://localhost:8080",
        methods: ["GET", "POST"],
        credentials: true
    }
});

// Serve static files from the public directory
app.use(express.static('public'));

const corsOptions = {
  origin: 'http://localhost:8080',
  optionsSuccessStatus: 200 // For legacy browser support
};

app.use(cors(corsOptions));

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:8080');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// API endpoints
const API_BASE_URL = 'http://localhost:8000/api/v1';
const VEHICLES_URL = `${API_BASE_URL}/vehicles`;
const ROUTES_URL = `${API_BASE_URL}/routes`;

// Function to fetch vehicle positions
async function fetchVehiclePositions() {
    try {
        const response = await axios.get(VEHICLES_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching vehicle positions:', error);
        return [];
    }
}

// Function to fetch vehicle positions by route
async function fetchVehiclePositionsByRoute(routeId) {
    try {
        const response = await axios.get(`${VEHICLES_URL}-for-route/${routeId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching vehicle positions for route ${routeId}:`, error);
        return [];
    }
}

// Function to fetch routes
async function fetchRoutes() {
    try {
        const response = await axios.get(ROUTES_URL);
        console.log("got routes response", response.data)
        return response.data;
    } catch (error) {
        console.error('Error fetching routes:', error);
        return [];
    }
}

// Function to fetch stops for a route
async function fetchRouteStops(routeId) {
    try {
        const response = await axios.get(`${API_BASE_URL}/routes/${routeId}/stops`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching stops for route ${routeId}:`, error);
        return [];
    }
}

async function fetchTripStops(tripId) {
    try {
        const response = await axios.get(`${API_BASE_URL}/trips/${tripId}/stops`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching stops for trip ${tripId}:`, error);
        return [];
    }
}

// Function to fetch shape for a route
async function fetchRouteShape(routeId) {
    try {
        const response = await axios.get(`${API_BASE_URL}/routes/${routeId}/shape`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching shape for route ${routeId}:`, error);
        return [];
    }
}

// Function to fetch shape for a trip
async function fetchTripShape(tripId) {
    try {
        const response = await axios.get(`${API_BASE_URL}/trips/${tripId}/shape`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching shape for trip ${tripId}:`, error);
        return [];
    }
}

const VEHICLE_UPDATE_INTERVAL_MS = 1000;

// Function to fetch trips for a route
async function fetchRouteTrips(routeId) {
    try {
        const response = await axios.get(`${API_BASE_URL}/routes/${routeId}/trips`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching trips for route ${routeId}:`, error);
        return [];
    }
}

// Set up WebSocket connection
io.on('connection', async (socket) => {
    console.log('Client connected');
    
    // Send initial data
    const [routes] = await Promise.all([
        fetchRoutes()
    ]);
    
    socket.emit('routes', routes);

    const intervals = new Map()
    
    // Handle route stop requests
    socket.on('requestTripStops', async (tripId) => {
        const tripStops = await fetchTripStops(tripId);
        socket.emit('tripStops', { tripId, stops: tripStops });
    });

    socket.on('requestRouteVehicleUpdates', async (routeId) => {
        const positions = await fetchVehiclePositionsByRoute(routeId);
        socket.emit('routeVehicleUpdates', { routeId, positions });

        const interval = setInterval(async () => {
            const positions = await fetchVehiclePositionsByRoute(routeId);
            socket.emit('routeVehicleUpdates', { routeId, positions });
        }, VEHICLE_UPDATE_INTERVAL_MS);
        
        intervals.set(routeId, interval);
    });

    socket.on('requestRouteTrips', async (routeId) => {
        const trips = await fetchRouteTrips(routeId);
        socket.emit('routeTrips', { routeId, trips });
    });

    socket.on('requestTripShape', async (tripId) => {
        const shape = await fetchTripShape(tripId);
        socket.emit('tripShape', { tripId, shape });
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected');
        intervals.forEach((interval, routeId) => {
            clearInterval(interval);
        });
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
}); 