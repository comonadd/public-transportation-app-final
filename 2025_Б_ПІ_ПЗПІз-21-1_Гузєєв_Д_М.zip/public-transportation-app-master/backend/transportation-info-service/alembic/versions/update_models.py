"""update models

Revision ID: update_models
Revises: fb75f38e6a02
Create Date: 2024-04-12 16:00:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "update_models"
down_revision: Union[str, None] = "fb75f38e6a02"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Drop existing tables in reverse order
    op.drop_table("route_stop_association")
    op.drop_table("vehicles")
    op.drop_table("stop_times", if_exists=True)
    op.drop_table("trips", if_exists=True)
    op.drop_table("routes", if_exists=True)
    op.drop_table("stops", if_exists=True)
    op.drop_table("agencies", if_exists=True)

    # Create new tables with correct schema
    op.create_table(
        "agencies",
        sa.Column("agency_id", sa.String(), nullable=False),
        sa.Column("agency_name", sa.String(), nullable=False),
        sa.Column("agency_url", sa.String(), nullable=False),
        sa.Column("agency_timezone", sa.String(), nullable=False),
        sa.Column("agency_lang", sa.String(), nullable=True),
        sa.Column("agency_phone", sa.String(), nullable=True),
        sa.Column("agency_fare_url", sa.String(), nullable=True),
        sa.PrimaryKeyConstraint("agency_id"),
    )

    op.create_table(
        "stops",
        sa.Column("stop_id", sa.String(), nullable=False),
        sa.Column("stop_code", sa.String(), nullable=True),
        sa.Column("stop_name", sa.String(), nullable=False),
        sa.Column("stop_desc", sa.String(), nullable=True),
        sa.Column("stop_lat", sa.Float(), nullable=False),
        sa.Column("stop_lon", sa.Float(), nullable=False),
        sa.Column("zone_id", sa.String(), nullable=True),
        sa.Column("stop_url", sa.String(), nullable=True),
        sa.Column("location_type", sa.Integer(), nullable=True),
        sa.Column("parent_station", sa.String(), nullable=True),
        sa.Column("stop_timezone", sa.String(), nullable=True),
        sa.Column("wheelchair_boarding", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("stop_id"),
    )

    op.create_table(
        "routes",
        sa.Column("route_id", sa.String(), nullable=False),
        sa.Column("agency_id", sa.String(), nullable=True),
        sa.Column("route_short_name", sa.String(), nullable=True),
        sa.Column("route_long_name", sa.String(), nullable=True),
        sa.Column("route_desc", sa.String(), nullable=True),
        sa.Column("route_type", sa.Integer(), nullable=False),
        sa.Column("route_url", sa.String(), nullable=True),
        sa.Column("route_color", sa.String(), nullable=True),
        sa.Column("route_text_color", sa.String(), nullable=True),
        sa.Column("route_sort_order", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["agency_id"],
            ["agencies.agency_id"],
        ),
        sa.PrimaryKeyConstraint("route_id"),
    )

    op.create_table(
        "trips",
        sa.Column("trip_id", sa.String(), nullable=False),
        sa.Column("route_id", sa.String(), nullable=False),
        sa.Column("service_id", sa.String(), nullable=False),
        sa.Column("trip_headsign", sa.String(), nullable=True),
        sa.Column("trip_short_name", sa.String(), nullable=True),
        sa.Column("direction_id", sa.Integer(), nullable=True),
        sa.Column("block_id", sa.String(), nullable=True),
        sa.Column("shape_id", sa.String(), nullable=True),
        sa.Column("wheelchair_accessible", sa.Integer(), nullable=True),
        sa.Column("bikes_allowed", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["route_id"],
            ["routes.route_id"],
        ),
        sa.PrimaryKeyConstraint("trip_id"),
    )

    op.create_table(
        "stop_times",
        sa.Column("trip_id", sa.String(), nullable=False),
        sa.Column("arrival_time", sa.Time(), nullable=True),
        sa.Column("departure_time", sa.Time(), nullable=True),
        sa.Column("stop_id", sa.String(), nullable=False),
        sa.Column("stop_sequence", sa.Integer(), nullable=False),
        sa.Column("stop_headsign", sa.String(), nullable=True),
        sa.Column("pickup_type", sa.Integer(), nullable=True),
        sa.Column("drop_off_type", sa.Integer(), nullable=True),
        sa.Column("shape_dist_traveled", sa.Float(), nullable=True),
        sa.Column("timepoint", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["stop_id"],
            ["stops.stop_id"],
        ),
        sa.ForeignKeyConstraint(
            ["trip_id"],
            ["trips.trip_id"],
        ),
        sa.PrimaryKeyConstraint("trip_id", "stop_id"),
    )

    op.create_table(
        "vehicles",
        sa.Column("vehicle_id", sa.String(), nullable=False),
        sa.Column("trip_id", sa.String(), nullable=True),
        sa.Column("route_id", sa.String(), nullable=True),
        sa.Column("direction_id", sa.Integer(), nullable=True),
        sa.Column("start_time", sa.Time(), nullable=True),
        sa.Column("start_date", sa.String(), nullable=True),
        sa.Column("schedule_relationship", sa.Integer(), nullable=True),
        sa.Column("current_stop_sequence", sa.Integer(), nullable=True),
        sa.Column("stop_id", sa.String(), nullable=True),
        sa.Column("current_status", sa.Integer(), nullable=True),
        sa.Column("timestamp", sa.DateTime(), nullable=False),
        sa.Column("congestion_level", sa.Integer(), nullable=True),
        sa.Column("occupancy_status", sa.Integer(), nullable=True),
        sa.Column("latitude", sa.Float(), nullable=False),
        sa.Column("longitude", sa.Float(), nullable=False),
        sa.ForeignKeyConstraint(
            ["route_id"],
            ["routes.route_id"],
        ),
        sa.ForeignKeyConstraint(
            ["stop_id"],
            ["stops.stop_id"],
        ),
        sa.ForeignKeyConstraint(
            ["trip_id"],
            ["trips.trip_id"],
        ),
        sa.PrimaryKeyConstraint("vehicle_id"),
    )

    # Create route_stop_association table
    op.create_table(
        "route_stop_association",
        sa.Column("route_id", sa.String(), nullable=False),
        sa.Column("stop_id", sa.String(), nullable=False),
        sa.ForeignKeyConstraint(
            ["route_id"],
            ["routes.route_id"],
        ),
        sa.ForeignKeyConstraint(
            ["stop_id"],
            ["stops.stop_id"],
        ),
        sa.PrimaryKeyConstraint("route_id", "stop_id"),
    )


def downgrade() -> None:
    # Drop all tables in reverse order
    op.drop_table("route_stop_association")
    op.drop_table("vehicles")
    op.drop_table("stop_times")
    op.drop_table("trips")
    op.drop_table("routes")
    op.drop_table("stops")
    op.drop_table("agencies")
