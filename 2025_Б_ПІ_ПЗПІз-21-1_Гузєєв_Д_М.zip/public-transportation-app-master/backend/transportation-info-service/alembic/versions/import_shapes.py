"""import shapes

Revision ID: import_shapes
Revises: populate_route_stops
Create Date: 2024-04-12 17:30:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "import_shapes"
down_revision: Union[str, None] = "populate_route_stops"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create shapes table
    op.create_table(
        "shapes",
        sa.Column("shape_id", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("shape_id"),
    )

    # Create shape_points table
    op.create_table(
        "shape_points",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("shape_id", sa.String(), nullable=False),
        sa.Column("shape_pt_lat", sa.Float(), nullable=False),
        sa.Column("shape_pt_lon", sa.Float(), nullable=False),
        sa.Column("shape_pt_sequence", sa.Integer(), nullable=False),
        sa.Column("shape_dist_traveled", sa.Float(), nullable=True),
        sa.ForeignKeyConstraint(["shape_id"], ["shapes.shape_id"]),
        sa.PrimaryKeyConstraint("id"),
    )

    # Get the connection
    conn = op.get_bind()

    # Read and import shapes data
    with open("real_data_for_lviv/shapes.txt", "r") as f:
        # Skip header
        next(f)

        # Keep track of unique shape_ids
        shape_ids = set()

        # Prepare batch insert for shape points
        batch = []
        for line in f:
            shape_id, lat, lon, seq, dist = line.strip().split(",")

            # Add shape_id to set and insert into shapes table if not exists
            if shape_id not in shape_ids:
                conn.execute(
                    sa.text("INSERT INTO shapes (shape_id) VALUES (:shape_id)"),
                    {"shape_id": shape_id},
                )
                shape_ids.add(shape_id)

            # Add shape point to batch
            batch.append(
                {
                    "shape_id": shape_id,
                    "shape_pt_lat": float(lat),
                    "shape_pt_lon": float(lon),
                    "shape_pt_sequence": int(seq),
                    "shape_dist_traveled": float(dist) if dist else None,
                }
            )

            # Insert in batches of 1000
            if len(batch) >= 1000:
                conn.execute(
                    sa.text("""
                        INSERT INTO shape_points 
                        (shape_id, shape_pt_lat, shape_pt_lon, shape_pt_sequence, shape_dist_traveled)
                        VALUES (:shape_id, :shape_pt_lat, :shape_pt_lon, :shape_pt_sequence, :shape_dist_traveled)
                    """),
                    batch,
                )
                batch = []

        # Insert remaining records
        if batch:
            conn.execute(
                sa.text("""
                    INSERT INTO shape_points 
                    (shape_id, shape_pt_lat, shape_pt_lon, shape_pt_sequence, shape_dist_traveled)
                    VALUES (:shape_id, :shape_pt_lat, :shape_pt_lon, :shape_pt_sequence, :shape_dist_traveled)
                """),
                batch,
            )

    # Add foreign key constraint to trips table
    op.create_foreign_key(
        "fk_trips_shape_id", "trips", "shapes", ["shape_id"], ["shape_id"]
    )


def downgrade() -> None:
    # Drop foreign key constraint
    op.drop_constraint("fk_trips_shape_id", "trips", type_="foreignkey")

    # Drop shape_points table
    op.drop_table("shape_points")

    # Drop shapes table
    op.drop_table("shapes")
