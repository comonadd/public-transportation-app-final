from typing import Optional, Tuple, cast

from sqlalchemy import select
from sqlalchemy.orm import Session

from service.models import Route, Stop, Vehicle
from service.services.position_calculator import PositionCalculator


class StopFinderError(Exception):
    ROUTE_NOT_FOUND = "ROUTE_NOT_FOUND"
    NO_STOPS_FOUND = "NO_STOPS_FOUND"
    NO_CLOSEST_STOP_FOUND = "NO_CLOSEST_STOP_FOUND"

    def __init__(self, code: str, detail: str):
        self.code = code
        self.detail = detail

    def __str__(self):
        return f"{self.code}: {self.detail}"


def find_closest_stop(
    db: Session, vehicle: Vehicle, route_id: str
) -> Tuple[Optional[Stop], Optional[Stop]]:
    """
    Find the closest stop to the vehicle's current position and the next stop on the route.

    Args:
        db: Database session
        vehicle: The vehicle to find stops for
        route_id: The ID of the route the vehicle is on

    Returns:
        A tuple of (current_stop, next_stop) where both are Stop objects or None
    """
    # Get the route
    route = db.execute(
        select(Route).where(Route.route_id == route_id)
    ).scalar_one_or_none()
    if not route:
        return None, None

    # Get all stops for this route
    stops = (
        db.execute(select(Stop).where(Stop.routes.any(Route.route_id == route_id)))
        .scalars()
        .all()
    )
    if not stops:
        return None, None

    # Find the closest stop
    closest_stop = None
    closest_stop_idx = None
    min_distance = float("inf")
    for idx, stop in enumerate(stops):
        distance = PositionCalculator.calculate_distance(
            float(cast(float, vehicle.latitude)),
            float(cast(float, vehicle.longitude)),
            float(cast(float, stop.stop_lat)),
            float(cast(float, stop.stop_lon)),
        )
        if distance < min_distance:
            min_distance = distance
            closest_stop = stop
            closest_stop_idx = idx

    if not closest_stop or not closest_stop_idx:
        return None, None

    next_stop_idx = (closest_stop_idx + 1) % len(stops)
    next_stop = stops[next_stop_idx]

    return closest_stop, next_stop
