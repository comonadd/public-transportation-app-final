import threading
import time
from dataclasses import dataclass
import datetime
from functools import lru_cache
from typing import Dict, Optional, Tuple, List

from service.config import (
    VEHICLE_STOP_DURATION_SECONDS,
    VEHICLE_UPDATE_POSITION_CYCLE_LENGTH_SECONDS,
)
from service.models import Vehicle, ShapePoint, StopTime
from service.services.position_calculator import (
    PositionCalculator,
    StopId,
    VehicleState,
)
from service.services.route_service import RouteService
from service.services.route_shape_service import RouteShapeService
from service.services.stop_service import StopService
from service.services.vehicle_service import VehicleService
from sqlalchemy.orm import Session
from structlog import get_logger

logger = get_logger(__name__)


class VehiclePositionServiceError(Exception):
    VEHICLE_NOT_FOUND = "VEHICLE_NOT_FOUND"
    INITIALIZATION_ERROR = "INITIALIZATION_ERROR"

    def __init__(self, code: str, detail: str):
        self.code = code
        self.detail = detail

    def __str__(self):
        return f"{self.code}: {self.detail}"


@dataclass
class VehiclePositionServiceState:
    vehicle_states: Dict[str, VehicleState]
    failed_initializations: Dict[str, VehiclePositionServiceError]


class VehiclePositionService:
    def __init__(
        self,
        db: Session,
        vehicle_service: VehicleService,
        stop_service: StopService,
        route_service: RouteService,
        route_shape_service: RouteShapeService,
        initial_state: VehiclePositionServiceState | None = None,
    ):
        self.db = db
        self.vehicle_service = vehicle_service
        self.stop_service = stop_service
        self.route_service = route_service
        self.route_shape_service = route_shape_service
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.state = initial_state or VehiclePositionServiceState(
            vehicle_states={},
            failed_initializations={},
        )

    def start(self):
        if self._thread is not None and self._thread.is_alive():
            logger.info("Vehicle position service already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._update_loop)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join()
            self._thread = None

    def _update_loop(self):
        """Main update loop for vehicle positions."""
        try:
            logger.info(
                "Starting vehicle position update loop",
                cycle_length=VEHICLE_UPDATE_POSITION_CYCLE_LENGTH_SECONDS,
            )
            current_time = datetime.datetime.combine(datetime.date.today(), datetime.time(
                hour=11,
                minute=0,
                second=0,
            ))
            time_dilation_coefficient = 60 # one cycle equals 60 seconds in this simulation
            vehicles = self.vehicle_service.get_all_vehicles()
            for vehicle in vehicles:
                self.state.vehicle_states[vehicle.vehicle_id] = VehicleState(
                    current_position=(vehicle.latitude, vehicle.longitude),
                    trip_shape_id=vehicle.trip.shape_id,
                    trip_id=vehicle.trip_id,
                )
            while not self._stop_event.is_set():
                real_time_start = datetime.datetime.now()
                logger.info("Updating vehicle positions", time=current_time)
                self.state = self.advance_state(self.state, current_time=current_time)
                logger.info("Finished with update calculations")
                db_start = datetime.datetime.now()
                self.commit_state_to_db()
                real_time_end = datetime.datetime.now()
                logger.info("Finished update", time_passed=real_time_end - real_time_start, db_update_time=real_time_end - db_start)
                time.sleep(VEHICLE_UPDATE_POSITION_CYCLE_LENGTH_SECONDS)
                time_passed = time_dilation_coefficient
                current_time += datetime.timedelta(seconds=time_passed)
        except Exception as e:
            logger.error(
                "Error happened while updating vehicle positions",
            )
            raise e from e

    def commit_state_to_db(self):
        vehicles_updated = 0
        for vehicle_id, vehicle_state in self.state.vehicle_states.items():
            if not vehicle_state.dirty:
                continue
            self.db.query(Vehicle).filter(Vehicle.vehicle_id == vehicle_id).update(
                {
                    "latitude": vehicle_state.current_position[0],
                    "longitude": vehicle_state.current_position[1],
                    "timestamp": datetime.datetime.now(),
                }
            )
            vehicle_state.dirty = False
            vehicles_updated += 1
        logger.info("Commited vehicle state to db with timestamps", vehicles_updated=vehicles_updated)
        self.db.commit()

    def advance_state(
        self, prev_state: VehiclePositionServiceState, current_time: datetime
    ) -> VehiclePositionServiceState:
        new_state = VehiclePositionServiceState(
            vehicle_states=prev_state.vehicle_states,
            failed_initializations=prev_state.failed_initializations,
        )

        for vehicle_id, vehicle in self.state.vehicle_states.items():
            try:
                old_vehicle_state = prev_state.vehicle_states.get(vehicle_id)
                if old_vehicle_state is None:
                    raise VehiclePositionServiceError(
                        code="VEHICLE_NOT_FOUND",
                        detail=f"Vehicle {vehicle_id} not found",
                    )
                new_vehicle_state = self.advance_vehicle_state(
                    old_vehicle_state, current_time
                )
                new_state.vehicle_states[vehicle_id] = new_vehicle_state
            except KeyError:
                raise VehiclePositionServiceError(
                    code=VehiclePositionServiceError.VEHICLE_NOT_FOUND,
                    detail=f"Vehicle {vehicle_id} not found in vehicle_states",
                )

        return new_state

    @lru_cache(maxsize=20000)
    def get_ordered_shape_points(self, shape_id: str) -> List[ShapePoint]:
        return self.route_shape_service.get_ordered_shape_points(
            shape_id,
        )

    @lru_cache(maxsize=2000)
    def get_stop_times(self, trip_id: str) -> List[StopTime]:
        return self.route_shape_service.get_ordered_stop_times(trip_id)

    def advance_vehicle_state(
        self, vehicle: VehicleState, current_time: datetime
    ) -> VehicleState:
        """Update the state and position of a vehicle."""

        new_state = VehicleState(
            current_position=vehicle.current_position,
            trip_id=vehicle.trip_id,
            trip_shape_id=vehicle.trip_shape_id,
        )

        if not vehicle.trip_id:
            raise VehiclePositionServiceError(
                code=VehiclePositionServiceError.INITIALIZATION_ERROR,
                detail=f"Vehicle {vehicle.vehicle_id} has no trip_id",
            )

        # Get the trip's shape points and stop times
        shape_points = self.get_ordered_shape_points(
            vehicle.trip_shape_id,
        )
        stop_times = self.get_stop_times(vehicle.trip_id)

        if not shape_points or not stop_times:
            return new_state

        # Calculate new position
        current_time_seconds = int(current_time.timestamp())
        position = self.route_shape_service.calculate_position_in_route(
            current_time_seconds, stop_times, shape_points
        )

        if not position:
            return new_state

        # Update state with new position
        new_state.current_position = (position.latitude, position.longitude)

        if new_state.current_position != vehicle.current_position:
            new_state.dirty = True

        # Check if we're near a stop
        for stop_time in stop_times:
            distance = PositionCalculator.calculate_distance(
                position.latitude,
                position.longitude,
                float(stop_time.stop.stop_lat),
                float(stop_time.stop.stop_lon),
            )

            if distance < 50:  # 50 meters proximity threshold
                new_state.current_stop_id = StopId(stop_time.stop_id)
                new_state.is_at_stop = True
                new_state.stop_start_time = current_time
                break
            else:
                new_state.is_at_stop = False
                new_state.stop_start_time = None



        return new_state
