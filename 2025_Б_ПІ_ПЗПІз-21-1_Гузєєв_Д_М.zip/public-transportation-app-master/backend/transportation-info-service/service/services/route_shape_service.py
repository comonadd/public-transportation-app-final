from dataclasses import dataclass
from datetime import datetime, time
from typing import List, Optional

from service.models import Shape, ShapePoint, StopTime
from service.services.position_calculator import PositionCalculator


@dataclass
class Position:
    latitude: float
    longitude: float


class RouteShapeService:
    def __init__(self, db):
        self.db = db

    def get_ordered_shape_points(self, shape_id: str) -> List[ShapePoint]:
        """Get shape points ordered by sequence for a given shape ID."""
        return (
            self.db.query(ShapePoint)
            .filter(ShapePoint.shape_id == shape_id)
            .order_by(ShapePoint.shape_pt_sequence)
            .all()
        )

    def get_ordered_stop_times(self, trip_id: str) -> List[StopTime]:
        """Get stop times ordered by sequence for a given trip ID."""
        return (
            self.db.query(StopTime)
            .filter(StopTime.trip_id == trip_id)
            .order_by(StopTime.stop_sequence)
            .all()
        )

    def find_shape_point_for_stop(
        self, stop_lat: float, stop_lon: float, shape_points: List[Shape]
    ) -> Optional[Shape]:
        """Find the closest shape point to a given stop."""
        closest_point = None
        min_distance = float("inf")

        for point in shape_points:
            distance = PositionCalculator.calculate_distance(
                stop_lat, stop_lon, point.shape_pt_lat, point.shape_pt_lon
            )
            if distance < min_distance:
                min_distance = distance
                closest_point = point

        return closest_point

    def get_shape_points_between(
        self, start_sequence: int, end_sequence: int, shape_points: List[Shape]
    ) -> List[Shape]:
        """Get shape points between two sequence numbers."""
        return [
            point
            for point in shape_points
            if start_sequence <= point.shape_pt_sequence <= end_sequence
        ]

    def interpolate_position(
        self, points: List[Shape], progress: float
    ) -> Optional[Position]:
        """Interpolate position along a list of shape points."""
        if not points:
            return None

        if len(points) == 1:
            return Position(
                latitude=float(points[0].shape_pt_lat),
                longitude=float(points[0].shape_pt_lon),
            )

        # Calculate total distance along this segment
        total_distance = 0.0
        segment_distances = []

        for i in range(len(points) - 1):
            distance = PositionCalculator.calculate_distance(
                points[i].shape_pt_lat,
                points[i].shape_pt_lon,
                points[i + 1].shape_pt_lat,
                points[i + 1].shape_pt_lon,
            )
            total_distance += distance
            segment_distances.append(distance)

        # Find which sub-segment we're on based on progress
        target_distance = total_distance * progress
        accumulated_distance = 0.0

        for i in range(len(segment_distances)):
            if accumulated_distance + segment_distances[i] >= target_distance:
                sub_progress = (
                    target_distance - accumulated_distance
                ) / segment_distances[i]

                # Interpolate between these two points
                lat = float(points[i].shape_pt_lat) + sub_progress * (
                    float(points[i + 1].shape_pt_lat) - float(points[i].shape_pt_lat)
                )
                lon = float(points[i].shape_pt_lon) + sub_progress * (
                    float(points[i + 1].shape_pt_lon) - float(points[i].shape_pt_lon)
                )

                return Position(latitude=lat, longitude=lon)

            accumulated_distance += segment_distances[i]

        # Default to last point if we've gone beyond
        return Position(
            latitude=float(points[-1].shape_pt_lat),
            longitude=float(points[-1].shape_pt_lon),
        )

    def _time_to_seconds(self, t: time) -> int:
        """Convert a time object to seconds since midnight."""
        return t.hour * 3600 + t.minute * 60 + t.second

    def calculate_position_in_route(
        self,
        current_time_seconds_global: int,
        stop_times: List[StopTime],
        shape_points: List[Shape],
    ) -> Optional[Position]:
        """Calculate vehicle position along a route based on schedule."""
        previous_stop = None
        next_stop = None

        today = datetime.now().date()
        day_start = datetime.combine(today, time(0, 0, 0))
        day_start_timestamp = int(day_start.timestamp())
        seconds_passed_since_day_start = (
            current_time_seconds_global - day_start_timestamp
        )

        for i in range(len(stop_times)):
            departure_seconds = self._time_to_seconds(stop_times[i].departure_time)
            if i < len(stop_times) - 1:
                next_arrival_seconds = self._time_to_seconds(
                    stop_times[i + 1].arrival_time
                )
            else:
                next_arrival_seconds = None

            if departure_seconds <= seconds_passed_since_day_start and (
                next_arrival_seconds is None
                or next_arrival_seconds > seconds_passed_since_day_start
            ):
                previous_stop = stop_times[i]
                if i < len(stop_times) - 1:
                    next_stop = stop_times[i + 1]
                break

        if not previous_stop:
            # Vehicle hasn't started its trip yet
            return None

        if not next_stop:
            # Vehicle has completed its trip
            return Position(
                latitude=float(shape_points[-1].shape_pt_lat),
                longitude=float(shape_points[-1].shape_pt_lon),
            )

        # Find corresponding shape points for these stops
        previous_point = self.find_shape_point_for_stop(
            previous_stop.stop.stop_lat,
            previous_stop.stop.stop_lon,
            shape_points,
        )
        next_point = self.find_shape_point_for_stop(
            next_stop.stop.stop_lat,
            next_stop.stop.stop_lon,
            shape_points,
        )

        if not previous_point or not next_point:
            return None

        # Calculate progress between stops as a percentage
        total_time = self._time_to_seconds(
            next_stop.arrival_time
        ) - self._time_to_seconds(previous_stop.departure_time)
        elapsed_time = seconds_passed_since_day_start - self._time_to_seconds(
            previous_stop.departure_time
        )
        progress = elapsed_time / total_time

        # Find intermediate points between previous and next stop
        intermediate_points = self.get_shape_points_between(
            previous_point.shape_pt_sequence,
            next_point.shape_pt_sequence,
            shape_points,
        )

        # Interpolate position along route
        return self.interpolate_position(intermediate_points, progress)
