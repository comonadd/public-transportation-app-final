from typing import Optional, Tuple

from service.models import Stop
from sqlalchemy import select
from sqlalchemy.orm import Session
from structlog import get_logger

logger = get_logger(__name__)


class StopService:
    def __init__(self, db: Session):
        self.db = db

    def get_route_stops_in_order(self, route_id: str) -> list[Stop]:
        return (
            self.db.execute(
                select(Stop)
                .where(Stop.route_id == route_id)
                .order_by(Stop.stop_sequence)
            )
            .scalars()
            .all()
        )

    def find_closest_stop(
        self, vehicle_lat: float, vehicle_lon: float, route_id: str
    ) -> Tuple[Optional[Stop], Optional[Stop]]:
        """Find the closest current and next stops for a vehicle on a route."""

        stops = self.get_route_stops_in_order(route_id)

        if not stops:
            return None, None

        # Find the closest stop to the vehicle's current position
        closest_stop = None
        min_distance = float("inf")

        for stop in stops:
            distance = self._calculate_distance(
                vehicle_lat,
                vehicle_lon,
                stop.stop_lat,
                stop.stop_lon,
            )
            if distance < min_distance:
                min_distance = distance
                closest_stop = stop

        if not closest_stop:
            return None, None

        # Find the next stop in sequence
        next_stop = None
        for stop in stops:
            if stop.stop_sequence > closest_stop.stop_sequence:
                next_stop = stop
                break

        # If no next stop found, wrap around to the first stop
        if not next_stop and stops:
            next_stop = stops[0]

        return closest_stop, next_stop

    def _calculate_distance(
        self, lat1: float, lon1: float, lat2: float, lon2: float
    ) -> float:
        """Calculate the distance between two points using the Haversine formula."""
        from math import atan2, cos, radians, sin, sqrt

        R = 6371  # Earth's radius in kilometers

        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1

        a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
        c = 2 * atan2(sqrt(a), sqrt(1 - a))
        distance = R * c

        return distance
