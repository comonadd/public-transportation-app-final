import random
from datetime import datetime

import structlog
from fastapi import Request
from fastapi.responses import RedirectResponse
from service.database import get_db
from service.models import Route, Stop, Trip, Vehicle
from sqladmin import ModelView, action
from sqlalchemy import select

logger = structlog.get_logger(__name__)


class VehicleAdmin(ModelView, model=Vehicle):
    column_list = [  # type: ignore
        Vehicle.vehicle_id,  # type: ignore
        Vehicle.latitude,  # type: ignore
        Vehicle.longitude,  # type: ignore
        Vehicle.timestamp,  # type: ignore
        Vehicle.route_id,  # type: ignore
    ]

    @action(
        name="randomize_state",
        label="Randomize State",
        confirmation_message="Are you sure?",
        add_in_detail=True,
        add_in_list=True,
    )
    async def randomize_state(self, request: Request):
        pks = request.query_params.get("pks", "").split(",")
        if not pks:
            logger.error("No vehicles selected")
            return

        db = next(get_db())

        for pk in pks:
            logger.info("Randomizing state for vehicle", vehicle_id=pk)
            # Select random route and a trip related to that route
            vehicle = db.execute(
                select(Vehicle).where(Vehicle.vehicle_id == pk)
            ).scalar_one()
            route = db.execute(
                select(Route).where(Route.route_id == vehicle.route_id)
            ).scalar_one()
            trip = random.choice(route.trips)
            vehicle.trip_id = trip.trip_id
            # Select random stop from trip
            stop = random.choice(trip.stop_times)
            vehicle.stop_id = stop.stop_id
            vehicle.latitude = stop.stop.stop_lat
            vehicle.longitude = stop.stop.stop_lon

        db.commit()

        return RedirectResponse(request.url_for("admin:list", identity=self.identity))

    @action(
        name="reinitialize_vehicles",
        label="Re-Initialize Vehicles",
        confirmation_message="Are you sure?",
        add_in_detail=True,
        add_in_list=True,
    )
    async def reinit_vehicles(self, request: Request):
        db = next(get_db())

        db.query(Vehicle).delete()

        logger.info(f"Deleted all vehicles")

        routes = db.execute(select(Route)).scalars().all()  # type: ignore

        for route in routes:
            # Get all trips
            trips = route.trips
            if not trips:
                logger.warning(f"No trips found for route {route.route_id}")
                continue

            # Create 1 vehicle per trip


            # Only create vehicles for every 4th trip
            for trip_idx in range(0, len(trips), 4):
                trip = trips[trip_idx]

                # Get the first stop
                stop = trip.stop_times[0].stop

                # Create vehicle
                vehicle = Vehicle(
                    vehicle_id=f"{route.route_id}-{trip.trip_id}",
                    route_id=route.route_id,
                    trip_id=trip.trip_id,
                    latitude=stop.stop_lat,
                    longitude=stop.stop_lon,
                    timestamp=datetime.now(),
                )

                db.add(vehicle)
                logger.info(
                    "Created new vehicle",
                    vehicle_id=vehicle.vehicle_id,
                    route_id=route.route_id,
                    stop_id=stop.stop_id,
                )

        db.commit()

        return RedirectResponse(request.url_for("admin:list", identity=self.identity))


# async def create_vehicles_for_routes(db: Session):
#     """Create 2-4 vehicles for each route at random stops."""
#     routes = db.execute(select(Route)).scalars().all()  # type: ignore

#     for route in routes:
#         # Get all stops for this route
#         stops = route.stops
#         if not stops:
#             logger.warning(f"No stops found for route {route.route_id}")
#             continue

#         # Create 2-4 vehicles for this route
#         num_vehicles = random.randint(2, 4)
#         for i in range(num_vehicles):
#             # Pick a random stop
#             stop = random.choice(stops)

#             # Create vehicle
#             vehicle = Vehicle(
#                 vehicle_id=f"{route.route_id}-{i+1}",
#                 route_id=route.route_id,
#                 latitude=stop.stop_lat,
#                 longitude=stop.stop_lon,
#                 timestamp=datetime.now(),
#             )

#             self.db.add(vehicle)
#             logger.info(
#                 "Created new vehicle",
#                 vehicle_id=vehicle.vehicle_id,
#                 route_id=route.route_id,
#                 stop_id=stop.stop_id,
#             )

#     self.db.commit()
#     logger.info("Finished creating vehicles for all routes")


class RouteAdmin(ModelView, model=Route):
    column_list = [  # type: ignore
        Route.route_id,
        Route.route_long_name,
        Route.route_desc,
        Route.route_color,
        Route.stops,
    ]


class StopAdmin(ModelView, model=Stop):
    column_list = [Stop.stop_name, Stop.stop_lat, Stop.stop_lon, Stop.routes]


class TripAdmin(ModelView, model=Trip):
    column_list = [Trip.trip_id, Trip.route_id, Trip.route, Trip.stop_times]
