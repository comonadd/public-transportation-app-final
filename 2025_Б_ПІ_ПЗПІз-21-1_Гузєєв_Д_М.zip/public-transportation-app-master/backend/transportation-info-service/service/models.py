from typing import List, Optional

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Table, Time
from sqlalchemy.orm import DeclarativeBase, Mapped, relationship


class Base(DeclarativeBase):
    pass


# Association tables
route_stop_association = Table(
    "route_stop_association",
    Base.metadata,
    Column("route_id", String, ForeignKey("routes.route_id")),
    Column("stop_id", String, ForeignKey("stops.stop_id")),
)


class Shape(Base):
    __tablename__ = "shapes"

    shape_id = Column(String, primary_key=True)
    trips: Mapped[List["Trip"]] = relationship("Trip", back_populates="shape")
    points: Mapped[List["ShapePoint"]] = relationship(
        "ShapePoint", back_populates="shape"
    )


class ShapePoint(Base):
    __tablename__ = "shape_points"

    id = Column(Integer, primary_key=True, autoincrement=True)
    shape_id = Column(String, ForeignKey("shapes.shape_id"), nullable=False)
    shape_pt_lat = Column(Float, nullable=False)
    shape_pt_lon = Column(Float, nullable=False)
    shape_pt_sequence = Column(Integer, nullable=False)
    shape_dist_traveled = Column(Float, nullable=True)

    shape: Mapped["Shape"] = relationship("Shape", back_populates="points")


class Agency(Base):
    __tablename__ = "agencies"

    agency_id = Column(String, primary_key=True)
    agency_name = Column(String, nullable=False)
    agency_url = Column(String, nullable=False)
    agency_timezone = Column(String, nullable=False)
    agency_lang = Column(String, nullable=True)
    agency_phone = Column(String, nullable=True)
    agency_fare_url = Column(String, nullable=True)

    routes: Mapped[List["Route"]] = relationship("Route", back_populates="agency")


class Stop(Base):
    __tablename__ = "stops"

    stop_id = Column(String, primary_key=True)
    stop_code = Column(String, nullable=True)
    stop_name = Column(String, nullable=False)
    stop_desc = Column(String, nullable=True)
    stop_lat = Column(Float, nullable=False)
    stop_lon = Column(Float, nullable=False)
    zone_id = Column(String, nullable=True)
    stop_url = Column(String, nullable=True)
    location_type = Column(Integer, nullable=True)
    parent_station = Column(String, nullable=True)
    stop_timezone = Column(String, nullable=True)
    wheelchair_boarding = Column(Integer, nullable=True)

    routes: Mapped[List["Route"]] = relationship(
        "Route", secondary=route_stop_association, back_populates="stops"
    )
    stop_times: Mapped[List["StopTime"]] = relationship(
        "StopTime", back_populates="stop"
    )


class Route(Base):
    __tablename__ = "routes"

    route_id = Column(String, primary_key=True)
    agency_id = Column(String, ForeignKey("agencies.agency_id"), nullable=True)
    route_short_name = Column(String, nullable=True)
    route_long_name = Column(String, nullable=True)
    route_desc = Column(String, nullable=True)
    route_type = Column(Integer, nullable=False)
    route_url = Column(String, nullable=True)
    route_color = Column(String, nullable=True)
    route_text_color = Column(String, nullable=True)
    route_sort_order = Column(Integer, nullable=True)

    agency: Mapped[Optional["Agency"]] = relationship("Agency", back_populates="routes")
    vehicles: Mapped[List["Vehicle"]] = relationship("Vehicle", back_populates="route")
    stops: Mapped[List["Stop"]] = relationship(
        "Stop", secondary=route_stop_association, back_populates="routes"
    )
    trips: Mapped[List["Trip"]] = relationship("Trip", back_populates="route")


class Trip(Base):
    __tablename__ = "trips"

    trip_id = Column(String, primary_key=True)
    route_id = Column(String, ForeignKey("routes.route_id"), nullable=False)
    service_id = Column(String, nullable=False)
    trip_headsign = Column(String, nullable=True)
    trip_short_name = Column(String, nullable=True)
    direction_id = Column(Integer, nullable=True)
    block_id = Column(String, nullable=True)
    shape_id = Column(String, ForeignKey("shapes.shape_id"), nullable=True)
    wheelchair_accessible = Column(Integer, nullable=True)
    bikes_allowed = Column(Integer, nullable=True)

    route: Mapped["Route"] = relationship("Route", back_populates="trips")
    stop_times: Mapped[List["StopTime"]] = relationship(
        "StopTime", back_populates="trip"
    )
    vehicles: Mapped[List["Vehicle"]] = relationship("Vehicle", back_populates="trip")
    shape: Mapped[Optional["Shape"]] = relationship("Shape", back_populates="trips")


class StopTime(Base):
    __tablename__ = "stop_times"

    trip_id = Column(String, ForeignKey("trips.trip_id"), primary_key=True)
    arrival_time = Column(Time, nullable=True)
    departure_time = Column(Time, nullable=True)
    stop_id = Column(String, ForeignKey("stops.stop_id"), primary_key=True)
    stop_sequence = Column(Integer, nullable=False)
    stop_headsign = Column(String, nullable=True)
    pickup_type = Column(Integer, nullable=True)
    drop_off_type = Column(Integer, nullable=True)
    shape_dist_traveled = Column(Float, nullable=True)
    timepoint = Column(Integer, nullable=True)

    trip: Mapped["Trip"] = relationship("Trip", back_populates="stop_times")
    stop: Mapped["Stop"] = relationship("Stop", back_populates="stop_times")


class Vehicle(Base):
    __tablename__ = "vehicles"

    vehicle_id = Column(String, primary_key=True)
    trip_id = Column(String, ForeignKey("trips.trip_id"), nullable=True)
    route_id = Column(String, ForeignKey("routes.route_id"), nullable=True)
    direction_id = Column(Integer, nullable=True)
    start_time = Column(Time, nullable=True)
    start_date = Column(String, nullable=True)
    schedule_relationship = Column(Integer, nullable=True)
    current_stop_sequence = Column(Integer, nullable=True)
    stop_id = Column(String, ForeignKey("stops.stop_id"), nullable=True)
    current_status = Column(Integer, nullable=True)
    timestamp = Column(DateTime, nullable=False)
    congestion_level = Column(Integer, nullable=True)
    occupancy_status = Column(Integer, nullable=True)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)

    route: Mapped[Optional["Route"]] = relationship("Route", back_populates="vehicles")
    trip: Mapped[Optional["Trip"]] = relationship("Trip", back_populates="vehicles")
    current_stop: Mapped[Optional["Stop"]] = relationship("Stop")
