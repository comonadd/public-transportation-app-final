import os
from pathlib import Path

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Base directory
BASE_DIR = Path(__file__).resolve().parent

# Database Configuration
DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    raise ValueError("DATABASE_URL is not set")

# Application Settings
APP_ENV = os.getenv("APP_ENV", "development")
DEBUG = os.getenv("DEBUG", "True").lower() == "true"

# API Settings
API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", "8000"))

# Vehicle Position Update Settings
VEHICLE_UPDATE_POSITION_CYCLE_LENGTH_SECONDS = int(
    os.getenv("VEHICLE_UPDATE_POSITION_CYCLE_LENGTH_SECONDS", "1")
)
VEHICLE_STOP_DURATION_SECONDS = int(os.getenv("VEHICLE_STOP_DURATION_SECONDS", "5"))
