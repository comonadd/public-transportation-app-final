from dataclasses import dataclass
from unittest.mock import patch

from pytest_cases import parametrize_with_cases
from service.models import Stop
from service.services.position_calculator import StopId
from service.services.stop_service import StopService


@dataclass
class Params:
    vehicle_position: tuple[float, float]
    stops: list[Stop]
    expected_stop_current_id: StopId | None
    expected_stop_next_id: StopId | None


class TestCases:
    def case_empty_stops(self):
        return Params(
            vehicle_position=(38.722778, -9.147977),
            stops=[],
            expected_stop_current_id=None,
            expected_stop_next_id=None,
        )

    def case_single_stop(self):
        return Params(
            vehicle_position=(38.722778, -9.147977),
            stops=[Stop(stop_id="stop1", stop_lat=38.720145, stop_lon=-9.1457228)],
            expected_stop_current_id=StopId("stop1"),
            expected_stop_next_id=StopId("stop1"),
        )

    def case_two_stops_after_one_another_close(self):
        return Params(
            vehicle_position=(38.722778, -9.147977),
            stops=[
                Stop(stop_id="stop1", stop_lat=38.720145, stop_lon=-9.1457228),
                Stop(stop_id="stop2", stop_lat=38.716316, stop_lon=-9.142379),
            ],
            expected_stop_current_id=StopId("stop1"),
            expected_stop_next_id=StopId("stop2"),
        )


@parametrize_with_cases("params", cases=TestCases)
def test_find_nearest_stop(mock_stop_service: StopService, params: Params):
    with patch.object(
        mock_stop_service,
        "get_route_stops_in_order",
    ) as get_route_stops_in_order_mock:
        vehicle_position = params.vehicle_position
        stops = params.stops
        expected_stop_current_id = params.expected_stop_current_id
        expected_stop_next_id = params.expected_stop_next_id
        get_route_stops_in_order_mock.return_value = stops
        stop_current, stop_next = mock_stop_service.find_closest_stop(
            vehicle_position[0], vehicle_position[1], "route1"
        )
        assert stop_current is not None
        assert stop_current.stop_id == expected_stop_current_id
        assert stop_next is not None
        assert stop_next.stop_id == expected_stop_next_id
