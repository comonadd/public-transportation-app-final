import sys
from pathlib import Path
from unittest.mock import Mock

import pytest
from pytest import fixture

from service.services.route_service import RouteService
from service.services.stop_service import StopService
from service.services.vehicle_position_service import VehiclePositionService
from service.services.vehicle_service import VehicleService

# Add the parent directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the app after adding the path
from fastapi.testclient import TestClient
from service.app import app


@fixture
def client():
    return TestClient(app)

@fixture
def mock_db():
    return Mock()


@fixture
def mock_vehicle_service(mock_db):
    service = VehicleService(mock_db)
    return service


@fixture
def mock_stop_service(mock_db):
    service = StopService(mock_db)
    return service


@fixture
def mock_route_service(mock_db):
    service = RouteService(mock_db)
    return service


@fixture
def vehicle_position_service(
    mock_db, mock_vehicle_service, mock_stop_service, mock_route_service
):
    return VehiclePositionService(
        db=mock_db,
        vehicle_service=mock_vehicle_service,
        stop_service=mock_stop_service,
        route_service=mock_route_service,
    )
