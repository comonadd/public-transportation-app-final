"""initial migration

Revision ID: initial_migration
Revises:
Create Date: 2024-03-21 12:00:00.000000

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "initial_migration"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create services table
    op.create_table(
        "services",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("api_base", sa.String(), nullable=False),
        sa.Column("fetched_vehicles_at", sa.DateTime(), nullable=True),
        sa.Column("fetched_routes_at", sa.DateTime(), nullable=True),
        sa.Column("fetched_stops_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_services_id"), "services", ["id"], unique=False)


def downgrade() -> None:
    # Drop services table
    op.drop_index(op.f("ix_services_id"), table_name="services")
    op.drop_table("services")
