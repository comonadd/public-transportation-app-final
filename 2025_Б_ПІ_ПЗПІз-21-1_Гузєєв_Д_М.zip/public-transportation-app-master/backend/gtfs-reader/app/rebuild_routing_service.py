import logging
from sqlalchemy.orm import Session
from sqlalchemy import text

logger = logging.getLogger(__name__)


class RebuildRoutingDataService:
    WALKING_PENALTY = 300
    TRANSFER_PENALTY = 600
    ROUTE_CHANGE_PENALTY = 900
    MAX_WALKING_DISTANCE = 600
    MIN_WALKING_DISTANCE = 30

    def __init__(self, db: Session):
        self.db = db

    def rebuild_routing_data(self):
        """Main entrypoint to rebuild routing data"""
        logger.info("Rebuilding routing data with optimized transfer reduction")

        try:
            self._preprocess_data()
            self._clear_existing_data()
            self._create_routing_nodes()
            self._create_strategic_walking_connections()
            self._create_routing_edges()
            self._create_optimized_transit_edges()
            self._create_station_transfers()
            self._apply_transfer_optimization()
            self._update_transfer_penalties()

            self.db.commit()
            logger.info("Successfully rebuilt routing data with transfer optimization")

        except Exception as e:
            logger.error(f"Error rebuilding routing data: {e}")
            self.db.rollback()
            raise

    def _preprocess_data(self):
        """Apply preprocessing updates to base tables"""
        logger.info("Preprocessing base data")

        preprocessing_queries = [
            "UPDATE stops SET is_active = true",
            "UPDATE stops SET location_type = 0",
            "UPDATE trips SET bikes_allowed = 1",
            "UPDATE stops SET wheelchair_boarding = 1 WHERE wheelchair_boarding IS NULL"
        ]

        for query in preprocessing_queries:
            self.db.execute(text(query))

    def _clear_existing_data(self):
        """Clear existing routing data"""
        logger.info("Clearing existing routing data")

        clear_queries = [
            "TRUNCATE routing_edges CASCADE",
            "TRUNCATE walking_connections CASCADE",
            "TRUNCATE routing_nodes CASCADE",
            "TRUNCATE expanded_timetable CASCADE"
        ]

        for query in clear_queries:
            self.db.execute(text(query))

    def _create_routing_nodes(self):
        """Create routing nodes from stops only (simplified)"""
        logger.info("Creating routing nodes")

        stop_nodes_query = text("""
            INSERT INTO routing_nodes (stop_id, node_type, geom, is_active)
            SELECT 
                stop_id,
                'stop',
                geometry,
                true
            FROM stops
            WHERE location_type = 0 
            AND geometry IS NOT NULL
            AND is_active = true
        """)

        self.db.execute(stop_nodes_query)

    def _create_strategic_walking_connections(self):
        logger.info("Creating strategic walking connections")

        walking_connections_query = text("""
            INSERT INTO walking_connections (
                from_stop_id, to_stop_id, walk_time, distance, geom
            )
            WITH route_connectivity AS (
                -- Find which routes serve each stop
                SELECT 
                    s.stop_id,
                    s.geometry,
                    array_agg(DISTINCT r.route_id) as served_routes,
                    COUNT(DISTINCT r.route_id) as route_count
                FROM stops s
                JOIN stop_times st ON s.stop_id = st.stop_id
                JOIN trips t ON st.trip_id = t.trip_id
                JOIN routes r ON t.route_id = r.route_id
                WHERE s.location_type = 0 AND s.geometry IS NOT NULL
                GROUP BY s.stop_id, s.geometry
            ),
            strategic_pairs AS (
                SELECT 
                    rc1.stop_id as from_stop,
                    rc2.stop_id as to_stop,
                    ST_Distance(rc1.geometry::geography, rc2.geometry::geography) as distance,
                    ST_MakeLine(rc1.geometry, rc2.geometry) as line_geom,
                    -- Check if connecting these stops creates new route combinations
                    CASE WHEN rc1.served_routes && rc2.served_routes THEN 0  -- Same routes = less valuable
                         ELSE 1 END as connectivity_value
                FROM route_connectivity rc1
                JOIN route_connectivity rc2 ON rc1.stop_id < rc2.stop_id
                WHERE ST_DWithin(rc1.geometry::geography, rc2.geometry::geography, :max_walk_distance)
                -- Prioritize connections between stops with different route sets
                AND NOT (rc1.served_routes && rc2.served_routes AND array_length(rc1.served_routes, 1) = 1)
            )
            SELECT 
                from_stop,
                to_stop,
                -- More realistic walking speed calculation
                GREATEST(90, (distance / 1.2))::INTEGER as walk_time,  -- 1.2 m/s walking speed
                distance,
                line_geom
            FROM strategic_pairs
            WHERE distance >= :min_walk_distance 
            AND distance <= :max_walk_distance
            -- Prefer connections that don't duplicate existing transit connectivity
            ORDER BY connectivity_value DESC, distance ASC
            LIMIT 50000  -- Limit total walking connections
        """)

        self.db.execute(walking_connections_query, {
            'max_walk_distance': self.MAX_WALKING_DISTANCE,
            'min_walk_distance': self.MIN_WALKING_DISTANCE
        })

    def _create_routing_edges(self):
        logger.info("Creating walking routing edges")

        walking_edges_query = text("""
            INSERT INTO routing_edges (
                source_node, target_node, edge_type, cost, distance, geom, 
                is_active, wheelchair_accessible, bike_allowed
            )
            SELECT 
                rn1.node_id,
                rn2.node_id,
                'walking',
                wc.walk_time,
                wc.distance,
                wc.geom,
                true,
                true,
                true
            FROM walking_connections wc
            JOIN routing_nodes rn1 ON wc.from_stop_id = rn1.stop_id
            JOIN routing_nodes rn2 ON wc.to_stop_id = rn2.stop_id

            UNION ALL

            -- Reverse direction
            SELECT 
                rn2.node_id,
                rn1.node_id,
                'walking',
                wc.walk_time,
                wc.distance,
                ST_Reverse(wc.geom),
                true,
                true,
                true
            FROM walking_connections wc
            JOIN routing_nodes rn1 ON wc.from_stop_id = rn1.stop_id
            JOIN routing_nodes rn2 ON wc.to_stop_id = rn2.stop_id
        """)

        self.db.execute(walking_edges_query)

    def _create_station_transfers(self):
        """Create automatic transfers for same-station stops"""
        logger.info("Creating station transfers")

        station_transfers_query = text("""
            INSERT INTO routing_edges (
                source_node, target_node, edge_type, cost, distance, is_active, geom
            )
            WITH station_transfers AS (
                SELECT 
                    s1.stop_id as from_stop,
                    s2.stop_id as to_stop,
                    GREATEST(30, COALESCE(s1.min_transfer_time, 0), COALESCE(s2.min_transfer_time, 0)) as transfer_time,
                    ST_Distance(s1.geometry::geography, s2.geometry::geography) as distance,
                    ST_MakeLine(s1.geometry, s2.geometry) as transfer_geom
                FROM stops s1
                JOIN stops s2 ON s1.parent_station = s2.parent_station
                WHERE s1.stop_id != s2.stop_id
                AND s1.parent_station IS NOT NULL
                AND s1.location_type = 0 AND s2.location_type = 0
                AND s1.geometry IS NOT NULL AND s2.geometry IS NOT NULL
            )
            SELECT 
                rn1.node_id,
                rn2.node_id,
                'transfer',
                st.transfer_time,
                st.distance,
                true,
                st.transfer_geom
            FROM station_transfers st
            JOIN routing_nodes rn1 ON st.from_stop = rn1.stop_id
            JOIN routing_nodes rn2 ON st.to_stop = rn2.stop_id
        """)

        self.db.execute(station_transfers_query)

    def _create_optimized_transit_edges(self):
        """Create transit edges with better multi-hop optimization"""
        logger.info("Creating optimized transit edges")

        # Create single-hop edges
        single_hop_query = text("""
            INSERT INTO routing_edges (
                source_node, target_node, edge_type, cost, distance,
                route_id, trip_id, valid_from, valid_to, service_id,
                wheelchair_accessible, is_active, bike_allowed, geom
            )
            WITH consecutive_stops AS (
                SELECT
                    st1.trip_id,
                    st1.stop_id as from_stop,
                    st2.stop_id as to_stop,
                    st1.departure_time,
                    st2.arrival_time,
                    EXTRACT(EPOCH FROM (st2.arrival_time - st1.departure_time)) as travel_seconds,
                    t.route_id,
                    t.service_id,
                    CASE WHEN t.wheelchair_accessible = 1 THEN true ELSE false END as wheelchair_ok
                FROM stop_times st1
                JOIN stop_times st2 ON st1.trip_id = st2.trip_id
                    AND st2.stop_sequence = st1.stop_sequence + 1
                JOIN trips t ON st1.trip_id = t.trip_id
                WHERE st1.departure_time IS NOT NULL
                    AND st2.arrival_time IS NOT NULL
                    AND st2.arrival_time > st1.departure_time
            )
            SELECT
                rn1.node_id,
                rn2.node_id,
                'transit',
                cs.travel_seconds,
                ST_Distance(s1.geometry::geography, s2.geometry::geography),
                cs.route_id,
                cs.trip_id,
                cs.departure_time,
                cs.arrival_time,
                cs.service_id,
                cs.wheelchair_ok,
                true,
                true,
                ST_MakeLine(s1.geometry, s2.geometry) as geom
            FROM consecutive_stops cs
            JOIN routing_nodes rn1 ON cs.from_stop = rn1.stop_id
            JOIN routing_nodes rn2 ON cs.to_stop = rn2.stop_id
            JOIN stops s1 ON cs.from_stop = s1.stop_id
            JOIN stops s2 ON cs.to_stop = s2.stop_id
            WHERE s1.geometry IS NOT NULL AND s2.geometry IS NOT NULL
        """)

        self.db.execute(single_hop_query)

        # Create optimized multi-hop edges with better discounting
        multi_hop_query = text("""
            INSERT INTO routing_edges (
                source_node, target_node, edge_type, cost, distance,
                route_id, trip_id, valid_from, valid_to, service_id,
                wheelchair_accessible, is_active, bike_allowed, geom
            )
            WITH multi_hop_paths AS (
                SELECT 
                    st1.trip_id,
                    st1.stop_id as from_stop,
                    st2.stop_id as to_stop,
                    st1.departure_time,
                    st2.arrival_time,
                    st2.stop_sequence - st1.stop_sequence as hop_count,
                    EXTRACT(EPOCH FROM (st2.arrival_time - st1.departure_time)) as travel_seconds,
                    t.route_id,
                    t.service_id,
                    CASE WHEN t.wheelchair_accessible = 1 THEN true ELSE false END as wheelchair_ok
                FROM stop_times st1
                JOIN stop_times st2 ON st1.trip_id = st2.trip_id 
                    AND st2.stop_sequence BETWEEN st1.stop_sequence + 2 AND st1.stop_sequence + 8  -- Up to 8 stops
                JOIN trips t ON st1.trip_id = t.trip_id
                WHERE st1.departure_time IS NOT NULL
                    AND st2.arrival_time IS NOT NULL
                    AND st2.arrival_time > st1.departure_time
            )
            SELECT
                rn1.node_id,
                rn2.node_id,
                'transit_express',  -- Better name
                -- Significant discount for staying on same route (reduces transfer incentive)
                GREATEST(60, mhp.travel_seconds - (mhp.hop_count * 45)), 
                ST_Distance(s1.geometry::geography, s2.geometry::geography),
                mhp.route_id,
                mhp.trip_id,
                mhp.departure_time,
                mhp.arrival_time,
                mhp.service_id,
                mhp.wheelchair_ok,
                true,
                true,
                ST_MakeLine(s1.geometry, s2.geometry) as geom
            FROM multi_hop_paths mhp
            JOIN routing_nodes rn1 ON mhp.from_stop = rn1.stop_id
            JOIN routing_nodes rn2 ON mhp.to_stop = rn2.stop_id
            JOIN stops s1 ON mhp.from_stop = s1.stop_id
            JOIN stops s2 ON mhp.to_stop = s2.stop_id
            WHERE s1.geometry IS NOT NULL AND s2.geometry IS NOT NULL
            AND mhp.hop_count >= 2  -- Only for multi-hop
            AND mhp.hop_count <= 7  -- Max 7 stops
            AND mhp.travel_seconds <= 2400  -- Max 40 minutes
        """)

        self.db.execute(multi_hop_query)

    def _apply_transfer_optimization(self):
        """Apply additional optimizations to reduce transfers - simplified for performance"""
        logger.info("Applying transfer optimization strategies (simplified)")

        # Much simpler and faster approach - just adjust existing edge costs
        route_optimization_query = text("""
            -- Simply give bonuses to longer transit segments (reduces transfer incentive)
            UPDATE routing_edges SET 
                cost = GREATEST(30, cost * 0.85)  -- 15% discount for express/multi-hop
            WHERE edge_type IN ('transit_express', 'transit_multi')
            AND cost > 300;  -- Only for longer segments

            -- Give small penalty to very short transit hops (encourages staying on route)
            UPDATE routing_edges SET 
                cost = cost + 60  -- 1 minute penalty
            WHERE edge_type = 'transit' 
            AND cost < 180;  -- Less than 3 minutes
        """)

        try:
            self.db.execute(route_optimization_query)
            logger.info("Applied simple transfer optimization bonuses")
        except Exception as e:
            logger.warning(f"Transfer optimization failed: {e}")

    def _calculate_transfer_costs(self):
        """Calculate transfer costs with balanced penalties"""
        logger.info("Calculating balanced transfer costs")

        alter_table_query = text("""
            ALTER TABLE routing_edges 
            ADD COLUMN IF NOT EXISTS base_cost INTEGER,
            ADD COLUMN IF NOT EXISTS transfer_penalty INTEGER DEFAULT 0;

            -- Store original costs and apply REDUCED penalties
            UPDATE routing_edges SET 
                base_cost = CASE WHEN base_cost IS NULL THEN cost ELSE base_cost END,
                transfer_penalty = CASE 
                    WHEN edge_type = 'walking' THEN :walking_penalty
                    WHEN edge_type = 'transfer' THEN :transfer_penalty  
                    WHEN edge_type = 'route_continuation' THEN -50  -- Bonus for route continuation
                    ELSE 0
                END,
                cost = CASE 
                    WHEN edge_type = 'walking' THEN cost + :walking_penalty
                    WHEN edge_type = 'transfer' THEN cost + :transfer_penalty
                    WHEN edge_type = 'route_continuation' THEN GREATEST(10, cost - 50)  -- Apply bonus
                    ELSE cost
                END;
        """)

        self.db.execute(alter_table_query, {
            'walking_penalty': self.WALKING_PENALTY,
            'transfer_penalty': self.TRANSFER_PENALTY
        })

        # Create performance indexes
        create_indexes_query = text("""
            CREATE INDEX IF NOT EXISTS idx_routing_edges_active_cost ON routing_edges(cost) WHERE is_active = true;
            CREATE INDEX IF NOT EXISTS idx_routing_edges_type_route ON routing_edges(edge_type, route_id) WHERE is_active = true;
            CREATE INDEX IF NOT EXISTS idx_routing_edges_nodes ON routing_edges(source_node, target_node);
            CREATE INDEX IF NOT EXISTS idx_routing_nodes_stop ON routing_nodes(stop_id) WHERE stop_id IS NOT NULL;
        """)
        self.db.execute(create_indexes_query)

    def _update_transfer_penalties(self):
        """Update transfer penalties using the PostgreSQL function"""
        logger.info(f"Updating balanced penalties: Walking={self.WALKING_PENALTY}s, Transfer={self.TRANSFER_PENALTY}s")

        update_penalties_query = text("""
            UPDATE routing_edges SET
                transfer_penalty = CASE
                    WHEN edge_type = 'walking' THEN :walking_penalty
                    WHEN edge_type = 'transfer' THEN :transfer_penalty
                    WHEN edge_type = 'route_continuation' THEN -50
                    ELSE 0
                END,
                cost = base_cost + CASE
                    WHEN edge_type = 'walking' THEN :walking_penalty
                    WHEN edge_type = 'transfer' THEN :transfer_penalty
                    WHEN edge_type = 'route_continuation' THEN -50
                    ELSE 0
                END
            WHERE base_cost IS NOT NULL;
        """)

        self.db.execute(update_penalties_query, {
            'walking_penalty': self.WALKING_PENALTY,
            'transfer_penalty': self.TRANSFER_PENALTY
        })
