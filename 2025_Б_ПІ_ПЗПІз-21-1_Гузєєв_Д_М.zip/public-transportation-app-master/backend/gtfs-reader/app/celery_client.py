import os

from celery import Celery  # type: ignore

redis_url = os.getenv("REDIS_URL")
if redis_url is None:
    raise ValueError("REDIS_URL is not set")

# Initialize Celery
celery_app = Celery(  # type: ignore
    "gtfs_reader",
    broker=redis_url,
    backend=redis_url,
    include=["app.tasks"],
)

# Configure Celery
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=3600,  # 1 hour
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=100,
    broker_connection_retry_on_startup=True,
)
