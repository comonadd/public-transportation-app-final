import datetime
from enum import Enum
from typing import List, Optional

from geoalchemy2 import Geometry
from sqlalchemy import INTEGER, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Table, Time, Index, \
    Interval, Numeric, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, relationship

from .base import Base

# Association tables
route_stop_association = Table(
    "route_stop_association",
    Base.metadata,
    Column("route_id", String, ForeignKey("routes.route_id")),
    Column("stop_id", String, ForeignKey("stops.stop_id")),
)


class Shape(Base):
    __tablename__ = "shapes"

    shape_id = Column(String, primary_key=True)
    trips: Mapped[List["Trip"]] = relationship("Trip", back_populates="shape")
    geometry = Column(Geometry(geometry_type="LINESTRING", srid=4326), nullable=False)


class Agency(Base):
    __tablename__ = "agencies"

    agency_id = Column(String, primary_key=True)
    agency_name = Column(String, nullable=False)
    agency_url = Column(String, nullable=False)
    agency_timezone = Column(String, nullable=False)
    agency_lang = Column(String, nullable=True)
    agency_phone = Column(String, nullable=True)
    agency_fare_url = Column(String, nullable=True)

    routes: Mapped[List["Route"]] = relationship("Route", back_populates="agency")


class Calendar(Base):
    __tablename__ = "calendar"

    service_id= Column(String, primary_key=True)
    monday= Column(INTEGER, nullable=False)
    tuesday = Column(INTEGER, nullable=False)
    wednesday = Column(INTEGER, nullable=False)
    thursday = Column(INTEGER, nullable=False)
    friday = Column(INTEGER, nullable=False)
    saturday = Column(INTEGER, nullable=False)
    sunday = Column(INTEGER, nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)


class Stop(Base):
    __tablename__ = "stops"

    stop_id = Column(String, primary_key=True)
    stop_code = Column(String, nullable=True)
    stop_name = Column(String, nullable=False)
    stop_desc = Column(String, nullable=True)
    zone_id = Column(String, nullable=True)
    stop_url = Column(String, nullable=True)
    location_type = Column(Integer, nullable=True)
    parent_station = Column(String, nullable=True)
    stop_timezone = Column(String, nullable=True)
    wheelchair_boarding = Column(Integer, nullable=True)
    geometry = Column(Geometry(geometry_type="POINT", srid=4326), nullable=False)
    is_active = Column(Boolean, nullable=True, default=True)

    routes: Mapped[List["Route"]] = relationship(
        "Route", secondary=route_stop_association, back_populates="stops"
    )
    stop_times: Mapped[List["StopTime"]] = relationship(
        "StopTime", back_populates="stop"
    )

    incoming_walking_connections = relationship(
        "WalkingConnection",
        foreign_keys="WalkingConnection.to_stop_id",
        back_populates="to_stop"
    )
    outgoing_walking_connections = relationship(
        "WalkingConnection",
        foreign_keys="WalkingConnection.from_stop_id",
        back_populates="from_stop"
    )
    outgoing_transfers = relationship(
        "Transfer",
        foreign_keys="Transfer.from_stop_id",
        back_populates="from_stop",
    )
    incoming_transfers = relationship(
        "Transfer",
        foreign_keys="Transfer.to_stop_id",
        back_populates="to_stop",
    )

    min_transfer_time = Column(Integer, default=120)
    walking_radius = Column(Integer, default=500)


class Route(Base):
    __tablename__ = "routes"

    route_id = Column(String, primary_key=True)
    agency_id = Column(String, ForeignKey("agencies.agency_id"), nullable=True)
    route_short_name = Column(String, nullable=True)
    route_long_name = Column(String, nullable=True)
    route_desc = Column(String, nullable=True)
    route_type = Column(Integer, nullable=False)
    route_url = Column(String, nullable=True)
    route_color = Column(String, nullable=True)
    route_text_color = Column(String, nullable=True)
    route_sort_order = Column(Integer, nullable=True)
    geometry = Column(Geometry(geometry_type="LINESTRING", srid=4326), nullable=False)

    agency: Mapped[Optional["Agency"]] = relationship("Agency", back_populates="routes")
    stops: Mapped[List["Stop"]] = relationship(
        "Stop", secondary=route_stop_association, back_populates="routes"
    )
    trips: Mapped[List["Trip"]] = relationship("Trip", back_populates="route")

    route_patterns = relationship("RoutePattern", back_populates="route")
    expanded_timetable_entries = relationship("ExpandedTimetable", back_populates="route")

class Trip(Base):
    __tablename__ = "trips"

    trip_id = Column(String, primary_key=True)
    route_id = Column(String, ForeignKey("routes.route_id"), nullable=False)
    service_id = Column(String, nullable=False)
    trip_headsign = Column(String, nullable=True)
    trip_short_name = Column(String, nullable=True)
    direction_id = Column(Integer, nullable=True)
    block_id = Column(String, nullable=True)
    shape_id = Column(String, ForeignKey("shapes.shape_id"), nullable=True)
    wheelchair_accessible = Column(Integer, nullable=True)
    bikes_allowed = Column(Integer, nullable=False, default=1)
    geometry = Column(Geometry(geometry_type="LINESTRING", srid=4326), nullable=False)

    route: Mapped["Route"] = relationship("Route", back_populates="trips")
    stop_times: Mapped[List["StopTime"]] = relationship(
        "StopTime", back_populates="trip"
    )
    shape: Mapped[Optional["Shape"]] = relationship("Shape", back_populates="trips")
    expanded_timetable_entries = relationship("ExpandedTimetable", back_populates="trip")


class StopTime(Base):
    __tablename__ = "stop_times"

    trip_id = Column(String, ForeignKey("trips.trip_id"), primary_key=True)
    arrival_time = Column(Time, nullable=True)
    departure_time = Column(Time, nullable=True)
    stop_id = Column(String, ForeignKey("stops.stop_id"), primary_key=True)
    stop_sequence = Column(Integer, nullable=False)
    stop_headsign = Column(String, nullable=True)
    pickup_type = Column(Integer, nullable=True)
    drop_off_type = Column(Integer, nullable=True)
    shape_dist_traveled = Column(Float, nullable=True)
    timepoint = Column(Integer, nullable=True)

    trip: Mapped["Trip"] = relationship("Trip", back_populates="stop_times")
    stop: Mapped["Stop"] = relationship("Stop", back_populates="stop_times")


class NodeType(str, Enum):
    STOP = "stop"
    VIRTUAL = "virtual"
    TRANSFER = "transfer"
    STATION_HUB = "station_hub"
    TRANSFER_HUB = "transfer_hub"


class EdgeType(str, Enum):
    TRANSIT = "transit"
    WALKING = "walking"
    TRANSFER = "transfer"


class RoutingNode(Base):
    __tablename__ = "routing_nodes"

    node_id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
        comment="Auto-incrementing primary key"
    )

    stop_id = Column(
        String(50),
        ForeignKey("stops.stop_id"),
        nullable=True,
        comment="Referenced stop ID, NULL for virtual nodes"
    )

    node_type = Column(
        String(20),
        nullable=False,
        comment="Type of node: stop, virtual, transfer, etc."
    )

    geom = Column(
        Geometry('POINT', srid=4326),
        nullable=False,
        comment="Point geometry in WGS84 (EPSG:4326)"
    )

    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        comment="Whether this node is currently active for routing"
    )

    stop = relationship("Stop")
    source_edges = relationship(
        "RoutingEdge",
        back_populates="source_node_rel",
        foreign_keys="RoutingEdge.source_node"
    )
    target_edges = relationship(
        "RoutingEdge",
        back_populates="target_node_rel",
        foreign_keys="RoutingEdge.target_node"
    )

    __table_args__ = (
        Index('idx_routing_nodes_geom', 'geom', postgresql_using='gist'),
        Index('idx_routing_nodes_stop_id', 'stop_id'),
        Index('idx_routing_nodes_type', 'node_type'),
        Index('idx_routing_nodes_active', 'is_active'),
    )

    def __repr__(self):
        return f"<RoutingNode(node_id={self.node_id}, type={self.node_type}, stop_id={self.stop_id})>"


class RoutingEdge(Base):
    __tablename__ = "routing_edges"

    edge_id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
        comment="Auto-incrementing primary key"
    )

    source_node = Column(
        Integer,
        ForeignKey("routing_nodes.node_id"),
        nullable=False,
        comment="Source node ID"
    )

    target_node = Column(
        Integer,
        ForeignKey("routing_nodes.node_id"),
        nullable=False,
        comment="Target node ID"
    )

    edge_type = Column(
        String(20),
        nullable=False,
        comment="Type of edge: transit, walking, transfer"
    )

    cost = Column(
        Numeric(10, 2),
        nullable=False,
        comment="Travel time in seconds"
    )

    distance = Column(
        Numeric(10, 2),
        nullable=True,
        comment="Distance in meters"
    )

    route_id = Column(
        String(50),
        ForeignKey("routes.route_id"),
        nullable=True,
        comment="Associated route ID for transit edges"
    )

    trip_id = Column(
        String(50),
        ForeignKey("trips.trip_id"),
        nullable=True,
        comment="Associated trip ID for transit edges"
    )

    valid_from = Column(
        Interval,
        nullable=True,
        comment="Time of day when edge becomes valid"
    )

    valid_to = Column(
        Interval,
        nullable=True,
        comment="Time of day when edge expires"
    )

    service_id = Column(
        String(50),
        nullable=True,
        comment="Service ID for calendar/schedule references"
    )

    wheelchair_accessible = Column(
        Boolean,
        default=True,
        nullable=False,
        comment="Whether edge is wheelchair accessible"
    )

    bike_allowed = Column(
        Boolean,
        default=False,
        nullable=False,
        comment="Whether bikes are allowed on this edge"
    )

    geom = Column(
        Geometry('LINESTRING', srid=4326),
        nullable=True,
        comment="LineString geometry for walking paths"
    )

    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        comment="Whether this edge is currently active for routing"
    )

    source_node_rel = relationship(
        "RoutingNode",
        back_populates="source_edges",
        foreign_keys=[source_node]
    )
    target_node_rel = relationship(
        "RoutingNode",
        back_populates="target_edges",
        foreign_keys=[target_node]
    )
    route = relationship("Route")
    trip = relationship("Trip")

    __table_args__ = (
        Index('idx_routing_edges_source', 'source_node'),
        Index('idx_routing_edges_target', 'target_node'),
        Index('idx_routing_edges_type', 'edge_type'),
        Index('idx_routing_edges_active', 'is_active'),
        Index('idx_routing_edges_route', 'route_id'),
        Index('idx_routing_edges_service', 'service_id'),
        Index('idx_routing_edges_time', 'valid_from', 'valid_to'),
        Index('idx_routing_edges_geom', 'geom', postgresql_using='gist'),
        Index('idx_routing_edges_service_time', 'service_id', 'valid_from', 'valid_to'),
        Index('idx_routing_edges_cost', 'cost'),
    )

    def __repr__(self):
        return f"<RoutingEdge(edge_id={self.edge_id}, type={self.edge_type}, {self.source_node}->{self.target_node})>"


class TransferType(int, Enum):
    RECOMMENDED = 0      # Recommended transfer point
    TIMED = 1           # Timed transfer (coordinated schedules)
    MIN_TIME = 2        # Minimum time required
    NOT_POSSIBLE = 3    # Transfer not possible


class AccessibilityRating(int, Enum):
    UNKNOWN = 0
    ACCESSIBLE = 1
    DIFFICULT = 2


class WalkingConnection(Base):
    __tablename__ = "walking_connections"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
        comment="Auto-incrementing primary key"
    )

    from_stop_id = Column(
        String(50),
        ForeignKey("stops.stop_id"),
        nullable=False,
        comment="Origin stop ID"
    )

    to_stop_id = Column(
        String(50),
        ForeignKey("stops.stop_id"),
        nullable=False,
        comment="Destination stop ID"
    )

    walk_time = Column(
        Integer,
        nullable=False,
        comment="Walking time in seconds"
    )

    distance = Column(
        Numeric(8, 2),
        nullable=False,
        comment="Walking distance in meters"
    )

    geom = Column(
        Geometry('LINESTRING', srid=4326),
        nullable=True,
        comment="Walking path geometry"
    )

    accessibility_rating = Column(
        Integer,
        default=0,
        comment="0=unknown, 1=accessible, 2=difficult"
    )

    created_at = Column(
        DateTime,
        default=datetime.datetime.utcnow,
        comment="Record creation timestamp"
    )

    # Relationships
    from_stop = relationship("Stop", foreign_keys=[from_stop_id], back_populates="outgoing_walking_connections")
    to_stop = relationship("Stop", foreign_keys=[to_stop_id], back_populates="incoming_walking_connections")

    # Constraints and Indexes
    __table_args__ = (
        UniqueConstraint('from_stop_id', 'to_stop_id', name='uq_walking_connection_stops'),
        Index('idx_walking_connections_geom', 'geom', postgresql_using='gist'),
        Index('idx_walking_from_stop', 'from_stop_id'),
        Index('idx_walking_to_stop', 'to_stop_id'),
        Index('idx_walking_time', 'walk_time'),
        Index('idx_walking_distance', 'distance'),
        Index('idx_walking_accessibility', 'accessibility_rating'),
    )

    def __repr__(self):
        return f"<WalkingConnection(id={self.id}, {self.from_stop_id}->{self.to_stop_id}, {self.walk_time}s)>"


class Transfer(Base):
    __tablename__ = "transfers"

    from_stop_id = Column(
        String(50),
        ForeignKey("stops.stop_id"),
        primary_key=True,
        comment="Origin stop ID"
    )

    to_stop_id = Column(
        String(50),
        ForeignKey("stops.stop_id"),
        primary_key=True,
        comment="Destination stop ID"
    )

    transfer_type = Column(
        Integer,
        nullable=False,
        default=0,
        comment="0=recommended, 1=timed, 2=min_time, 3=not_possible"
    )

    min_transfer_time = Column(
        Integer,
        nullable=True,
        comment="Minimum transfer time in seconds"
    )

    from_route_id = Column(
        String(50),
        ForeignKey("routes.route_id"),
        nullable=True,
        comment="Specific route for origin"
    )

    to_route_id = Column(
        String(50),
        ForeignKey("routes.route_id"),
        nullable=True,
        comment="Specific route for destination"
    )

    from_trip_id = Column(
        String(50),
        ForeignKey("trips.trip_id"),
        nullable=True,
        comment="Specific trip for origin"
    )

    to_trip_id = Column(
        String(50),
        ForeignKey("trips.trip_id"),
        nullable=True,
        comment="Specific trip for destination"
    )

    # Relationships
    from_stop = relationship("Stop", foreign_keys=[from_stop_id], back_populates="outgoing_transfers")
    to_stop = relationship("Stop", foreign_keys=[to_stop_id], back_populates="incoming_transfers")
    from_route = relationship("Route", foreign_keys=[from_route_id])
    to_route = relationship("Route", foreign_keys=[to_route_id])
    from_trip = relationship("Trip", foreign_keys=[from_trip_id])
    to_trip = relationship("Trip", foreign_keys=[to_trip_id])

    # Indexes
    __table_args__ = (
        Index('idx_transfers_from_stop', 'from_stop_id'),
        Index('idx_transfers_to_stop', 'to_stop_id'),
        Index('idx_transfers_type', 'transfer_type'),
        Index('idx_transfers_from_route', 'from_route_id'),
        Index('idx_transfers_to_route', 'to_route_id'),
        Index('idx_transfers_min_time', 'min_transfer_time'),
    )

    def __repr__(self):
        return f"<Transfer({self.from_stop_id}->{self.to_stop_id}, type={self.transfer_type})>"


class ExpandedTimetable(Base):
    __tablename__ = "expanded_timetable"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
        comment="Auto-incrementing primary key"
    )

    trip_id = Column(
        String(50),
        ForeignKey("trips.trip_id"),
        nullable=False,
        comment="Trip ID"
    )

    from_stop_id = Column(
        String(50),
        ForeignKey("stops.stop_id"),
        nullable=False,
        comment="Origin stop ID"
    )

    to_stop_id = Column(
        String(50),
        ForeignKey("stops.stop_id"),
        nullable=False,
        comment="Destination stop ID"
    )

    departure_time = Column(
        Interval,
        nullable=False,
        comment="Departure time from origin stop"
    )

    arrival_time = Column(
        Interval,
        nullable=False,
        comment="Arrival time at destination stop"
    )

    travel_time = Column(
        Integer,
        nullable=False,
        comment="Travel time in seconds"
    )

    stop_sequence = Column(
        Integer,
        nullable=False,
        comment="Stop sequence number in trip"
    )

    service_id = Column(
        String(50),
        nullable=False,
        comment="Service ID for calendar reference"
    )

    route_id = Column(
        String(50),
        ForeignKey("routes.route_id"),
        nullable=False,
        comment="Route ID"
    )

    # Relationships
    trip = relationship("Trip", back_populates="expanded_timetable_entries")
    from_stop = relationship("Stop", foreign_keys=[from_stop_id])
    to_stop = relationship("Stop", foreign_keys=[to_stop_id])
    route = relationship("Route", back_populates="expanded_timetable_entries")

    # Indexes for performance
    __table_args__ = (
        Index('idx_expanded_timetable_lookup', 'from_stop_id', 'departure_time', 'service_id'),
        Index('idx_expanded_timetable_trip', 'trip_id'),
        Index('idx_expanded_timetable_route', 'route_id'),
        Index('idx_expanded_timetable_service', 'service_id'),
        Index('idx_expanded_timetable_departure', 'departure_time'),
        Index('idx_expanded_timetable_from_stop', 'from_stop_id'),
        Index('idx_expanded_timetable_to_stop', 'to_stop_id'),
        Index('idx_expanded_timetable_sequence', 'trip_id', 'stop_sequence'),
    )

    def __repr__(self):
        return f"<ExpandedTimetable(id={self.id}, {self.from_stop_id}->{self.to_stop_id}, trip={self.trip_id})>"


class RoutePattern(Base):
    __tablename__ = "route_patterns"

    pattern_id = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
        comment="Auto-incrementing primary key"
    )

    route_id = Column(
        String(50),
        ForeignKey("routes.route_id"),
        nullable=False,
        comment="Associated route ID"
    )

    direction_id = Column(
        Integer,
        nullable=True,
        comment="Direction ID (0 or 1)"
    )

    pattern_name = Column(
        String(255),
        nullable=True,
        comment="Human-readable pattern name"
    )

    stop_sequence = Column(
        JSONB,
        nullable=False,
        comment="Array of stop_ids in order"
    )

    geom = Column(
        Geometry('LINESTRING', srid=4326),
        nullable=True,
        comment="Route pattern geometry"
    )

    is_active = Column(
        Boolean,
        default=True,
        comment="Whether this pattern is currently active"
    )

    # Relationships
    route = relationship("Route", back_populates="route_patterns")

    # Indexes
    __table_args__ = (
        Index('idx_route_patterns_route', 'route_id'),
        Index('idx_route_patterns_direction', 'direction_id'),
        Index('idx_route_patterns_active', 'is_active'),
        Index('idx_route_patterns_geom', 'geom', postgresql_using='gist'),
        Index('idx_route_patterns_stop_sequence', 'stop_sequence', postgresql_using='gin'),
    )

    def __repr__(self):
        return f"<RoutePattern(pattern_id={self.pattern_id}, route={self.route_id}, direction={self.direction_id})>"
