from sqlalchemy import Column, DateTime, String

from .base import BaseModel


class Service(BaseModel):
    __tablename__ = "services"

    name = Column(String, nullable=False)
    api_base = Column(String, nullable=False)
    routes_fetched_at = Column(DateTime, nullable=False)
    stops_fetched_at = Column(DateTime, nullable=False)
    vehicles_fetched_at = Column(DateTime, nullable=False)
    trips_fetched_at = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<Service(routes_fetched_at={self.routes_fetched_at}, stops_fetched_at={self.stops_fetched_at}, vehicles_fetched_at={self.vehicles_fetched_at}, trips_fetched_at={self.trips_fetched_at})>"
