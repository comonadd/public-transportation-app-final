import asyncio
from datetime import datetime, timedelta

import aiohttp
import structlog
from aiokafka import AIOKafkaProducer  # type: ignore
from pydantic import BaseModel
from typing import Optional
from datetime import time
from app.models.service import Service
from sqlalchemy.orm import Session

logger = structlog.get_logger(__name__)

ROUTES_FETCH_INTERVAL = timedelta(days=7)
STOPS_FETCH_INTERVAL = timedelta(days=7)
VEHICLES_FETCH_INTERVAL = timedelta(seconds=5)

class VehicleResponse(BaseModel):
    vehicle_id: str
    trip_id: Optional[str] = None
    route_id: Optional[str] = None
    direction_id: Optional[int] = None
    start_time: Optional[time] = None
    start_date: Optional[str] = None
    schedule_relationship: Optional[int] = None
    current_stop_sequence: Optional[int] = None
    stop_id: Optional[str] = None
    current_status: Optional[int] = None
    timestamp: datetime
    congestion_level: Optional[int] = None
    occupancy_status: Optional[int] = None
    latitude: float
    longitude: float

    class Config:
        from_attributes = True


class ServiceUpdater:
    def __init__(self, db: Session, kafka_producer: AIOKafkaProducer):
        self.db = db
        self.is_running = False
        self.kafka_producer = kafka_producer

    async def update_loop(self):
        services = self.db.query(Service).all()
        while self.is_running:
            for service in services:
                await self.update_service(service)
            await asyncio.sleep(1)

    async def update_service(self, service: Service):
        now = datetime.now()
        if (
            service.vehicles_fetched_at is None
            or now - service.vehicles_fetched_at > VEHICLES_FETCH_INTERVAL
        ):
            await self.fetch_vehicles(service)

    async def fetch_vehicles(self, service: Service):
        try:
            logger.info(
                "Fetching vehicles", service_id=service.id, service_name=service.name
            )
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{service.api_base}/api/v1/vehicles",
                    headers={"Content-Type": "application/json"},
                ) as response:
                    vehicles = await response.json()
                    logger.info(
                        "Vehicles response", num_vehicles=len(vehicles), service_id=service.id, service_name=service.name
                    )
                    for vehicle in vehicles:
                        vehicle_model = VehicleResponse(**vehicle)
                        await self.kafka_producer.send(
                            "vehicles",
                            key=vehicle_model.vehicle_id.encode("utf-8"),
                            value=vehicle_model.model_dump_json().encode("utf-8"),
                        )
            service.vehicles_fetched_at = datetime.now()  # type: ignore
            self.db.commit()
        except Exception as e:
            logger.error("Error fetching vehicles", service=service, error=e)

    async def start(self):
        logger.info("Starting service updater")
        self.is_running = True
        asyncio.create_task(self.update_loop())

    async def stop(self):
        logger.info("Stopping service updater")
        self.is_running = False
