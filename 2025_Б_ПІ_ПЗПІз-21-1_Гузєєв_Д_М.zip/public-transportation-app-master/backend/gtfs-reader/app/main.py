import os
from contextlib import asynccontextmanager
from typing import Any

import structlog
from aiokafka import AIOKafkaProducer  # type: ignore
from sqlalchemy import text
from starlette import status

from app.admin import setup_admin_for_app
from app.db import engine, get_db
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session

from app.service_updater import ServiceUpdater

# Load environment variables
load_dotenv()

# Kafka configuration
KAFKA_BROKER = os.getenv("KAFKA_BROKER", "kafka:9092")

# Kafka producer
producer = None

logger = structlog.get_logger(__name__)

service_updater = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global producer
    producer = AIOKafkaProducer(bootstrap_servers=KAFKA_BROKER)
    await producer.start()
    db = next(get_db())
    global service_updater
    service_updater = ServiceUpdater(db, producer)
    await service_updater.start()
    yield
    await producer.stop()
    await service_updater.stop()
    db.close()


app = FastAPI(title="GTFS Reader Service", lifespan=lifespan)
setup_admin_for_app(app, engine)

@app.get("/health")
async def health_check(db: Session = Depends(get_db)) -> dict[str, Any]:
    """
    Comprehensive health check endpoint that verifies:
    - Database connectivity
    - Kafka producer status
    - Service updater status
    """

    health_status: dict = {
        "status": "healthy",
        "service": "GTFS Reader Service",
        "checks": {}
    }

    overall_healthy = True

    try:
        db.execute(text("SELECT 1"))
        health_status["checks"]["database"] = {
            "status": "healthy",
            "message": "Database connection successful"
        }
    except Exception as e:
        overall_healthy = False
        health_status["checks"]["database"] = {
            "status": "unhealthy",
            "message": f"Database connection failed: {str(e)}"
        }
        logger.error("Database health check failed", error=str(e))

    try:
        if producer is None:
            raise Exception("Kafka producer not initialized")

        health_status["checks"]["kafka"] = {
            "status": "healthy",
            "message": "Kafka producer is running",
            "broker": KAFKA_BROKER
        }
    except Exception as e:
        overall_healthy = False
        health_status["checks"]["kafka"] = {
            "status": "unhealthy",
            "message": f"Kafka producer check failed: {str(e)}",
            "broker": KAFKA_BROKER
        }
        logger.error("Kafka health check failed", error=str(e))

    try:
        if service_updater is None:
            raise Exception("Service updater not initialized")

        health_status["checks"]["service_updater"] = {
            "status": "healthy",
            "message": "Service updater is running"
        }
    except Exception as e:
        overall_healthy = False
        health_status["checks"]["service_updater"] = {
            "status": "unhealthy",
            "message": f"Service updater check failed: {str(e)}"
        }
        logger.error("Service updater health check failed", error=str(e))

    if not overall_healthy:
        health_status["status"] = "unhealthy"
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=health_status
        )

    return health_status