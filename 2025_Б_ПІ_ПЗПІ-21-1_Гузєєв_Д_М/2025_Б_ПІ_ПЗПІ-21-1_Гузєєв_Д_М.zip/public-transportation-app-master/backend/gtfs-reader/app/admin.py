import uuid
from pathlib import Path

import structlog
from fastapi import HTTPException
from sqladmin import BaseView, ModelView, expose, Admin
from starlette.requests import Request
from starlette.responses import RedirectResponse

from app.models import Service, Route, Stop, Trip
from app.tasks import import_gtfs_static, rebuild_routing_data

logger = structlog.get_logger(__name__)


class ServiceAdmin(ModelView, model=Service):
    column_list = [
        Service.id,
        Service.name,
        Service.routes_fetched_at,
        Service.stops_fetched_at,
        Service.vehicles_fetched_at,
    ]


class RouteAdmin(ModelView, model=Route):
    column_list = [  # type: ignore
        Route.route_id,
        Route.route_long_name,
        Route.route_desc,
        Route.route_color,
        Route.stops,
    ]


class StopAdmin(ModelView, model=Stop):
    column_list = [Stop.stop_name, Stop.routes]


class TripAdmin(ModelView, model=Trip):
    column_list = [Trip.trip_id, Trip.route_id, Trip.route, Trip.stop_times]


class ImportGTFSStaticAdmin(BaseView):
    name = "Import GTFS Static Data"
    icon = "fa-solid fa-chart-line"

    @expose("/import-gtfs-static", methods=["GET", "POST"])
    async def report_page(self, request: Request):
        if request.method == "GET":
            return await self.templates.TemplateResponse(
                request, "import_gtfs_static.html"
            )

        if request.method == "POST":
            logger.info("Received POST request")
            # Get the file from request here (field name is gtfs_file)
            form_data = await request.form()
            file = form_data.get("gtfs_file")
            agency_id = form_data.get("agency_id")
            # Parse file zip into JSON-serializable object
            if file is None:
                raise HTTPException(status_code=400, detail="File is required")

            if isinstance(file, str):
                raise HTTPException(status_code=400, detail="File is not a valid file")

            # Put file into the file system
            file_content = await file.read()
            file_name = f"gtfs_static_{str(uuid.uuid4())}.zip"
            fs_path = Path(f"/tmp/{file_name}")
            logger.info(f"Writing file to {fs_path}")
            fs_path.write_bytes(file_content)
            import_gtfs_static.delay(  # type: ignore
                str(fs_path),
            )
            return await self.templates.TemplateResponse(
                request, "import_gtfs_static_result.html"
            )

class RebuildRoutingData(BaseView):
    name = "Re-build Routing Data"
    icon = "fa-solid fa-refresh"

    @expose("/rebuild-routing", methods=["GET", "POST"])
    async def rebuild_routing_page(self, request: Request):
        if request.method == "GET":
            return await self.templates.TemplateResponse(
                request, "rebuild_routing.html"
            )

        logger.info("Received request for rebuilding routing data")

        if request.method == "POST":
            logger.info("Received POST request for rebuilding routing data")
            rebuild_routing_data.delay()
            return await self.templates.TemplateResponse(
                request, "rebuild_routing_data_started.html"
            )

def setup_admin_for_app(app, engine):
    admin = Admin(app, engine, templates_dir="./app/admin_templates")
    admin.add_view(ImportGTFSStaticAdmin)
    admin.add_view(RebuildRoutingData)
    admin.add_view(ServiceAdmin)
    admin.add_view(RouteAdmin)
    admin.add_view(StopAdmin)
    admin.add_view(TripAdmin)
