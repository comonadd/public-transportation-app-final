import os

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Load environment variables
load_dotenv()

# Database configuration
POSTGRES_URL = os.getenv("DATABASE_URL")

if POSTGRES_URL is None:
    raise ValueError("DATABASE_URL is not set")

# Database URL
SQLALCHEMY_DATABASE_URL = POSTGRES_URL.strip()

# Create database engine
engine = create_engine(SQLALCHEMY_DATABASE_URL, plugins=["geoalchemy2"])
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
