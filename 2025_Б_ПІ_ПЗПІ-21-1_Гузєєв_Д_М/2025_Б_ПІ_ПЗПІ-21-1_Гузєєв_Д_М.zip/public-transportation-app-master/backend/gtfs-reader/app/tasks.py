import structlog
from sqlalchemy.orm import Session

from app.celery_client import celery_app
from app.db import get_db
from pathlib import Path

import tempfile
import zipfile
import gtfs_kit as gk # type: ignore

from app.gtfs_import_service.gtfs_import_service import GTFSImportService
from app.rebuild_routing_service import RebuildRoutingDataService

logger = structlog.getLogger(__name__)


@celery_app.task(
    name="import_gtfs_static",
    bind=True,
    autoretry_for=(Exception,),  # Retry for any exception
    retry_kwargs={
        'max_retries': 5,
        'countdown': 60  # Initial delay of 60 seconds
    },
    retry_backoff=True,  # Enable exponential backoff
    retry_backoff_max=600,  # Maximum delay of 10 minutes
    retry_jitter=True,  # Add randomization to prevent thundering herd
)
def import_gtfs_static(self, file_path: str) -> dict:
    logger.info("Starting GTFS data import")
    db = next(get_db())
    logger.info(f"Reading file from", file_path=file_path)
    if Path(file_path).suffix == ".zip":
        logger.info("File is a zip archive, extracting contents for easier processing")
        temp_dir = tempfile.mkdtemp()
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
            logger.info(
                "Extracted zip archive contents",
                temp_dir=temp_dir,
            )
            final_file_path = temp_dir
    else:
        final_file_path = file_path
    logger.info(f"Reading file", final_file_path=final_file_path, exists=Path(final_file_path).exists())
    feed = gk.read_feed(final_file_path, dist_units="m")
    service = GTFSImportService(db)
    service.import_gtfs_static(feed=feed)
    logger.info("GTFS data import completed successfully")
    return {"status": "success", "message": "GTFS data imported successfully"}


@celery_app.task(
    name="rebuild_routing_data",
    bind=True,
)
def rebuild_routing_data(self) -> dict:
    logger.info("Starting routing data rebuild")
    db: Session = next(get_db())
    service = RebuildRoutingDataService(db)
    service.rebuild_routing_data()
    logger.info("Routing data rebuild completed successfully")
    return {"status": "success", "message": "Routing data rebuilt successfully"}