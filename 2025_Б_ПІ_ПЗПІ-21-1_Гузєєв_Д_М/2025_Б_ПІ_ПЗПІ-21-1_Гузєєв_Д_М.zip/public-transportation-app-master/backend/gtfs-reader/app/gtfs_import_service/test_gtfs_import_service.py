import pytest
import gtfs_kit as gk # type: ignore
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.db import engine
from app.gtfs_import_service.gtfs_import_service import GTFSImportService
from app.models import Base, Route


@pytest.fixture(scope="module")
def db_session():
    Base.metadata.create_all(engine)
    session = Session(bind=engine)
    try:
        yield session
    finally:
        session.rollback()
        session.close()
        Base.metadata.drop_all(engine)


@pytest.fixture
def gtfs_import_service(db_session):
    return GTFSImportService(db_session)


def test_gtfs_import_service_works_on_real_data(
    gtfs_import_service: GTFSImportService,
    db_session: Session,
):
    test_file = '/Users/guzeev/Documents/real_data_for_lviv'
    feed = gk.read_feed(test_file, dist_units="m")
    gtfs_import_service.import_gtfs_static(
        feed=feed,
    )
    conn = db_session.connection()
    routes = conn.execute(select(Route)).all() # type: ignore
    assert routes is not None
    assert len(routes) > 0