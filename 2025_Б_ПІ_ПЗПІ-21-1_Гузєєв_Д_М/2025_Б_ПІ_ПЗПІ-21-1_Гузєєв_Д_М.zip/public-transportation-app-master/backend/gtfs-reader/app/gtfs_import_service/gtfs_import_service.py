from enum import Enum, auto

from gtfs_kit import Feed, drop_invalid_columns, drop_zombies # type: ignore
from structlog import get_logger

import gtfs_kit as gk

logger = get_logger(__name__)

class GTFSImportServiceError(Exception):
    class Code(Enum):
        NO_DATA = auto()

    def __init__(self, code: Code, message: str):
        self.code = code
        self.message = message

    def __str__(self):
        return f"GTFSImportServiceError({self.code.value}: {self.message})"

class GTFSImportService:
    def __init__(self, db):
        self.db = db

    def import_gtfs_static(self, feed: Feed):
        # TODO: Calculate hash-sum for this file beforehand, and do not allow second imports
        drop_invalid_columns(feed)
        drop_zombies(feed)
        connection = self.db.connection()
        shapes = gk.get_shapes(as_gdf=True, feed=feed)
        if shapes is None or shapes.empty:
            raise GTFSImportServiceError(
                GTFSImportServiceError.Code.NO_DATA,
                "No shapes found",
            )
        routes = gk.get_routes(as_gdf=True, feed=feed)
        if routes is None or routes.empty:
            raise GTFSImportServiceError(
                GTFSImportServiceError.Code.NO_DATA,
                "No routes found",
            )
        stops = gk.get_stops(as_gdf=True, feed=feed)
        if stops is None or stops.empty:
            raise GTFSImportServiceError(
                GTFSImportServiceError.Code.NO_DATA,
                "No stops found",
            )
        stop_times = gk.get_stop_times(feed=feed)
        if stop_times is None or stop_times.empty:
            raise GTFSImportServiceError(
                GTFSImportServiceError.Code.NO_DATA,
                "No stop_times found",
            )
        trips = gk.get_trips(as_gdf=True, feed=feed)
        if trips is None or trips.empty:
            raise GTFSImportServiceError(
                GTFSImportServiceError.Code.NO_DATA,
                "No trips found",
            )
        logger.info(
            "Imported into memory",
            shapes_amount=len(shapes),
            routes_amount=len(routes),
            stops_amount=len(stops),
            stop_times_amount=len(stop_times),
            trips_amount=len(trips),
        )
        shapes.to_postgis(
            name="shapes",
            con=connection,
            if_exists="append",
            index=False,
            chunksize=1000,
        )
        feed.agency.to_sql(
            name="agencies",
            con=connection,
            if_exists="append",
            index=False,
            chunksize=1000,
        )
        feed.calendar.to_sql(
            name="calendar",
            con=connection,
            if_exists="append",
            index=False,
            chunksize=1000,
        )
        routes.to_postgis(
            name="routes",
            con=connection,
            if_exists="append",
            index=False,
            chunksize=1000,
        )
        stops.to_postgis(
            name="stops",
            con=connection,
            if_exists="append",
            index=False,
            chunksize=1000,
        )
        trips.to_postgis(
            name="trips",
            con=connection,
            if_exists="append",
            index=False,
            chunksize=1000,
        )
        stop_times.to_sql(
            name="stop_times",
            con=connection,
            if_exists="append",
            index=False,
            chunksize=1000,
        )
        connection.commit()
