import pytest
import gtfs_kit as gk # type: ignore
from sqlalchemy.orm import Session
from fastapi.testclient import TestClient

from app.db import engine
from app.main import app
from app.models import Base
from app.tasks import import_gtfs_static


@pytest.fixture(scope="module")
def db_session():
    Base.metadata.create_all(engine)
    session = Session(bind=engine)
    try:
        yield session
    finally:
        session.rollback()
        session.close()
        Base.metadata.drop_all(engine)

@pytest.fixture()
def client():
    return TestClient(app=app)

def test_import_admin(
    client: TestClient,
):
    response = client.get("/admin/import-gtfs-static")
    assert response.status_code == 200
    with open("/Users/guzeev/Documents/real_data_for_lviv.zip", "rb") as gtfs_data_file:
        response = client.post(
            "/admin/import-gtfs-static",
            files={'gtfs_file': gtfs_data_file},
        )
        assert response.status_code == 200

def test_import_task_works_with_folders(
    client: TestClient,
):
    import_gtfs_static(
        file_path="/Users/guzeev/Documents/real_data_for_lviv",
    )

def test_import_task_works_with_zip(
    client: TestClient,
):
    import_gtfs_static(
        file_path="/Users/guzeev/Documents/real_data_for_lviv.zip",
    )
