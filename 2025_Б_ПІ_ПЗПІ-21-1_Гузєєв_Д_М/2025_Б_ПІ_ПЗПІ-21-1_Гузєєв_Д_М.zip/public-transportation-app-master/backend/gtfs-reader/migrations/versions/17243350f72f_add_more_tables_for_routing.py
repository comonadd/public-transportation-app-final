"""add_more_tables_for_routing

Revision ID: 17243350f72f
Revises: f576f5690f52
Create Date: 2025-05-22 18:28:54.231576

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '17243350f72f'
down_revision: Union[str, None] = 'f576f5690f52'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
