"""add_is_active_field_to_stop

Revision ID: 36f732629d89
Revises: 17243350f72f
Create Date: 2025-05-22 18:32:24.192136

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '36f732629d89'
down_revision: Union[str, None] = '17243350f72f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
