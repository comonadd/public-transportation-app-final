import json
from datetime import time, datetime

import structlog
from aiokafka import AIOKafkaConsumer # type: ignore
from pydantic import BaseModel
from typing import Dict, Set
from fastapi import WebSocket
from app.config import KAFKA_BROKER, KAFKA_VEHICLE_UPDATES_TOPIC
from typing import Optional

logger = structlog.get_logger(__name__)

class VehicleResponse(BaseModel):
    vehicle_id: str
    trip_id: Optional[str] = None
    route_id: Optional[str] = None
    direction_id: Optional[int] = None
    start_time: Optional[time] = None
    start_date: Optional[str] = None
    schedule_relationship: Optional[int] = None
    current_stop_sequence: Optional[int] = None
    stop_id: Optional[str] = None
    current_status: Optional[int] = None
    timestamp: datetime
    congestion_level: Optional[int] = None
    occupancy_status: Optional[int] = None
    latitude: float
    longitude: float

    class Config:
        from_attributes = True


class KafkaManager:
    def __init__(self, on_message_callback):
        self.consumer = AIOKafkaConsumer(
            KAFKA_VEHICLE_UPDATES_TOPIC,
            bootstrap_servers=KAFKA_BROKER,
            value_deserializer=lambda m: json.loads(m.decode("utf-8")),
        )
        self.on_message_callback = on_message_callback

    async def start(self):
        await self.consumer.start()
        logger.info("Started Kafka consumer", topic=KAFKA_VEHICLE_UPDATES_TOPIC)
        try:
            async for msg in self.consumer:
                try:
                    data = VehicleResponse(**msg.value)
                    await self.on_message_callback(data)
                except Exception as e:
                    print(f"Invalid message format: {e}")
        finally:
            await self.consumer.stop()


class WebSocketManager:
    def __init__(self) -> None:
        self.active_connections: Dict[str, Set[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, route_id: str):
        await websocket.accept()
        self.active_connections.setdefault(route_id, set()).add(websocket)

    def disconnect(self, websocket: WebSocket):
        for connections in self.active_connections.values():
            connections.discard(websocket)

    def disconnect_all(self):
        for connections, websockets in self.active_connections.values():
            for websocket in websockets:
                connections.discard(websocket)

    async def broadcast(self, route_id: str, message: str):
        connections = self.active_connections.get(route_id, set())
        for connection in connections:
            try:
                await connection.send_text(message)
            except Exception:
                self.disconnect(connection)