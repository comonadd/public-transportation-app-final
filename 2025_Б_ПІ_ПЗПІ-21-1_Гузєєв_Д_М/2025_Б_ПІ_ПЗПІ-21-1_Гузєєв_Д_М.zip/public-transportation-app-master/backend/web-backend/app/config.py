import os

from dotenv import load_dotenv

load_dotenv()

KAFKA_BROKER = os.getenv("KAFKA_BROKER")
if KAFKA_BROKER is None:
    raise ValueError("KAFKA_BROKER is not set")

FRONTEND_URL = "http://localhost:3000"

DEFAULT_STOP_DISCOVERY_RADIUS_M = 10_000

KAFKA_VEHICLE_UPDATES_TOPIC = "vehicles"
