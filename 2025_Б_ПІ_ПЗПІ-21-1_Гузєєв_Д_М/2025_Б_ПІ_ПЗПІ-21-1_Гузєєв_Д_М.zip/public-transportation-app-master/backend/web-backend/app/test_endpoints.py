import pytest
from fastapi.testclient import TestClient
from sqlalchemy import Connection, text
from sqlmodel import SQLModel, create_engine, Session, StaticPool, insert

from app.db import engine
from .main import app, get_session
from app.models import Stop, Route


@pytest.fixture(name="session")
def session_fixture():
    with engine.begin() as conn:
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS public"))
        conn.execute(text("CREATE EXTENSION postgis"))

    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        yield session

    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))


@pytest.fixture()
def client():
    from app.main import app
    with TestClient(app) as client:
        yield client


def test_health_check(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}


def test_stops_in_radius(client, session: Session):
    def get_session_override():
        return session

    app.dependency_overrides[get_session] = get_session_override

    session.execute(insert(Stop).values(
        stop_id="1",
        stop_name="Test Stop",
        geometry="SRID=4326;POINT(-74.0060 40.7128)",
    ))
    session.commit()

    response = client.get("/stops-in-radius?lat=40.7128&lon=-74.0060&radius_m=1000")
    assert response.status_code == 200
    response_json = response.json()
    assert len(response_json) == 1
    first_stop = response_json[0]
    assert first_stop["stop_id"] == "1"
    assert first_stop["stop_name"] == "Test Stop"
    assert first_stop["geometry"]["coordinates"] == [-74.0060, 40.7128]


def test_stop_info(client, session: Session):
    def get_session_override():
        return session

    app.dependency_overrides[get_session] = get_session_override

    session.execute(insert(Stop).values(
        stop_id="1",
        stop_name="Test Stop",
        geometry="SRID=4326;POINT(-74.0060 40.7128)",
    ))

    session.execute(insert(Route).values(
        stop_id="1",
        stop_name="Test Stop",
        geometry="SRID=4326;POINT(-74.0060 40.7128)",
    ))

    session.commit()

    response = client.get("/stops-in-radius?lat=40.7128&lon=-74.0060&radius_m=1000")
    assert response.status_code == 200
    response_json = response.json()
    assert len(response_json) == 1