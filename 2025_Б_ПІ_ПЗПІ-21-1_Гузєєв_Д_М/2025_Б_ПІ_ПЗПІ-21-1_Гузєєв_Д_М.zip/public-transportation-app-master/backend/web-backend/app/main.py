import asyncio
from contextlib import asynccontextmanager
from typing import Annotated, cast, Any

import structlog
from geoalchemy2 import WKBElement
from pydantic import BaseModel
from starlette import status
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import JSONResponse
from starlette.websockets import WebSocket, WebSocketDisconnect

from app.admin import setup_admin_for_app
from app.config import FRONTEND_URL, DEFAULT_STOP_DISCOVERY_RADIUS_M
from app.db import engine, get_db
from fastapi import Depends, FastAPI, HTTPException
from sqlmodel import Session, select
from app.models import Stop, Route
from app.models.gtfs import serialize_line_string_geometry, Trip, StopTime
from app.path_builder_service import PathBuilderService
from app.types import StopId
from app.ws_vehicle_updates_service import WebSocketManager, VehicleResponse, KafkaManager

logger = structlog.get_logger(__name__)

path_builder_service = None
ws_manager: WebSocketManager | None = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    db = next(get_db())
    global path_builder_service
    path_builder_service = PathBuilderService(
        db=db,
    )
    path_builder_service.initialize()
    global ws_manager
    ws_manager = WebSocketManager()
    kafka = KafkaManager(handle_kafka_message)
    asyncio.create_task(kafka.start())
    yield
    ws_manager.disconnect_all()
    path_builder_service.clean()
    db.close()

def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]

app = FastAPI(title="Web Backend", lifespan=lifespan)

origins = [
    FRONTEND_URL,
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

setup_admin_for_app(app, engine)

@app.websocket("/ws/{route_id}")
async def websocket_endpoint(websocket: WebSocket, route_id: str):
    if not ws_manager:
        raise RuntimeError("WebSocketManager is not initialized")
    await ws_manager.connect(websocket, route_id)
    try:
        while True:
            await websocket.receive_text()  # Keep connection open
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

async def handle_kafka_message(vehicle_update: VehicleResponse):
    if not ws_manager:
        raise RuntimeError("WebSocketManager is not initialized")
    if vehicle_update.route_id:
        await ws_manager.broadcast(vehicle_update.route_id, vehicle_update.model_dump_json())

@app.get("/health")
async def health_check(db: Session = Depends(get_db)) -> dict[str, Any]:
    health_status: dict = {
        "status": "healthy",
        "service": "Web-backend",
        "checks": {}
    }

    overall_healthy = True

    try:
        db.execute(text("SELECT 1"))
        health_status["checks"]["database"] = {
            "status": "healthy",
            "message": "Database connection successful"
        }
    except Exception as e:
        overall_healthy = False
        health_status["checks"]["database"] = {
            "status": "unhealthy",
            "message": f"Database connection failed: {str(e)}"
        }
        logger.error("Database health check failed", error=str(e))

    if not overall_healthy:
        health_status["status"] = "unhealthy"
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=health_status
        )

    return health_status

@app.get("/stops-in-radius", response_class=JSONResponse)
async def stops_around_me(session: SessionDep, lat: float, lon: float, radius_m: int = DEFAULT_STOP_DISCOVERY_RADIUS_M):
    radius_degrees = radius_m / 111000.0
    point = f"SRID=4326;POINT({lon} {lat})"
    stmt = select(Stop).where(
        Stop.geometry.ST_DWithin( # type: ignore
            point,
            radius_degrees,
        )
    )
    stops = session.exec(stmt)
    return stops.fetchall()

@app.get("/route-geometry")
async def route_geometry(session: SessionDep, route_id: int):
    stmt = select(Route).where(  # type: ignore
        Route.route_id == str(route_id)
    )
    route = session.exec(stmt)
    matching_route = route.first()
    return serialize_line_string_geometry(cast(WKBElement, matching_route.geometry))


class RouteDetails(BaseModel):
    route_id: str
    route_long_name: str
    route_short_name: str
    start_stop: Stop | None = None
    end_stop: Stop | None = None

    class Config:
        orm_mode = True

@app.get("/route-details")
async def get_route_details(session: SessionDep, route_id: int):
    route_stmt: Any = select(Route).where(Route.route_id == str(route_id))
    route = session.exec(route_stmt).first()

    if not route:
        raise HTTPException(status_code=404, detail="Route not found")

    # Get all stops for this route, ordered by stop_sequence
    stops_stmt = (
        select(Stop, StopTime.stop_sequence) # type: ignore
        .join(StopTime, StopTime.stop_id == Stop.stop_id) # type: ignore
        .join(Trip, Trip.trip_id == StopTime.trip_id) # type: ignore
        .where(Trip.route_id == str(route_id)) # type: ignore
        .order_by(Stop.stop_id, StopTime.stop_sequence)  # Order by stop_id first for DISTINCT ON
        .distinct(Stop.stop_id)
    )

    # Execute and get results
    stops_results = session.exec(stops_stmt).all()

    # Sort by stop_sequence after getting unique stops
    stops_with_sequence = [(stop, sequence) for stop, sequence in stops_results]
    stops_with_sequence.sort(key=lambda x: x[1])  # Sort by stop_sequence
    stops = [stop for stop, _ in stops_with_sequence]

    return RouteDetails(
        route_id=route.route_id,
        route_long_name=route.route_long_name,
        route_short_name=route.route_short_name,
        start_stop=stops[0] if stops else None,
        end_stop=stops[-1] if stops else None,
    )

@app.get("/routes-for-stop")
async def routes_for_stop(session: SessionDep, stop_id: int):
    statement = (
        select(Route) # type: ignore
        .join(Trip, Trip.route_id == Route.route_id) # type: ignore
        .join(StopTime, StopTime.trip_id == Trip.trip_id) # type: ignore
        .where(StopTime.stop_id == str(stop_id)) # type: ignore
        .distinct()
    )

    routes = session.exec(statement).all()
    return routes

@app.get("/stops/{stop_id}")
async def stop_detail(session: SessionDep, stop_id: int):
    statement = select(Stop).where(Stop.stop_id == str(stop_id)) # type: ignore
    stop = session.exec(statement).first()
    return stop

class SearchResultItem(BaseModel):
    id: str
    name: str
    type: str
    route: Route | None = None
    stop: Stop | None = None
    distance_to_m: float | None = None  # Distance in meters, if applicable

    class Config:
        orm_mode = True

class SearchResponse(BaseModel):
    items: list[SearchResultItem]

from sqlalchemy import func, case


from sqlalchemy import text

@app.get("/search")
async def search(
        session: SessionDep,
        query: str,
        type: str | None = None,
        lat: float | None = None,
        lng: float | None = None
):
    user_location = None
    if lat is not None and lng is not None:
        user_location = (lng, lat)

    if user_location:
        sql_query = text("""
            (
                SELECT 
                    stop_id as id,
                    stop_name as name,
                    'stop' as type,
                    ST_Distance(
                        geometry::geography,
                        ST_SetSRID(ST_MakePoint(:lng, :lat), 4326)::geography
                    ) as distance_m,
                    stop_id, stop_name, stop_desc, geometry as stop_geometry,
                    NULL as route_id, NULL as route_long_name, NULL as route_short_name, NULL as route_geometry
                FROM stops 
                WHERE (:type IS NULL OR :type = 'stop')
                  AND (stop_name ILIKE :query OR stop_desc ILIKE :query)
            )
            UNION ALL
            (
                SELECT 
                    route_id as id,
                    route_long_name as name,
                    'route' as type,
                    ST_Distance(
                        geometry::geography,
                        ST_SetSRID(ST_MakePoint(:lng, :lat), 4326)::geography
                    ) as distance_m,
                    NULL as stop_id, NULL as stop_name, NULL as stop_desc, NULL as stop_geometry,
                    route_id, route_long_name, route_short_name, geometry as route_geometry
                FROM routes 
                WHERE (:type IS NULL OR :type = 'route')
                  AND (route_long_name ILIKE :query OR route_short_name ILIKE :query)
            )
            ORDER BY distance_m
        """)

        query_params = {
            "query": f"%{query}%",
            "type": type,
            "lat": user_location[1],
            "lng": user_location[0]
        }
    else:
        sql_query = text("""
            (
                SELECT 
                    stop_id as id,
                    stop_name as name,
                    'stop' as type,
                    NULL as distance_m,
                    stop_id, stop_name, stop_desc, geometry as stop_geometry,
                    NULL as route_id, NULL as route_long_name, NULL as route_short_name, NULL as route_geometry
                FROM stops 
                WHERE (:type IS NULL OR :type = 'stop')
                  AND (stop_name ILIKE :query OR stop_desc ILIKE :query)
            )
            UNION ALL
            (
                SELECT 
                    route_id as id,
                    route_long_name as name,
                    'route' as type,
                    NULL as distance_m,
                    NULL as stop_id, NULL as stop_name, NULL as stop_desc, NULL as stop_geometry,
                    route_id, route_long_name, route_short_name, geometry as route_geometry
                FROM routes 
                WHERE (:type IS NULL OR :type = 'route')
                  AND (route_long_name ILIKE :query OR route_short_name ILIKE :query)
            )
            ORDER BY name
        """)

        query_params = {
            "query": f"%{query}%",
            "type": type
        }

    result_rows = session.execute(sql_query, query_params).fetchall()

    results = []
    for row in result_rows:
        if row.type == "stop":
            # Create Stop object from row data
            stop = Stop(
                stop_id=row.stop_id,
                stop_name=row.stop_name,
                stop_desc=row.stop_desc,
                geometry=WKBElement(row.stop_geometry)
            )
            results.append(SearchResultItem(
                id=row.id,
                name=row.name,
                type="stop",
                stop=stop,
                distance_to_m=round(row.distance_m) if row.distance_m else None,
            ))
        else:  # route
            # Create Route object from row data
            route = Route(
                route_id=row.route_id,
                route_long_name=row.route_long_name,
                route_short_name=row.route_short_name,
                geometry=WKBElement(row.route_geometry),
            )
            results.append(SearchResultItem(
                id=row.id,
                name=row.name,
                type="route",
                route=route,
                distance_to_m=round(row.distance_m) if row.distance_m else None,
            ))

    return SearchResponse(items=results)


@app.get("/build-path")
async def build_path(session: SessionDep, point_a: StopId, point_b: StopId):
    result = PathBuilderService(db=session).build_path(
        point_a=point_a,
        point_b=point_b,
    )
    return result
