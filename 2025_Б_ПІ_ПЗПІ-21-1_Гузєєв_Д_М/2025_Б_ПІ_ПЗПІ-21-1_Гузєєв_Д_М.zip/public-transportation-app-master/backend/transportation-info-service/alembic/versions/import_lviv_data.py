"""import lviv data

Revision ID: import_lviv_data
Revises: update_models
Create Date: 2024-04-12 16:30:00.000000

"""

import csv
import os
from datetime import time
from typing import Optional, Sequence, Union

import sqlalchemy as sa
from sqlalchemy import column, table

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "import_lviv_data"
down_revision: Union[str, None] = "update_models"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def parse_time(time_str: str) -> Optional[time]:
    """Parse GTFS time string into time object."""
    if not time_str:
        return None

    # Handle times that may go beyond 24 hours
    hours, minutes, seconds = map(int, time_str.split(":"))
    hours = hours % 24  # Normalize hours to 0-23 range
    return time(hour=hours, minute=minutes, second=seconds)


def safe_float(value: str) -> Optional[float]:
    """Safely convert string to float, returning None for empty strings."""
    try:
        return float(value) if value.strip() else None
    except (ValueError, AttributeError):
        return None


def safe_int(value: str) -> Optional[int]:
    """Safely convert string to int, returning None for empty strings."""
    try:
        return int(value) if value.strip() else None
    except (ValueError, AttributeError):
        return None


def upgrade() -> None:
    # Define table objects for bulk insert
    agencies = table(
        "agencies",
        column("agency_id", sa.String),
        column("agency_name", sa.String),
        column("agency_url", sa.String),
        column("agency_timezone", sa.String),
        column("agency_lang", sa.String),
        column("agency_phone", sa.String),
        column("agency_fare_url", sa.String),
    )

    stops = table(
        "stops",
        column("stop_id", sa.String),
        column("stop_code", sa.String),
        column("stop_name", sa.String),
        column("stop_desc", sa.String),
        column("stop_lat", sa.Float),
        column("stop_lon", sa.Float),
        column("zone_id", sa.String),
        column("stop_url", sa.String),
        column("location_type", sa.Integer),
        column("parent_station", sa.String),
        column("stop_timezone", sa.String),
        column("wheelchair_boarding", sa.Integer),
    )

    routes = table(
        "routes",
        column("route_id", sa.String),
        column("agency_id", sa.String),
        column("route_short_name", sa.String),
        column("route_long_name", sa.String),
        column("route_desc", sa.String),
        column("route_type", sa.Integer),
        column("route_url", sa.String),
        column("route_color", sa.String),
        column("route_text_color", sa.String),
        column("route_sort_order", sa.Integer),
    )

    trips = table(
        "trips",
        column("trip_id", sa.String),
        column("route_id", sa.String),
        column("service_id", sa.String),
        column("trip_headsign", sa.String),
        column("trip_short_name", sa.String),
        column("direction_id", sa.Integer),
        column("block_id", sa.String),
        column("shape_id", sa.String),
        column("wheelchair_accessible", sa.Integer),
        column("bikes_allowed", sa.Integer),
    )

    stop_times = table(
        "stop_times",
        column("trip_id", sa.String),
        column("arrival_time", sa.Time),
        column("departure_time", sa.Time),
        column("stop_id", sa.String),
        column("stop_sequence", sa.Integer),
        column("stop_headsign", sa.String),
        column("pickup_type", sa.Integer),
        column("drop_off_type", sa.Integer),
        column("shape_dist_traveled", sa.Float),
        column("timepoint", sa.Integer),
    )

    data_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        "real_data_for_lviv",
    )

    # Import agencies
    with open(os.path.join(data_dir, "agency.txt"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        agencies_data = [dict(row) for row in reader]
        op.bulk_insert(agencies, agencies_data)

    # Import stops
    with open(os.path.join(data_dir, "stops.txt"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        stops_data = []
        for row in reader:
            # Convert string values to appropriate types
            if "stop_lat" in row:
                row["stop_lat"] = safe_float(row["stop_lat"])
            if "stop_lon" in row:
                row["stop_lon"] = safe_float(row["stop_lon"])
            if "location_type" in row:
                row["location_type"] = safe_int(row["location_type"])
            if "wheelchair_boarding" in row:
                row["wheelchair_boarding"] = safe_int(row["wheelchair_boarding"])
            stops_data.append(row)
        op.bulk_insert(stops, stops_data)

    # Import routes
    with open(os.path.join(data_dir, "routes.txt"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        routes_data = []
        for row in reader:
            if "route_type" in row:
                row["route_type"] = safe_int(row["route_type"])
            if "route_sort_order" in row:
                row["route_sort_order"] = safe_int(row["route_sort_order"])
            routes_data.append(row)
        op.bulk_insert(routes, routes_data)

    # Import trips
    with open(os.path.join(data_dir, "trips.txt"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        trips_data = []
        for row in reader:
            if "direction_id" in row:
                row["direction_id"] = safe_int(row["direction_id"])
            if "wheelchair_accessible" in row:
                row["wheelchair_accessible"] = safe_int(row["wheelchair_accessible"])
            if "bikes_allowed" in row:
                row["bikes_allowed"] = safe_int(row["bikes_allowed"])
            trips_data.append(row)
        op.bulk_insert(trips, trips_data)

    # Import stop times
    batch_size = 1000  # Process in batches to handle large file
    stop_times_data = []

    with open(os.path.join(data_dir, "stop_times.txt"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Convert string values to appropriate types
            if "arrival_time" in row:
                row["arrival_time"] = parse_time(row["arrival_time"])
            if "departure_time" in row:
                row["departure_time"] = parse_time(row["departure_time"])
            if "stop_sequence" in row:
                row["stop_sequence"] = safe_int(row["stop_sequence"])
            if "pickup_type" in row:
                row["pickup_type"] = safe_int(row["pickup_type"])
            if "drop_off_type" in row:
                row["drop_off_type"] = safe_int(row["drop_off_type"])
            if "shape_dist_traveled" in row:
                row["shape_dist_traveled"] = safe_float(row["shape_dist_traveled"])
            if "timepoint" in row:
                row["timepoint"] = safe_int(row["timepoint"])

            stop_times_data.append(row)

            # Insert in batches
            if len(stop_times_data) >= batch_size:
                op.bulk_insert(stop_times, stop_times_data)
                stop_times_data = []

        # Insert remaining records
        if stop_times_data:
            op.bulk_insert(stop_times, stop_times_data)


def downgrade() -> None:
    # Delete all data from tables in reverse order
    op.execute("DELETE FROM stop_times")
    op.execute("DELETE FROM trips")
    op.execute("DELETE FROM routes")
    op.execute("DELETE FROM stops")
    op.execute("DELETE FROM agencies")
