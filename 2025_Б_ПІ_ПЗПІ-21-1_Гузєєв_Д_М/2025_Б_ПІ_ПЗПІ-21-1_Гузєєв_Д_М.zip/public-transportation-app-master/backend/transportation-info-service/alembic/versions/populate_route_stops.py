"""populate route stops

Revision ID: populate_route_stops
Revises: import_lviv_data
Create Date: 2024-04-12 17:00:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "populate_route_stops"
down_revision: Union[str, None] = "import_lviv_data"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Get the connection
    conn = op.get_bind()

    # Create a temporary table to store unique route-stop combinations
    conn.execute(
        sa.text("""
        CREATE TEMPORARY TABLE temp_route_stops AS
        SELECT DISTINCT t.route_id, st.stop_id
        FROM stop_times st
        JOIN trips t ON st.trip_id = t.trip_id
    """)
    )

    # Insert the relationships into route_stop_association
    conn.execute(
        sa.text("""
        INSERT INTO route_stop_association (route_id, stop_id)
        SELECT route_id, stop_id
        FROM temp_route_stops
        WHERE NOT EXISTS (
            SELECT 1 FROM route_stop_association rsa
            WHERE rsa.route_id = temp_route_stops.route_id
            AND rsa.stop_id = temp_route_stops.stop_id
        )
    """)
    )

    # Drop the temporary table
    conn.execute(sa.text("DROP TABLE temp_route_stops"))


def downgrade() -> None:
    # Clear the route_stop_association table
    op.execute("DELETE FROM route_stop_association")
