"""import mock data

Revision ID: fb75f38e6a02
Revises: c0098d51a3d7
Create Date: 2024-04-12 14:00:00.000000

"""
import json
import sys
from pathlib import Path
from typing import Sequence, Union, Any

from sqlalchemy import text

from alembic import op

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

def load_json_data(file_name: str) -> dict[str, list[Any]]:
    """Load JSON data from a file in the mock_data directory."""
    mock_data_path = Path(__file__).parent.parent / "mock_data" / file_name
    with open(mock_data_path, "r") as f:
        return json.load(f)


def load_routes() -> list[dict[str, Any]]:
    """Load route data from routes.json."""
    return load_json_data("routes.json")["routes"]


def load_stops() -> list[dict[str, Any]]:
    """Load stop data from stops.json."""
    return load_json_data("stops.json")["stops"]


def load_vehicles() -> list[dict[str, Any]]:
    """Load vehicle data from vehicles.json."""
    return load_json_data("vehicles.json")["vehicles"]

# revision identifiers, used by Alembic.
revision: str = "fb75f38e6a02"
down_revision: Union[str, None] = "c0098d51a3d7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Get database connection
    conn = op.get_bind()

    # Import stops first (no foreign key dependencies)
    stops = load_stops()
    for stop in stops:
        conn.execute(
            text("""
                INSERT INTO stops (id, name, latitude, longitude)
                VALUES (:id, :name, :latitude, :longitude)
            """),
            {
                "id": stop["id"],
                "name": stop["name"],
                "latitude": stop["latitude"],
                "longitude": stop["longitude"],
            },
        )

    # Import routes
    routes = load_routes()
    for route in routes:
        # First insert the route
        conn.execute(
            text("""
                INSERT INTO routes (id, name)
                VALUES (:id, :name)
            """),
            {"id": route["id"], "name": route["name"]},
        )

        # Then create the route-stop associations
        for stop_id in route["stops"]:
            conn.execute(
                text("""
                    INSERT INTO route_stop_association (route_id, stop_id)
                    VALUES (:route_id, :stop_id)
                """),
                {"route_id": route["id"], "stop_id": stop_id},
            )

    # Import vehicles
    vehicles = load_vehicles()
    for vehicle in vehicles:
        conn.execute(
            text("""
                INSERT INTO vehicles (id, latitude, longitude, timestamp, route_id)
                VALUES (:id, :latitude, :longitude, :timestamp, :route_id)
            """),
            {
                "id": vehicle["id"],
                "latitude": vehicle["latitude"],
                "longitude": vehicle["longitude"],
                "timestamp": vehicle["timestamp"],
                "route_id": vehicle["route_id"],
            },
        )


def downgrade() -> None:
    # Get database connection
    conn = op.get_bind()

    # Delete data in reverse order of dependencies
    conn.execute(text("DELETE FROM vehicles"))
    conn.execute(text("DELETE FROM route_stop_association"))
    conn.execute(text("DELETE FROM routes"))
    conn.execute(text("DELETE FROM stops"))
