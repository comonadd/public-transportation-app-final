// Initialize the map
const map = L.map('map').setView([49.8397, 24.0297], 13); // Default to Lviv

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Store vehicle markers and route polylines
const vehicleMarkers = new Map();
const routePolylines = new Map();
const vehiclePositions = new Map();
const interpolationInterval = 100; // ms between interpolation steps
const interpolationSteps = 10; // number of steps between updates

// Route list pagination settings
const routesPerPage = 10;
let currentPage = 1;
let allRoutes = [];

// Connect to WebSocket server
const socket = io('http://localhost:3000', {
    withCredentials: true,
    transports: ['websocket']
});

// Initialize route list UI
function initializeRouteList() {
    const routeListContainer = document.createElement('div');
    routeListContainer.id = 'route-list-container';
    routeListContainer.className = 'route-list-container';
    
    const routeList = document.createElement('div');
    routeList.id = 'route-list';
    routeList.className = 'route-list';
    
    const paginationControls = document.createElement('div');
    paginationControls.id = 'pagination-controls';
    paginationControls.className = 'pagination-controls';
    
    routeListContainer.appendChild(routeList);
    routeListContainer.appendChild(paginationControls);
    document.body.appendChild(routeListContainer);
    
    // Add styles
    const style = document.createElement('style');
    style.textContent = `
        .route-list-container {
            position: absolute;
            top: 10px;
            right: 10px;
            background: white;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            max-height: 80vh;
            overflow-y: auto;
            z-index: 1000;
        }
        
        .route-list {
            margin-bottom: 10px;
        }
        
        .route-item {
            padding: 8px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
        }
        
        .route-item:hover {
            background-color: #f5f5f5;
        }
        
        .route-item.active {
            background-color: #e3f2fd;
        }
        
        .pagination-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px;
        }
        
        .pagination-button {
            padding: 5px 10px;
            margin: 0 5px;
            cursor: pointer;
            border: 1px solid #ddd;
            background: white;
            border-radius: 3px;
        }
        
        .pagination-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .page-info {
            font-size: 0.9em;
            color: #666;
        }
    `;
    document.head.appendChild(style);
}

// Render routes for current page
function renderRoutes() {
    const routeList = document.getElementById('route-list');
    const startIndex = (currentPage - 1) * routesPerPage;
    const endIndex = startIndex + routesPerPage;
    const currentRoutes = allRoutes.slice(startIndex, endIndex);
    
    routeList.innerHTML = '';
    
    currentRoutes.forEach(route => {
        const routeItem = document.createElement('div');
        routeItem.className = 'route-item';
        routeItem.innerHTML = `
            <div><strong>Route ${route.route_id}</strong></div>
            <div>${route.route_short_name || 'No name'}</div>
        `;
        
        routeItem.addEventListener('click', () => {
            // Remove active class from all items
            document.querySelectorAll('.route-item').forEach(item => {
                item.classList.remove('active');
            });
            // Add active class to clicked item
            routeItem.classList.add('active');
            
            // Request route details
            socket.emit('requestRouteTrips', route.route_id);
            socket.emit('requestTripStops', route.route_id);
            socket.emit('requestRouteVehicleUpdates', route.route_id);
        });
        
        routeList.appendChild(routeItem);
    });
    
    updatePaginationControls();
}

// Update pagination controls
function updatePaginationControls() {
    const paginationControls = document.getElementById('pagination-controls');
    const totalPages = Math.ceil(allRoutes.length / routesPerPage);
    
    paginationControls.innerHTML = `
        <button class="pagination-button" id="prev-page" ${currentPage === 1 ? 'disabled' : ''}>
            Previous
        </button>
        <span class="page-info">
            Page ${currentPage} of ${totalPages}
        </span>
        <button class="pagination-button" id="next-page" ${currentPage === totalPages ? 'disabled' : ''}>
            Next
        </button>
    `;
    
    // Add event listeners
    document.getElementById('prev-page').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderRoutes();
        }
    });
    
    document.getElementById('next-page').addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderRoutes();
        }
    });
}

// Handle route data
socket.on('routes', (routes) => {
    console.log({ routes })
    allRoutes = routes;
    renderRoutes();
});

socket.on('routeTrips', ({ routeId, trips }) => {
    console.log({ trips })
    const firstTrip = trips[0]
    socket.emit('requestTripShape', firstTrip.trip_id);
});

socket.on('tripShape', ({ tripId, shape }) => {
    const points = shape.map(p => [p.shape_pt_lat, p.shape_pt_lon])
    polyline = L.polyline(
        points,
        {
                    color: '#3388ff',
                    weight: 3,
                    opacity: 0.7
                }
    ).addTo(map);
    routePolylines.set(tripId, polyline);
    console.info('Route polylines created')
    polyline.bindPopup(`Route ${tripId}`);
    routePolylines.set(tripId, polyline);
})

// Handle route stops and shape data
socket.on('tripStops', ({ tripId, stops }) => {
    // Remove existing polyline if it exists
    if (routePolylines.has(tripId)) {
        routePolylines.get(tripId).remove();
        routePolylines.delete(routeId);
    }

    // Add stop markers
    stops.forEach(stop => {
        const marker = L.circleMarker(
            [stop.stop_lat, stop.stop_lon],
            {
                radius: 4,
                fillColor: '#ff0000',
                color: '#000',
                weight: 1,
                opacity: 1,
                fillOpacity: 0.8
            }
        ).addTo(map);

        marker.bindPopup(`
            <b>Stop:</b> ${stop.stop_name}<br>
            <b>ID:</b> ${stop.stop_id}
        `);
    });
});

// Helper function to interpolate between two points
function interpolatePoint(start, end, progress) {
    return [
        start[0] + (end[0] - start[0]) * progress,
        start[1] + (end[1] - start[1]) * progress
    ];
}

let vehiclePositionsState = {}

const hashString = (string) => string
  .split('')
  .map((char) => char.charCodeAt(0))
  .reduce((a, b) => a + b, 0)
  

const COLORS = [
    '#FF0000',
    '#00FF00',
    '#0000FF',
    '#FFFF00',
    '#FF00FF',
    '#00FFFF',
    '#FF00FF',
]

const stringToColor = (string) => COLORS[hashString(string) % COLORS.length];


// Handle vehicle position updates with interpolation
socket.on('routeVehicleUpdates', ({ routeId, positions }) => {
    positions.forEach(vehicle => {
        const vehicleId = vehicle.vehicle_id;
        const vehicleColor = stringToColor(vehicleId)
        const newPosition = [vehicle.latitude, vehicle.longitude];
        if (vehiclePositionsState[vehicleId] && (
            vehiclePositionsState[vehicleId][0] === newPosition[0] ||
            vehiclePositionsState[vehicleId][1] === newPosition[1]
        )) {
            // If the position is the same as the previous position, don't update the marker
            return;
        }
        console.info("vehicle position updated", {
            vehicleId,
            oldPosition: vehiclePositionsState[vehicleId],
            newPosition
        })
        vehiclePositionsState[vehicleId] = newPosition
        // If this is a new vehicle, create its marker
        if (vehicleMarkers.has(vehicleId)) {
            const marker = vehicleMarkers.get(vehicleId);
            vehiclePositions[vehicleId].target = newPosition
            vehiclePositions[vehicleId].progress = 0; 
            // marker.setLatLng(newPosition);
        } else {
            const marker = L.circleMarker(
                newPosition,
                {
                    radius: 10,
                    fillColor: vehicleColor,
                    color: '#000',
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 0.8
                }
            ).addTo(map);

            marker.bindPopup(`
                <b>Vehicle ID:</b> ${vehicle.vehicle_id}<br>
                <b>Route ID:</b> ${vehicle.route_id}<br>
                <b>Last Update:</b> ${new Date(vehicle.timestamp).toLocaleString()}
            `);

            vehicleMarkers.set(vehicleId, marker);
            vehiclePositions.set(vehicleId, {
                current: newPosition,
                target: newPosition,
                progress: 1
            });
        }
    });
});

// Set up interpolation animation
setInterval(() => {
    for (const [vehicleId, data] of vehiclePositions.entries()) {
        if (data.progress < 1) {
            data.progress = Math.min(1, data.progress + (1 / interpolationSteps));
            const interpolatedPosition = interpolatePoint(data.current, data.target, data.progress);
            
            // Update marker position
            const marker = vehicleMarkers.get(vehicleId);
            if (marker) {
                marker.setLatLng(interpolatedPosition);
            }
            
            // Update current position for next interpolation
            data.current = interpolatedPosition;
        }
    }
}, interpolationInterval);

// Initialize the app
initializeRouteList();
socket.emit('requestRoutes'); 