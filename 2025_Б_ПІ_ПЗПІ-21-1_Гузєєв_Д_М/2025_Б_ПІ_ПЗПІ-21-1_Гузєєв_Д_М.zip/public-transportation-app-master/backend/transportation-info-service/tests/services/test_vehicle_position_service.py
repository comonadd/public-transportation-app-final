from datetime import datetime, timedelta
from unittest.mock import Mock, patch

from pytest_cases import fixture, parametrize
from service.config import VEHICLE_STOP_DURATION_SECONDS
from service.models import Vehicle
from service.services.position_calculator import StopId, VehicleState

@fixture
def sample_vehicle():
    return Vehicle(
        vehicle_id="1",
        route_id="route1",
        latitude=0.0,
        longitude=0.0,
    )


@fixture
def sample_vehicle_state():
    return VehicleState(
        current_stop_id=StopId("stop1"),
        next_stop_id=StopId("stop2"),
        current_position=(0.0, 0.0),
        next_stop_position=(1.0, 1.0),
        start_time=datetime.now(),
        arrival_time=datetime.now() + timedelta(seconds=60),
        is_at_stop=True,
        stop_start_time=datetime.now(),
    )


@parametrize(
    "is_at_stop,stop_duration,expected_is_at_stop",
    [
        (True, VEHICLE_STOP_DURATION_SECONDS - 1, True),  # Still at stop
        (True, VEHICLE_STOP_DURATION_SECONDS + 1, False),  # Time to move
        (False, 0, False),  # Already moving
    ],
)
def test_advance_vehicle_state(
    vehicle_position_service,
    sample_vehicle,
    sample_vehicle_state,
    is_at_stop,
    stop_duration,
    expected_is_at_stop,
):
    # Setup
    current_time = datetime.now()
    sample_vehicle_state.is_at_stop = is_at_stop
    sample_vehicle_state.stop_start_time = current_time - timedelta(
        seconds=stop_duration
    )

    # Mock the stop service to return some stops
    mock_current_stop = Mock(stop_id="stop3", stop_lat=2.0, stop_lon=2.0)
    mock_next_stop = Mock(stop_id="stop4", stop_lat=3.0, stop_lon=3.0)
    with patch.object(
        vehicle_position_service.stop_service,
        "find_closest_stop",
        return_value=(mock_current_stop, mock_next_stop),
    ):
        # Mock the vehicle service update method
        with patch.object(
            vehicle_position_service.vehicle_service,
            "update_vehicle_position",
        ) as mock_update_position:
            # Act
            result = vehicle_position_service.advance_vehicle_state(
                sample_vehicle, sample_vehicle_state, current_time
            )

            # Assert
            assert result.is_at_stop == expected_is_at_stop

            if not is_at_stop or stop_duration >= VEHICLE_STOP_DURATION_SECONDS:
                # Should have updated vehicle position
                mock_update_position.assert_called_once()
            else:
                # Should not have updated vehicle position
                mock_update_position.assert_not_called()


def test_advance_vehicle_state_at_stop_transition(
    vehicle_position_service, sample_vehicle, sample_vehicle_state
):
    # Setup
    current_time = datetime.now()
    sample_vehicle_state.is_at_stop = True
    sample_vehicle_state.stop_start_time = current_time - timedelta(
        seconds=VEHICLE_STOP_DURATION_SECONDS + 1
    )

    # Mock the stop service to return some stops
    mock_current_stop = Mock(stop_id="stop3", stop_lat=2.0, stop_lon=2.0)
    mock_next_stop = Mock(stop_id="stop4", stop_lat=3.0, stop_lon=3.0)
    with patch.object(
        vehicle_position_service.stop_service,
        "find_closest_stop",
        return_value=(mock_current_stop, mock_next_stop),
    ):
        # Act
        result = vehicle_position_service.advance_vehicle_state(
            sample_vehicle, sample_vehicle_state, current_time
        )

        # Assert
        assert not result.is_at_stop
        assert result.current_stop_id == StopId("stop3")
        assert result.next_stop_id == StopId("stop4")
        assert result.next_stop_position == (3.0, 3.0)
        assert result.start_time == current_time
        assert result.stop_start_time is None
