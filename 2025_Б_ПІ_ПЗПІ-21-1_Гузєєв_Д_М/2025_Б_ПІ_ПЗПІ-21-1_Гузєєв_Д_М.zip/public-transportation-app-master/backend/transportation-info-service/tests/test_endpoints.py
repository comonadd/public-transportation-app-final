def test_get_stops(client):
    response = client.get("/api/v1/stops")
    assert response.status_code == 200


def test_get_stop(client):
    # First get all stops to get a valid stop_id
    stops_response = client.get("/api/v1/stops")
    assert stops_response.status_code == 200
    stops = stops_response.json()
    if stops:
        stop_id = stops[0]["stop_id"]
        response = client.get(f"/api/v1/stops/{stop_id}")
        assert response.status_code == 200


def test_get_routes(client):
    response = client.get("/api/v1/routes")
    assert response.status_code == 200


def test_get_route(client):
    # First get all routes to get a valid route_id
    routes_response = client.get("/api/v1/routes")
    assert routes_response.status_code == 200
    routes = routes_response.json()
    if routes:
        route_id = routes[0]["route_id"]
        response = client.get(f"/api/v1/routes/{route_id}")
        assert response.status_code == 200


def test_get_route_stops(client):
    # First get all routes to get a valid route_id
    routes_response = client.get("/api/v1/routes")
    assert routes_response.status_code == 200
    routes = routes_response.json()
    if routes:
        route_id = routes[0]["route_id"]
        response = client.get(f"/api/v1/routes/{route_id}/stops")
        assert response.status_code == 200


def test_get_route_trips(client):
    # First get all routes to get a valid route_id
    routes_response = client.get("/api/v1/routes")
    assert routes_response.status_code == 200
    routes = routes_response.json()
    if routes:
        route_id = routes[0]["route_id"]
        response = client.get(f"/api/v1/routes/{route_id}/trips")
        assert response.status_code == 200


def test_get_vehicles(client):
    response = client.get("/api/v1/vehicles")
    assert response.status_code == 200


def test_get_vehicle(client):
    # First get all vehicles to get a valid vehicle_id
    vehicles_response = client.get("/api/v1/vehicles")
    assert vehicles_response.status_code == 200
    vehicles = vehicles_response.json()
    if vehicles:
        vehicle_id = vehicles[0]["vehicle_id"]
        response = client.get(f"/api/v1/vehicles/{vehicle_id}")
        assert response.status_code == 200


def test_get_route_shape(client):
    # First get all routes to get a valid route_id
    routes_response = client.get("/api/v1/routes")
    assert routes_response.status_code == 200
    routes = routes_response.json()
    if routes:
        route_id = routes[0]["route_id"]
        response = client.get(f"/api/v1/routes/{route_id}/shape")
        assert response.status_code == 200


def test_get_trip_shape(client):
    # First get all trips to get a valid trip_id
    trips_response = client.get("/api/v1/trips")
    assert trips_response.status_code == 200
    trips = trips_response.json()
    if trips:
        trip_id = trips[0]["trip_id"]
        response = client.get(f"/api/v1/trips/{trip_id}/shape")
        assert response.status_code == 200


def test_get_trips(client):
    response = client.get("/api/v1/trips")
    assert response.status_code == 200


def test_get_trip(client):
    # First get all trips to get a valid trip_id
    trips_response = client.get("/api/v1/trips")
    assert trips_response.status_code == 200
    trips = trips_response.json()
    if trips:
        trip_id = trips[0]["trip_id"]
        response = client.get(f"/api/v1/trips/{trip_id}")
        assert response.status_code == 200


def test_get_stop_times(client):
    response = client.get("/api/v1/stop_times")
    assert response.status_code == 200


def test_get_stop_time(client):
    # First get all stop times to get a valid stop_time_id
    stop_times_response = client.get("/api/v1/stop_times")
    assert stop_times_response.status_code == 200
    stop_times_response.json()
