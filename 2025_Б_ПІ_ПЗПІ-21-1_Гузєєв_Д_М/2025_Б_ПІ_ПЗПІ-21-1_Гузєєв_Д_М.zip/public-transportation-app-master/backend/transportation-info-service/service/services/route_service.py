from service.models import Route
from sqlalchemy import select
from sqlalchemy.orm import Session
from structlog import get_logger

logger = get_logger(__name__)


class RouteService:
    def __init__(self, db: Session):
        self.db = db

    def get_route_by_id(self, route_id: str) -> Route | None:
        """Get a route by its ID."""
        return self.db.execute(
            select(Route).where(Route.route_id == route_id)
        ).scalar_one_or_none()

    def get_all_routes(self):
        """Get all routes from the database."""
        return self.db.execute(select(Route)).scalars().all()
