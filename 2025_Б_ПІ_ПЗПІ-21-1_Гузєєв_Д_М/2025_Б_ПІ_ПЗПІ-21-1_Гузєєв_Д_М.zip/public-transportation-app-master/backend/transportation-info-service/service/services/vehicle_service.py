from service.models import Vehicle
from sqlalchemy import select
from sqlalchemy.orm import Session
from structlog import get_logger

logger = get_logger(__name__)


class VehicleService:
    def __init__(self, db: Session):
        self.db = db

    def get_all_vehicles(self):
        """Get all vehicles from the database."""
        return self.db.execute(select(Vehicle)).scalars().all()

    def update_vehicle_position(
        self, vehicle: Vehicle, latitude: float, longitude: float
    ):
        """Update vehicle's position in the database."""
        vehicle.latitude = latitude
        vehicle.longitude = longitude
        self.db.commit()
