import math
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Tuple, NewType

StopId = NewType("StopId", str)

@dataclass
class VehicleState:
    current_position: Tuple[float, float]
    trip_shape_id: str
    trip_id: str
    dirty: bool = False

class PositionCalculator:
    @staticmethod
    def calculate_distance(
        lat1: float,
        lon1: float,
        lat2: float,
        lon2: float,
    ) -> float:
        """
        Calculate the distance between two points in kilometers using the Haversine formula.

        Args:
            lat1: Latitude of first point
            lon1: Longitude of first point
            lat2: Latitude of second point
            lon2: Longitude of second point

        Returns:
            Distance in kilometers
        """
        # Convert degrees to radians
        lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])

        # Haversine formula
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = (
            math.sin(dlat / 2) ** 2
            + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
        )
        c = 2 * math.asin(math.sqrt(a))
        r = 6371  # Radius of Earth in kilometers
        return c * r

    @staticmethod
    def calculate_position(
        start_lat: float,
        start_lon: float,
        end_lat: float,
        end_lon: float,
        progress: float,
    ) -> Tuple[float, float]:
        """
        Calculate position between two points based on progress (0 to 1).

        Args:
            start_lat: Starting latitude
            start_lon: Starting longitude
            end_lat: Ending latitude
            end_lon: Ending longitude
            progress: Progress from start to end (0 to 1)

        Returns:
            Tuple of (latitude, longitude) for the current position
        """
        current_lat = start_lat + (end_lat - start_lat) * progress
        current_lon = start_lon + (end_lon - start_lon) * progress
        return current_lat, current_lon

    @staticmethod
    def calculate_progress(start_time: datetime, arrival_time: datetime) -> float:
        """
        Calculate progress between two points based on time.

        Args:
            start_time: Time when the vehicle started moving
            arrival_time: Expected arrival time

        Returns:
            Progress value between 0 and 1
        """
        now = datetime.now()
        total_duration = (arrival_time - start_time).total_seconds()
        elapsed = (now - start_time).total_seconds()

        if total_duration <= 0:
            return 1.0

        progress = elapsed / total_duration
        return max(0.0, min(1.0, progress))
