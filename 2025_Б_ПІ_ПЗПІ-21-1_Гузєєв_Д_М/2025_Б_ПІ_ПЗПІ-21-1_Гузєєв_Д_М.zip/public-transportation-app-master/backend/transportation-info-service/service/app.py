from contextlib import asynccontextmanager
from typing import List

from fastapi import Depends, FastAPI, HTTPException
from service.admin import RouteAdmin, StopAdmin, TripAdmin, VehicleAdmin
from service.database import engine, get_db
from service.models import Route, ShapePoint, Stop, StopTime, Trip, Vehicle
from service.schemas import (
    RouteResponse,
    ShapePointResponse,
    StopResponse,
    StopTimeResponse,
    TripResponse,
    VehicleResponse,
)
from service.services.route_service import RouteService
from service.services.route_shape_service import RouteShapeService
from service.services.stop_service import StopService
from service.services.vehicle_position_service import VehiclePositionService
from service.services.vehicle_service import VehicleService
from sqladmin import Admin
from sqlalchemy import asc, text
from sqlalchemy.orm import Session
from structlog import get_logger

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    db = next(get_db())
    vehicle_service = VehicleService(db)
    stop_service = StopService(db)
    route_service = RouteService(db)
    route_shape_service = RouteShapeService(db)
    vehicle_position_service = VehiclePositionService(
        db, vehicle_service, stop_service, route_service, route_shape_service
    )
    vehicle_position_service.start()
    logger.info("Vehicle position service started")
    yield
    vehicle_position_service.stop()
    logger.info("Vehicle position service stopped")


app = FastAPI(
    title="Transportation Info Service",
    description="GTFS-compliant API for transportation information",
    version="1.0.0",
    lifespan=lifespan,
)
admin = Admin(app, engine)
admin.add_view(VehicleAdmin)
admin.add_view(RouteAdmin)
admin.add_view(StopAdmin)
admin.add_view(TripAdmin)


@app.get("/api/v1/stops", response_model=List[StopResponse])
async def get_stops(db: Session = Depends(get_db)):
    """Get all stops."""
    return db.query(Stop).all()


@app.get("/api/v1/stops/{stop_id}", response_model=StopResponse)
async def get_stop(stop_id: str, db: Session = Depends(get_db)):
    """Get a specific stop by ID."""
    stop = db.query(Stop).filter(Stop.stop_id == stop_id).first()
    if not stop:
        raise HTTPException(status_code=404, detail="Stop not found")
    return stop


@app.get("/api/v1/routes", response_model=List[RouteResponse])
def get_routes(db: Session = Depends(get_db)):
    routes = db.query(Route).all()
    return routes


@app.get("/api/v1/routes/{route_id}", response_model=RouteResponse)
def get_route(route_id: str, db: Session = Depends(get_db)):
    route = db.query(Route).filter(Route.route_id == route_id).first()
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")
    return route


@app.get("/api/v1/routes/{route_id}/stops", response_model=List[StopResponse])
def get_route_stops(route_id: str, db: Session = Depends(get_db)):
    route = db.query(Route).filter(Route.route_id == route_id).first()
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")
    return route.stops


@app.get("/api/v1/trips/{trip_id}/stops", response_model=List[StopResponse])
def get_trip_stops(trip_id: str, db: Session = Depends(get_db)):
    stops = (
        db.query(Stop).filter(Stop.stop_times.any(StopTime.trip_id == trip_id)).all()
    )
    if not stops:
        raise HTTPException(status_code=404, detail="Route not found")
    return stops


@app.get("/api/v1/routes/{route_id}/trips", response_model=List[TripResponse])
def get_route_trips(route_id: str, db: Session = Depends(get_db)):
    route = db.query(Route).filter(Route.route_id == route_id).first()
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")
    return route.trips


@app.get("/api/v1/vehicles", response_model=List[VehicleResponse])
def get_vehicles(db: Session = Depends(get_db)):
    vehicles = db.query(Vehicle).all()
    return vehicles


@app.get("/api/v1/vehicles/{vehicle_id}", response_model=VehicleResponse)
def get_vehicle(vehicle_id: str, db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter(Vehicle.vehicle_id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehicle not found")
    return vehicle


@app.get(
    "/api/v1/routes/{route_id}/shape", response_model=List[List[ShapePointResponse]]
)
def get_route_shape(route_id: str, db: Session = Depends(get_db)):
    # Check if route exists
    route = db.query(Route).filter(Route.route_id == route_id).first()
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")

    # Get all unique shape points for this route's trips
    # Need to group by trip_id here
    sql = text("""
        SELECT 
            shape_points.*,
            trips.trip_id
        FROM 
            shape_points
        JOIN 
            trips ON trips.shape_id = shape_points.shape_id
        WHERE 
            trips.route_id = :route_id
        ORDER BY 
            trips.trip_id,
            shape_points.shape_pt_sequence ASC
    """)
    shape_points = db.execute(sql, {"route_id": route_id}).fetchall()

    if not shape_points:
        raise HTTPException(
            status_code=404, detail="No shape points found for this route"
        )

    # Option 1: Query ShapePoints and attach trip_id to each object
    shape_points_with_trips = (
        db.query(ShapePoint, Trip.trip_id)
        .join(Trip, Trip.shape_id == ShapePoint.shape_id)
        .filter(Trip.route_id == route_id)
        .order_by(Trip.trip_id, asc(ShapePoint.shape_pt_sequence))
        .all()
    )

    # Convert to flat array by attaching trip_id to each ShapePoint
    shape_points_by_trip_id: list[list[ShapePoint]] = []
    current_subarray = None
    current_trip_id = None
    logger.info(
        "shape_points_with_trips",
        shape_points_with_trips_length=len(shape_points_with_trips),
    )
    for shape_point, trip_id in shape_points_with_trips:
        if current_trip_id is None:
            current_trip_id = trip_id
            current_subarray = []
            shape_points_by_trip_id.append(current_subarray)
        current_subarray.append(shape_point)  # type: ignore

    logger.info("done", shape_points_by_trip_id_length=len(shape_points_by_trip_id))

    return shape_points_by_trip_id


@app.get("/api/v1/trips/{trip_id}/shape", response_model=List[ShapePointResponse])
def get_trip_shape(trip_id: str, db: Session = Depends(get_db)):
    # Check if route exists
    trip = db.query(Trip).filter(Trip.trip_id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")

    # Get all unique shape points for this route's trips
    # limit to
    shape_points = (
        db.query(ShapePoint)
        .join(Trip, Trip.shape_id == ShapePoint.shape_id)
        .filter(Trip.trip_id == trip_id)
        .order_by(asc(ShapePoint.shape_pt_sequence))
        .all()
    )

    if not shape_points:
        raise HTTPException(
            status_code=404, detail="No shape points found for this trip"
        )

    return shape_points


@app.get("/api/v1/trips", response_model=List[TripResponse])
async def get_trips(db: Session = Depends(get_db)):
    """Get all trips."""
    return db.query(Trip).all()


@app.get("/api/v1/trips/{trip_id}", response_model=TripResponse)
async def get_trip(trip_id: str, db: Session = Depends(get_db)):
    """Get a specific trip by ID."""
    trip = db.query(Trip).filter(Trip.trip_id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    return trip


@app.get("/api/v1/stop_times", response_model=List[StopTimeResponse])
async def get_stop_times(db: Session = Depends(get_db)):
    """Get all stop times."""
    return db.query(StopTime).all()


@app.get("/api/v1/vehicles-for-route/{route_id}", response_model=List[VehicleResponse])
async def get_vehicles_for_route(route_id: str, db: Session = Depends(get_db)):
    """Get all vehicles for a route."""
    return db.query(Vehicle).filter(Vehicle.route_id == route_id).all()
