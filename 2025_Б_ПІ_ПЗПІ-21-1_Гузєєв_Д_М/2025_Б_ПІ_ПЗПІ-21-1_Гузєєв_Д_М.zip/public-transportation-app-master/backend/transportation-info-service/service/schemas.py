from datetime import datetime, time
from typing import Optional

from pydantic import BaseModel


class ShapePointResponse(BaseModel):
    id: int
    shape_id: str
    shape_pt_lat: float
    shape_pt_lon: float
    shape_pt_sequence: int
    shape_dist_traveled: Optional[float] = None
    trip_id: Optional[str] = None

    class Config:
        from_attributes = True


class RouteResponse(BaseModel):
    route_id: str
    agency_id: Optional[str] = None
    route_short_name: Optional[str] = None
    route_long_name: Optional[str] = None
    route_desc: Optional[str] = None
    route_type: int
    route_url: Optional[str] = None
    route_color: Optional[str] = None
    route_text_color: Optional[str] = None
    route_sort_order: Optional[int] = None

    class Config:
        from_attributes = True


class StopResponse(BaseModel):
    stop_id: str
    stop_code: Optional[str] = None
    stop_name: str
    stop_desc: Optional[str] = None
    stop_lat: float
    stop_lon: float
    zone_id: Optional[str] = None
    stop_url: Optional[str] = None
    location_type: Optional[int] = None
    parent_station: Optional[str] = None
    stop_timezone: Optional[str] = None
    wheelchair_boarding: Optional[int] = None

    class Config:
        from_attributes = True


class TripResponse(BaseModel):
    trip_id: str
    route_id: str
    service_id: str
    trip_headsign: Optional[str] = None
    trip_short_name: Optional[str] = None
    direction_id: Optional[int] = None
    block_id: Optional[str] = None
    shape_id: Optional[str] = None
    wheelchair_accessible: Optional[int] = None
    bikes_allowed: Optional[int] = None

    class Config:
        from_attributes = True


class StopTimeResponse(BaseModel):
    trip_id: str
    arrival_time: Optional[time] = None
    departure_time: Optional[time] = None
    stop_id: str
    stop_sequence: int


class VehicleResponse(BaseModel):
    vehicle_id: str
    trip_id: Optional[str] = None
    route_id: Optional[str] = None
    direction_id: Optional[int] = None
    start_time: Optional[time] = None
    start_date: Optional[str] = None
    schedule_relationship: Optional[int] = None
    current_stop_sequence: Optional[int] = None
    stop_id: Optional[str] = None
    current_status: Optional[int] = None
    timestamp: datetime
    congestion_level: Optional[int] = None
    occupancy_status: Optional[int] = None
    latitude: float
    longitude: float

    class Config:
        from_attributes = True
