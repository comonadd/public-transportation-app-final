import { Stop } from "@/types";
import { useRoutesForStop } from "../hooks/useRoutesForStop";
import { useMapContext } from "../mapContext";
import ForkRightIcon from "@mui/icons-material/ForkRight";
import { CloseButton } from "./CloseButton";
import { useFavoriteStops } from "../hooks/useFavoriteStops";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import FavoriteIcon from "@mui/icons-material/Favorite";

export const StopDropdown: React.FC<{ stop: Stop }> = ({ stop }) => {
  const { data: routes } = useRoutesForStop(stop);
  const context = useMapContext();
  const { toggleFavorite, isFavorite } = useFavoriteStops();
  const isThisFavorite = isFavorite(stop.stop_id);

  return (
    <div className="card bg-base-100 shadow-md" style={{ overflowY: "auto" }}>
      <CloseButton onClick={() => context.setSelectedStop(null)} />
      <div className="card-body w-full py-4 px-0">
        <div className="flex flex-col justify-between pb-4 px-4 gap-2">
          <div className="mr-8 mb-2">
            <h5 className="text-grey text-sm mb-1">Зупинка</h5>
            <h2 className="card-title p-0">{stop?.stop_desc}</h2>
          </div>
          <div className="flex px-0 py-0 flex-row gap-2">
            <button
              className="btn py-0 box-content btn-soft btn-secondary btn-m"
              title={
                isThisFavorite ? "Видалити з обраних" : "Додати до обраних"
              }
              onClick={() => {
                toggleFavorite({
                  stop_id: stop.stop_id,
                  stop_name: stop.stop_name,
                  stop_desc: stop.stop_desc,
                });
              }}
            >
              {isThisFavorite ? (
                <FavoriteIcon className="inline-block align-middle" />
              ) : (
                <FavoriteBorderIcon className="inline-block align-middle" />
              )}
            </button>
            <button
              className="btn py-0 box-content btn-soft btn-primary btn-m"
              onClick={() => {
                context.setPointA(stop);
                context.setSelectedStop(null);
              }}
            >
              Напрямки від
            </button>
            <button
              className="btn py-0 box-content btn-soft btn-secondary btn-m"
              onClick={() => {
                context.setPointB(stop);
                context.setSelectedStop(null);
              }}
            >
              Напрямки до
            </button>
          </div>
        </div>
        <label className="block text-sm font-bold text-gray-700 mb-2 px-4">
          Напрямки, що проходять через цю зупинку
        </label>
        <div
          className="list bg-base-100 rounded-box w-full p-0"
          style={{ maxHeight: "300px", overflowY: "auto" }}
        >
          {routes?.map((route) => (
            <div
              key={route.route_id}
              onClick={() => context.setSelectedRoute(route)}
              className="list-row text-left w-full py-2 px-0 hover:bg-gray-100 rounded-none cursor-pointer"
            >
              <button
                className="w-full text-left pointer-events-none p-0 flex flex-row items-center justify-between"
                onClick={() => {
                  context.setSelectedRoute(route);
                }}
              >
                <div className="px-4">
                  <ForkRightIcon
                    className="inline-block align-middle"
                    style={{ fontSize: "1.2rem" }}
                  />
                </div>
                {route.route_long_name}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
