import { Stop } from "@/types";
import { useMapContext } from "../mapContext";

export const StopMarker: React.FC<{ stop: Stop }> = (props) => {
  const ctx = useMapContext();
  return (
    <>
      <div
        onClick={() => {
          ctx.setSelectedStop(props.stop);
        }}
      >
        {props.stop.stop_name}
      </div>
    </>
  );
};
