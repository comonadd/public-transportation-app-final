import { useThrottle } from "@uidotdev/usehooks";
import { useState } from "react";
import { useSearch } from "../hooks/useSearch";
import { useCurrentUserLocation } from "../hooks/useCurrentUserLocation";
import { PathBuilderHistory } from "./PathBuilderHistory";
import { SearchResultItem } from "./SearchResultItem";

export const SearchBar = () => {
  const [searchText, setSearchText] = useState<string>("");
  const searchTextThrottled = useThrottle(searchText, 500);
  const location = useCurrentUserLocation();
  const { data: searchResults } = useSearch({
    query: searchTextThrottled,
    type: null,
    coords: location,
  });

  return (
    <div className="dropdown w-full">
      <input
        role="button"
        type="text"
        placeholder="Search..."
        className="input w-full"
        onChange={(e) => {
          setSearchText(e.target.value);
        }}
      ></input>
      {Boolean(searchResults?.items) ? (
        <ul
          tabIndex={0}
          className="dropdown-content menu bg-base-100 z-1 w-full p-0 px-0 shadow-sm overflow-y-auto overflow-x-hidden max-h-64"
          style={{
            overflowX: "hidden",
            flexWrap: "nowrap",
            overflowWrap: "normal",
          }}
        >
          {searchResults?.items?.length === 0 && (
            <li
              key="no-results"
              className="px-0 cursor-pointer w-full flex flex-row items-center px-4 text-gray-500"
              style={{ height: "40px" }}
            >
              Нічого не знайдено
            </li>
          )}
          {searchResults?.items?.map((result) => {
            return <SearchResultItem result={result} key={result.id} />;
          })}
        </ul>
      ) : (
        <div
          tabIndex={0}
          className="dropdown-content menu bg-base-100 z-1 w-full p-0 px-0 shadow-sm overflow-y-auto overflow-x-hidden max-h-64"
        >
          <PathBuilderHistory />
        </div>
      )}
    </div>
  );
};
