import { useEffect, useState } from "react";

interface MapTooltipProps {
  content: string;
  x: number;
  y: number;
}

export const MapTooltip = ({ content, x, y }: MapTooltipProps) => {
  const [position, setPosition] = useState({ x, y });

  useEffect(() => {
    setPosition({ x, y });
  }, [x, y]);

  if (!content) return null;

  return (
    <div
      style={{
        position: "absolute",
        left: position.x + 10,
        top: position.y + 10,
        backgroundColor: "white",
        padding: "8px 12px",
        borderRadius: "4px",
        boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
        zIndex: 1000,
        fontSize: "14px",
        maxWidth: "200px",
        pointerEvents: "none",
      }}
    >
      {content}
    </div>
  );
};
