import { useVehicleUpdatesOnMapForRoute } from "../hooks/useVehicleUpdatesOnMapForRoute";
import { MapTooltip } from "./MapTooltip";
import { useMapContext } from "../mapContext";

export const MovingVehiclesOnMap = () => {
  const ctx = useMapContext();
  const { tooltip: tooltipForVehicle } = useVehicleUpdatesOnMapForRoute(
    ctx.selectedRoute,
    ctx.map
  );
  if (!tooltipForVehicle) {
    return null;
  }
  return <MapTooltip {...tooltipForVehicle} />;
};
