import { Path } from "@/types";
import { EdgeType } from "../hooks/useBuildPath";
import { builtPathColorForPart, focusOnRoutePart } from "../helpers";
import { useMapContext } from "../mapContext";

export interface Props {
  path: Path;
}

const textForEdgeType = (edgeType: EdgeType | null): string => {
  switch (edgeType) {
    case EdgeType.WALK:
      return "Пішки";
    case EdgeType.TRANSIT:
      return "Громадський транспорт";
    case EdgeType.TRANSFER:
      return "Трансфер";
    default:
      return "Кінець маршруту";
  }
};

export const PathDetails: React.FC<Props> = ({ path }) => {
  const { map } = useMapContext();
  return (
    <div
      className="card bg-base-100 shadow-md rounded-none"
      style={{ overflowY: "auto" }}
    >
      <div className="card-body w-full p-0 rounded-none">
        <div
          className="list bg-base-100 rounded-none w-full p-0"
          style={{ maxHeight: "400px", overflowY: "auto" }}
        >
          {path.routeParts?.map((part) => {
            const color = builtPathColorForPart(part);
            return (
              <div
                key={part.seq}
                className="list-row text-left w-full py-2 px-4 hover:bg-gray-300 rounded-none cursor-pointer flex flex-col gap-2"
                onClick={() => {
                  if (!map) {
                    return;
                  }
                  focusOnRoutePart(part, map);
                }}
              >
                <div className="flex flex-row gap-2 items-center">
                  <span
                    style={{
                      backgroundColor: color,
                      borderRadius: "100%",
                      width: "10px",
                      height: "10px",
                    }}
                  />
                  <span className="text-xs mr-0 text-nowrap">{`${part.seq}.`}</span>
                  <span className="text-xs">
                    {part.instruction
                      ? part.instruction
                      : textForEdgeType(part.edge_type)}
                  </span>
                </div>
                <div className="flex flex-col gap-1">
                  <span>{part.stop.stop_name}</span>
                  <span className="text-xs text-gray-500">
                    {part.edge_type === EdgeType.TRANSIT && (
                      <span className="text-gray-500">
                        {part.route_long_name || "Невідомий маршрут"}
                      </span>
                    )}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
