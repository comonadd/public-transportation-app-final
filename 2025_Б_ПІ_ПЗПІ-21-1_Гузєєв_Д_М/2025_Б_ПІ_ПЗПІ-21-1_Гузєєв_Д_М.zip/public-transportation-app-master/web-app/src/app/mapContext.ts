"use client";

import Map from "ol/Map";
import { PartialStop, Path, Route, Stop } from "@/types";
import React, { useContext } from "react";

interface IMapContext {
  selectedRoute: Route | null;
  setSelectedRoute: (route: Route | null) => void;
  selectedStop: Stop | null;
  setSelectedStop: (stop: Stop | null) => void;
  pointA: Stop | null;
  pointB: Stop | null;
  setPointA: (stop: PartialStop | null) => void;
  setPointB: (stop: PartialStop | null) => void;
  setSelectedBuiltPath: (path: Path | null) => void;
  selectedBuiltPath: Path | null;
  map: Map | null;
  setMap: (map: Map | null) => void;
}

export const MapContext = React.createContext<IMapContext>(
  {} as unknown as IMapContext
);

export const useMapContext = () => {
  return useContext(MapContext);
};
