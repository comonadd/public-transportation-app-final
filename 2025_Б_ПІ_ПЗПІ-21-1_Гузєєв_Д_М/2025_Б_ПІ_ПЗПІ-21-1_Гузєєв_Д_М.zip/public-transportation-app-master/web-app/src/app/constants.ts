export const ROUTE_COLOR_ON_MAP = "#3388ff"; // Green
export const ROUTE_WIDTH_ON_MAP = 4; // Width of the route line on the map
export const ROUTE_Z_INDEX_ON_MAP = 10;

export const STOP_COLOR = "#3388ff";
export const STOP_OUTLINE_COLOR = "#ffffff";
export const STOP_RADIUS_ON_MAP = 8;

export const STOPS_LAYER_Z_INDEX_ON_MAP = 20;

export const AVAILABLE_BUILT_PATH_ROUTE_COLORS = [
  "#3388ff", // Blue
  "#cc33ff", // Purple
  "#ff3333", // Red
  "#ff33cc", // Magenta
];

export const BUILT_PATH_ROUTE_LAYER_NAME = "builtPathRouteLayer";
export const BUILT_PATH_STOP_LAYER_NAME = "builtPathStopsLayer";

export const VEHICLE_Z_INDEX_ON_MAP = 30;
