import { Coords } from "@/types";
import { fromLonLat } from "ol/proj";
import { Map } from "ol";
import { useEffect } from "react";

export const useLocationZoomForMap = (
  map: Map | null,
  location: Coords | null
) => {
  useEffect(() => {
    if (!map || !location) {
      return;
    }
    const userCoordinate = location
      ? fromLonLat([location.lon, location.lat])
      : null;
    if (!userCoordinate) {
      return;
    }
    map.getView().setCenter(userCoordinate);
    const latitude = location.lat;
    const mapSize = map.getSize();
    if (!mapSize) {
      console.error("Map size is not available");
      return;
    }
    const resolution =
      (4000 / mapSize[0]) * Math.cos((latitude * Math.PI) / 180);
    map.getView().setResolution(resolution);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, location?.lon, location?.lat]);
};
