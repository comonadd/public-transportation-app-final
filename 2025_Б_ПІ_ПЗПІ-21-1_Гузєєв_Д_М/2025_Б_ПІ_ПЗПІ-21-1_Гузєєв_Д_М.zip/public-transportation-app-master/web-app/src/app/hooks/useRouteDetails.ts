import { useQuery } from "@tanstack/react-query";
import { API } from "../api";

export const useRouteDetails = (routeId: string | null) => {
  return useQuery({
    queryKey: ["routeDetails", routeId],
    queryFn: async () => {
      if (!routeId) return null;
      const response = await API.get(`/route-details?route_id=${routeId}`);
      return response.data;
    },
    enabled: Boolean(routeId),
  });
};
