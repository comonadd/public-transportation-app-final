import { toLonLat } from "ol/proj";
import { useState, useEffect, useMemo } from "react";
import { useMapContext } from "../mapContext";

export const useMapCenter = () => {
  const ctx = useMapContext();
  const [mapCenterRaw, setMapCenterRaw] = useState(() =>
    ctx.map ? ctx.map.getView().getCenter() : null
  );

  useEffect(() => {
    if (!ctx.map) return;

    const view = ctx.map.getView();

    const updateCenter = () => {
      setMapCenterRaw(view.getCenter());
    };

    view.on("change:center", updateCenter);
    ctx.map.on("moveend", updateCenter);

    updateCenter();

    return () => {
      view.un("change:center", updateCenter);
      if (ctx.map) {
        ctx.map.un("moveend", updateCenter);
      }
    };
  }, [ctx.map]);

  const mapCenterCoords = useMemo(
    () => toLonLat(mapCenterRaw || [0, 0]),
    [mapCenterRaw]
  );

  const result = useMemo(
    () =>
      mapCenterCoords
        ? { lat: mapCenterCoords[1], lon: mapCenterCoords[0] }
        : null,
    [mapCenterCoords]
  );

  return result;
};
