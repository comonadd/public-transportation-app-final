"use client";

import { useEffect, useRef, useState } from "react";
import { VehicleResponse } from "@/types";

export const useVehicleWebSocket = (routeId: string | null) => {
  const [vehicles, setVehicles] = useState<VehicleResponse[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!routeId) return;

    const ws = new WebSocket(`ws://localhost:8002/ws/${routeId}`);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      try {
        const data: VehicleResponse = JSON.parse(event.data);
        setVehicles((prev) => {
          const updated = prev.filter((v) => v.vehicle_id !== data.vehicle_id);
          return [...updated, data];
        });
      } catch (err) {
        console.error("Failed to parse vehicle update:", err);
      }
    };

    return () => {
      ws.close();
    };
  }, [routeId]);

  return vehicles;
};
