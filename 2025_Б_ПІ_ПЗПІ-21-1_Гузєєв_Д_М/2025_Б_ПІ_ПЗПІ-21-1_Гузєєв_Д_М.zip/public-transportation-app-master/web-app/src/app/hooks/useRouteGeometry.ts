import { useQuery } from "@tanstack/react-query";
import { API } from "../api";
import { QUERY_KEYS } from "../queryKeys";
import { RouteGeometry, Route } from "@/types";
import { AxiosResponse } from "axios";

export const useRouteGeometry = (route: Route | null) => {
  return useQuery({
    queryKey: [QUERY_KEYS.ROUTE_GEOMETRY, route?.route_id],
    queryFn: async () => {
      if (!route) {
        throw new Error("Route is null");
      }
      const response = await API.get<never, AxiosResponse<RouteGeometry>>(
        `/route-geometry?route_id=${route.route_id}`
      );
      return response.data;
    },
    enabled: !!route,
  });
};
