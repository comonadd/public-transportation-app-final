import { useLocalStorage } from "@uidotdev/usehooks";
import { useCallback } from "react";

export interface FavoriteStop {
  stop_id: string;
  stop_name: string;
  stop_desc: string;
}

interface UseFavoriteStopsResult {
  favorites: FavoriteStop[];
  addFavorite: (stop: FavoriteStop) => void;
  removeFavorite: (stopId: string) => void;
  isFavorite: (stopId: string) => boolean;
  toggleFavorite: (stop: FavoriteStop) => void;
}

const FAVORITE_STOPS_KEY = "favoriteStops";

export function useFavoriteStops(): UseFavoriteStopsResult {
  const [favorites, setFavorites] = useLocalStorage<FavoriteStop[]>(
    FAVORITE_STOPS_KEY,
    []
  );

  const addFavorite = useCallback(
    (stop: FavoriteStop) => {
      setFavorites((currentFavorites) => {
        const exists = currentFavorites.some(
          (favorite) => favorite.stop_id === stop.stop_id
        );

        if (!exists) {
          return [...currentFavorites, stop];
        }

        return currentFavorites;
      });
    },
    [setFavorites]
  );

  const removeFavorite = useCallback(
    (stopId: string) => {
      setFavorites((currentFavorites) =>
        currentFavorites.filter((favorite) => favorite.stop_id !== stopId)
      );
    },
    [setFavorites]
  );

  const isFavorite = useCallback(
    (stopId: string) => {
      return favorites.some((favorite) => favorite.stop_id === stopId);
    },
    [favorites]
  );

  const toggleFavorite = useCallback(
    (stop: FavoriteStop) => {
      if (isFavorite(stop.stop_id)) {
        removeFavorite(stop.stop_id);
      } else {
        addFavorite(stop);
      }
    },
    [isFavorite, removeFavorite, addFavorite]
  );

  return {
    favorites,
    addFavorite,
    removeFavorite,
    isFavorite,
    toggleFavorite,
  };
}
