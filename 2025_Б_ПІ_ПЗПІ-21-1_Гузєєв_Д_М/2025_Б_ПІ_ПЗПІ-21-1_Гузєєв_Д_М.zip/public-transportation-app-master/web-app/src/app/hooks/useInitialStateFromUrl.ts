import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useMapContext } from "../mapContext";
import { useQuery } from "@tanstack/react-query";
import { API } from "../api";
import { Stop, Route } from "@/types";
import { fromLonLat } from "ol/proj";

export const useInitialStateFromUrl = () => {
  const searchParams = useSearchParams();
  const ctx = useMapContext();
  const [loadedInitialLocationState, setLoadedInitialState] = useState(false);

  const stopId = searchParams.get("stop");
  const { data: stopData } = useQuery({
    queryKey: ["stop", stopId],
    queryFn: async () => {
      if (!stopId) return null;
      const response = await API.get<Stop>(`/stops/${stopId}`);
      return response.data;
    },
    enabled: Boolean(stopId),
  });

  const routeId = searchParams.get("route");
  const { data: routeData } = useQuery({
    queryKey: ["route", routeId],
    queryFn: async () => {
      if (!routeId) return null;
      const response = await API.get<Route>(`/route-details?route_id=${routeId}`);
      return response.data;
    },
    enabled: Boolean(routeId),
  });

  // Get map center and zoom from URL if available
  const lat = searchParams.get("lat");
  const lon = searchParams.get("lon");
  const zoom = searchParams.get("zoom");

  useEffect(() => {
    if (stopData) {
      ctx.setSelectedStop(stopData);
    }
    if (routeData) {
      ctx.setSelectedRoute(routeData);
    }
    if (lat && lon && ctx.map) {
        if (loadedInitialLocationState) {
        return;
    }
      const view = ctx.map.getView();
      const center = fromLonLat([parseFloat(lon), parseFloat(lat)]);
      view.setCenter(center);
      
      if (zoom) {
        view.setZoom(parseFloat(zoom));
      } else if (stopData || routeData) {
        view.setZoom(15);
      } else {
        view.setZoom(13);
      }

      setLoadedInitialState(true);
    }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stopData, routeData, lat, lon, zoom, ctx.map, loadedInitialLocationState]);
}; 