import { Stop } from "@/types";
import { useQuery } from "@tanstack/react-query";
import { API } from "../api";
import { QUERY_KEYS } from "../queryKeys";
import { Route } from "@/types";


export const useRoutesForStop = (stop: Stop) => {
    return useQuery<Route[]>({
        queryKey: [QUERY_KEYS.ROUTES_FOR_STOP, stop?.stop_id],
        queryFn: async () => {
            const response = await API.get<never, Route[]>(`/routes-for-stop?stop_id=${stop.stop_id}`);
            return response.data;
        },
        enabled: !!stop,
    });
}