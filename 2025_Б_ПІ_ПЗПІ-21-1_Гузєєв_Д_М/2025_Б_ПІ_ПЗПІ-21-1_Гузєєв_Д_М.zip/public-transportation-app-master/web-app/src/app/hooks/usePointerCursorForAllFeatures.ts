import { useEffect } from "react";
import { Map } from "ol";

export const usePointerCursorForAllFeatures = (map: Map | null) => {
  useEffect(() => {
    if (!map) return;

    map.on("pointermove", function (evt) {
      // @ts-ignore
      const hit = this.forEachFeatureAtPixel(
        evt.pixel,
        // @ts-ignore
        function (feature, layer) {
          return true;
        }
      );
      if (hit) {
        // @ts-ignore
        this.getTargetElement().style.cursor = "pointer";
      } else {
        // @ts-ignore
        this.getTargetElement().style.cursor = "";
      }
    });
  }, [map]);
};
