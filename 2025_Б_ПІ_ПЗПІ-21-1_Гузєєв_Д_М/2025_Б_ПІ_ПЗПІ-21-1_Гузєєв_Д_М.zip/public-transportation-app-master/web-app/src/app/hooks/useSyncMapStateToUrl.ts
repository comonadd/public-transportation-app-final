import { useMapContext } from "../mapContext";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { toLonLat } from "ol/proj";
import { useThrottle } from "@uidotdev/usehooks";

export const useSyncMapStateToUrl = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const ctx = useMapContext();

  // Get current map center and zoom
  const mapCenterRaw = ctx.map?.getView().getCenter();
  const mapZoom = ctx.map?.getView().getZoom();
  const mapCenterCoords = mapCenterRaw ? toLonLat(mapCenterRaw) : null;
  const mapCenter = useThrottle(
    mapCenterCoords ? { lat: mapCenterCoords[1], lon: mapCenterCoords[0] } : null,
    1000
  );
  const throttledZoom = useThrottle(mapZoom, 1000);

  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());

    // Update stop parameter
    if (ctx.selectedStop) {
      params.set("stop", ctx.selectedStop.stop_id);
    } else {
      params.delete("stop");
    }

    // Update route parameter
    if (ctx.selectedRoute) {
      params.set("route", ctx.selectedRoute.route_id);
    } else {
      params.delete("route");
    }

    // Update map center parameters
    if (mapCenter) {
      params.set("lat", mapCenter.lat.toString());
      params.set("lon", mapCenter.lon.toString());
    } else {
      params.delete("lat");
      params.delete("lon");
    }

    // Update zoom parameter
    if (throttledZoom !== undefined) {
      params.set("zoom", throttledZoom.toString());
    } else {
      params.delete("zoom");
    }

    // Only update URL if there are actual changes
    const newUrl = params.toString();
    if (newUrl !== searchParams.toString()) {
      router.replace(`?${newUrl}`, { scroll: false });
    }
  }, [ctx.selectedStop, ctx.selectedRoute, mapCenter, throttledZoom, router, searchParams]);
}; 