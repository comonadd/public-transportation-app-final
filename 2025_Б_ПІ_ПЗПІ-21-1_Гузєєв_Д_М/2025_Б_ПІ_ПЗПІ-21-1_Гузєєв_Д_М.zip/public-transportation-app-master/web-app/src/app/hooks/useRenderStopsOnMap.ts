import { Path, Stop, TooltipState } from "@/types";
import { Feature } from "ol";
import { click, pointerMove } from "ol/events/condition";
import { Point } from "ol/geom";
import { Select } from "ol/interaction";
import VectorLayer from "ol/layer/Vector";
import { fromLonLat } from "ol/proj";
import VectorSource from "ol/source/Vector";
import Icon from "ol/style/Icon";
import { useEffect, useRef, useState } from "react";
import { Map } from "ol";
import { STOPS_LAYER_Z_INDEX_ON_MAP } from "../constants";
import busSvg from "../bus.svg";
import Style from "ol/style/Style";
import { Fill, Stroke } from "ol/style";
import CircleStyle from "ol/style/Circle";
import { useMapContext } from "../mapContext";
import { useFavoriteStops } from "./useFavoriteStops";
import favoriteStopIcon from "../favorite-stop-icon.svg";

const isStopVisibleInScreen = (map: Map, stop: Stop): boolean => {
  const coordinates = fromLonLat([
    stop.geometry.coordinates[0],
    stop.geometry.coordinates[1],
  ]);
  const pixel = map.getPixelFromCoordinate(coordinates);
  const isInScreen =
    pixel &&
    pixel[0] >= 0 &&
    pixel[1] >= 0 &&
    pixel[0] < window.innerWidth &&
    pixel[1] < window.innerHeight;
  return isInScreen;
};

const shouldFilterBySector = (
  sectorsFilled: Record<number, Record<number, boolean>>,
  stop: Stop,
  map: Map
): boolean => {
  const currentZoom = map.getView().getZoom();

  let SECTOR_WIDTH_M = 500;
  if (currentZoom === undefined) {
    SECTOR_WIDTH_M = 0;
  } else if (currentZoom < 14) {
    SECTOR_WIDTH_M = 3000;
  } else if (currentZoom < 14.5) {
    SECTOR_WIDTH_M = 1000;
  } else if (currentZoom < 15) {
    SECTOR_WIDTH_M = 1000;
  } else if (currentZoom < 15.5) {
    SECTOR_WIDTH_M = 500;
  } else if (currentZoom < 16) {
    SECTOR_WIDTH_M = 10;
  } else {
    SECTOR_WIDTH_M = 0;
  }
  const SECTOR_HEIGHT_M = SECTOR_WIDTH_M;

  const coordinates = fromLonLat([
    stop.geometry.coordinates[0],
    stop.geometry.coordinates[1],
  ]);
  const stopSectorX =
    SECTOR_WIDTH_M <= 0
      ? coordinates[0]
      : Math.floor(coordinates[0] / SECTOR_WIDTH_M);
  const stopSectorY =
    SECTOR_HEIGHT_M <= 0
      ? coordinates[1]
      : Math.floor(coordinates[1] / SECTOR_HEIGHT_M);
  const doesSectorAlreadyHaveStop = sectorsFilled?.[stopSectorY]?.[stopSectorX];
  if (doesSectorAlreadyHaveStop) {
    return true;
  }
  if (!sectorsFilled[stopSectorY]) {
    sectorsFilled[stopSectorY] = {};
  }
  sectorsFilled[stopSectorY][stopSectorX] = true;
  return false;
};

export const useRenderStopsOnMap = (
  map: Map | null,
  stopsAround: Stop[] | undefined,
  selectedStop: Stop | null,
  setSelectedStop: (stop: Stop | null) => void,
  selectedBuiltPath: Path | null
) => {
  const stopsLayerRef = useRef<VectorLayer<VectorSource> | null>(null);
  const selectInteractionRef = useRef<Select | null>(null);
  const hoverInteractionRef = useRef<Select | null>(null);
  const [tooltip, setTooltip] = useState<TooltipState | null>(null);
  const context = useMapContext();
  const { isFavorite } = useFavoriteStops();

  useEffect(() => {
    if (!map) return;

    const stopsSource = new VectorSource();

    const stopStyle = [
      // Background circle
      new Style({
        image: new CircleStyle({
          radius: 12, // Adjust size as needed
          fill: new Fill({ color: "white" }),
          stroke: new Stroke({ color: "grey", width: 1 }),
        }),
      }),
      // SVG icon on top
      new Style({
        image: new Icon({
          src: busSvg.src,
          scale: 0.015,
          anchor: [0.5, 0.5],
        }),
      }),
    ];

    const stopsLayer = new VectorLayer({
      source: stopsSource,
      style: stopStyle,
      zIndex: STOPS_LAYER_Z_INDEX_ON_MAP,
    });
    stopsLayer.set("name", "stopsLayer");

    const select = new Select({
      condition: click,
      layers: [stopsLayer],
    });

    const hover = new Select({
      condition: pointerMove,
      layers: [stopsLayer],
      style: null,
    });

    select.on("select", (e) => {
      if (e.selected.length > 0) {
        const selectedFeature = e.selected[0];
        const stopData = selectedFeature.get("stopData");
        context.setSelectedRoute(null);
        setSelectedStop(stopData);
      } else {
        setSelectedStop(null);
      }
    });

    hover.on("select", (e) => {
      const target = map.getTargetElement();
      if (e.selected.length > 0) {
        const feature = e.selected[0];
        const stopName = feature.get("name");
        const pixel = map.getEventPixel(e.mapBrowserEvent.originalEvent);
        target.style.cursor = "pointer";
        setTooltip({ content: stopName, x: pixel[0], y: pixel[1] });
      } else {
        target.style.cursor = "";
        setTooltip(null);
      }
    });

    map.addLayer(stopsLayer);
    map.addInteraction(select);
    map.addInteraction(hover);
    stopsLayerRef.current = stopsLayer;
    selectInteractionRef.current = select;
    hoverInteractionRef.current = hover;

    return () => {
      if (stopsLayerRef.current) {
        map.removeLayer(stopsLayerRef.current);
        stopsLayerRef.current = null;
      }
      if (selectInteractionRef.current) {
        map.removeInteraction(selectInteractionRef.current);
        selectInteractionRef.current = null;
      }
      if (hoverInteractionRef.current) {
        map.removeInteraction(hoverInteractionRef.current);
        hoverInteractionRef.current = null;
      }
    };
  }, [map, setSelectedStop]);

  useEffect(() => {
    if (!map) return;
    if (!stopsLayerRef.current || !stopsAround) return;

    const stopsSource = stopsLayerRef.current.getSource();
    if (!stopsSource) return;

    stopsSource.clear();

    if (stopsAround.length === 0) {
      return;
    }

    const sectorsFilled: Record<number, Record<number, boolean>> = {};

    const stopFeatures = stopsAround
      .map((stop) => {
        const isFavoriteStop = isFavorite(stop.stop_id);
        if (!isFavoriteStop && !isStopVisibleInScreen(map, stop)) {
          return null;
        }
        const isThisSelectedStop = selectedStop?.stop_id === stop.stop_id;
        const isBuiltStop =
          selectedBuiltPath?.enter_stop.stop_id === stop.stop_id ||
          selectedBuiltPath?.exit_stop.stop_id === stop.stop_id ||
          selectedBuiltPath?.routeParts.some(
            (part) =>
              part.stop_id === stop.stop_id || part.stop_id === stop.stop_id
          );
        if (
          !isThisSelectedStop &&
          !isFavoriteStop &&
          !isBuiltStop &&
          shouldFilterBySector(sectorsFilled, stop, map)
        ) {
          return null;
        }
        const coordinates = fromLonLat([
          stop.geometry.coordinates[0],
          stop.geometry.coordinates[1],
        ]);
        const stopFeature = new Feature({
          geometry: new Point(coordinates),
          name: stop.stop_desc,
          stopId: stop.stop_id,
          stopData: stop,
        });
        stopFeature.setId(stop.stop_id);
        const isThisEnterStop =
          selectedBuiltPath?.enter_stop.stop_id === stop.stop_id;
        const isThisExitStop =
          selectedBuiltPath?.exit_stop.stop_id === stop.stop_id;
        if (isThisEnterStop) {
          const customStyle = new Style({
            image: new CircleStyle({
              radius: 10,
              fill: new Fill({ color: "green" }),
              stroke: new Stroke({ color: "white", width: 2 }),
            }),
          });

          stopFeature.setStyle(customStyle);
        } else if (isThisExitStop) {
          const customStyle = new Style({
            image: new CircleStyle({
              radius: 10,
              fill: new Fill({ color: "red" }),
              stroke: new Stroke({ color: "white", width: 2 }),
            }),
          });

          stopFeature.setStyle(customStyle);
        } else if (isThisSelectedStop || isBuiltStop) {
          const customStyle = new Style({
            image: new CircleStyle({
              radius: 10,
              fill: new Fill({ color: "blue" }),
              stroke: new Stroke({ color: "white", width: 2 }),
            }),
          });

          stopFeature.setStyle(customStyle);
        } else if (isFavorite(stop.stop_id)) {
          const favoriteStyle = new Style({
            image: new Icon({
              src: favoriteStopIcon.src,
              scale: 0.028,
              anchor: [0.5, 0.5],
            }),
          });
          stopFeature.setStyle(favoriteStyle);
        }
        return stopFeature;
      })
      .filter((feature) => feature !== null);

    stopsSource.addFeatures(stopFeatures);
  }, [stopsAround, selectedStop, selectedBuiltPath]);

  return { tooltip };
};
