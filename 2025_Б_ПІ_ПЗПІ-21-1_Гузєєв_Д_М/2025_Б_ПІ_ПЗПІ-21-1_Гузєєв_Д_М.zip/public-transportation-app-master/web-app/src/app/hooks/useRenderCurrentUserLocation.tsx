import { Coords } from "@/types";
import { Feature, Map } from "ol";
import { Point } from "ol/geom";
import VectorLayer from "ol/layer/Vector";
import { fromLonLat } from "ol/proj";
import VectorSource from "ol/source/Vector";
import { Style, Fill, Stroke } from "ol/style";
import CircleStyle from "ol/style/Circle";
import { useEffect, useRef } from "react";

export const useRenderCurrentUserLocation = (
  map: Map | null,
  location: Coords | null
) => {
  const animationRef = useRef<number | null>(null);
  const layerRef = useRef<VectorLayer<VectorSource> | null>(null);

  useEffect(() => {
    if (!map || !location) {
      return;
    }

    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }

    const existingLocationLayer = map
      .getLayers()
      .getArray()
      .find((layer) => layer.get("name") === "currentUserLocationLayer");
    if (existingLocationLayer) {
      map.removeLayer(existingLocationLayer);
    }

    const locationFeature = new Feature({
      geometry: new Point(fromLonLat([location.lon, location.lat])),
    });

    const createLocationStyles = (
      pulseRadius: number,
      pulseOpacity: number
    ) => [
      new Style({
        image: new CircleStyle({
          radius: pulseRadius,
          fill: new Fill({
            color: `rgba(59, 130, 246, ${pulseOpacity * 0.3})`,
          }),
          stroke: new Stroke({
            color: `rgba(59, 130, 246, ${pulseOpacity * 0.8})`,
            width: 1,
          }),
        }),
      }),
      new Style({
        image: new CircleStyle({
          radius: 12,
          fill: new Fill({ color: "rgba(59, 130, 246, 0.8)" }),
          stroke: new Stroke({ color: "white", width: 2 }),
        }),
      }),
      new Style({
        image: new CircleStyle({
          radius: 2,
          fill: new Fill({ color: "white" }),
        }),
      }),
    ];

    const locationSource = new VectorSource({
      features: [locationFeature],
    });

    const locationLayer = new VectorLayer({
      source: locationSource,
    });

    locationLayer.set("name", "currentUserLocationLayer");
    layerRef.current = locationLayer;
    map.addLayer(locationLayer);

    let start: number | null = null;
    const animate = (timestamp: number) => {
      if (!start) start = timestamp;
      const elapsed = timestamp - start;

      const cycle = (elapsed % 2000) / 2000;
      const pulse = Math.sin(cycle * Math.PI * 2) * 0.5 + 0.5;

      const minRadius = 12;
      const maxRadius = 25;
      const pulseRadius = minRadius + (maxRadius - minRadius) * pulse;
      const pulseOpacity = 1 - pulse * 0.7;

      if (layerRef.current) {
        layerRef.current.setStyle(
          createLocationStyles(pulseRadius, pulseOpacity)
        );
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      if (layerRef.current) {
        map.removeLayer(layerRef.current);
      }
    };
  }, [location?.lat, location?.lon, map]);
};
