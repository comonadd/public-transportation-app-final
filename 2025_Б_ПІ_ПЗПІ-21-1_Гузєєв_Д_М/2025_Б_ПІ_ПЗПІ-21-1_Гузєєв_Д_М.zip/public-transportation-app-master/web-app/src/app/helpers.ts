import { Coords, Stop } from "@/types";
import { RoutePart } from "./hooks/useBuildPath";
import { Feature, Map } from "ol";
import VectorLayer from "ol/layer/Vector";
import { BUILT_PATH_ROUTE_LAYER_NAME } from "./constants";

export const coordsFromGeometryPointType = (
  coordinates: [number, number]
): Coords => ({
  lon: coordinates[0],
  lat: coordinates[1],
});

export const builtPathColorForPart = (part: RoutePart) => {
  switch (part.edge_type) {
    case "walking":
      return "#00ff00"; // Green for walking
    case "transit":
      return "#0000ff"; // Blue for transit
    case "transfer":
      return "#ff0000"; // Red for transfer
    default:
      return "#000000"; // Default to black if unknown
  }
};

export const findAndRemoveLayer = (map: Map, layerId: string) => {
  const existingLayer = map
    .getLayers()
    .getArray()
    .find((layer) => layer.get("name") === layerId);
  if (existingLayer) {
    map.removeLayer(existingLayer);
  }
};

export const formatDistanceMeters = (meters: number | null) => {
  if (meters === null) return "";
  if (meters < 1000) {
    return `${meters} м`;
  } else {
    return `${(meters / 1000).toFixed(1)} км`;
  }
};

export const focusOnStop = (stop: Stop, map: Map) => {
  const stopsLayer = map
    .getLayers()
    .getArray()
    .find((layer) => layer.get("name") === "stopsLayer") as VectorLayer;

  if (!stopsLayer) {
    console.error("Stops layer not found");
    return;
  }

  if (!stop?.stop_id) {
    return;
  }
  const stopFeature = stopsLayer.getSource()?.getFeatureById(stop?.stop_id);

  if (!stopFeature) {
    console.error("Stop feature not found on the map");
    return;
  }

  const geometry = stopFeature.getGeometry();
  if (!geometry) {
    console.error("Stop geometry is undefined");
    return;
  }

  const stopExtent = geometry.getExtent();

  map.getView().fit(stopExtent, {
    padding: [50, 50, 50, 50],
    maxZoom: 16,
  });
};

export const focusRouteOnMap = (routeFeature: Feature, map: Map) => {
  const routeExtent = routeFeature.getGeometry()?.getExtent();
  if (!routeExtent) {
    console.error("Route extent is undefined");
    return;
  }
  map.getView().fit(routeExtent, {
    padding: [50, 50, 50, 50],
    maxZoom: 16,
  });
};

export const builtRoutePartFeatureId = (part: RoutePart) => {
  return `built-route-part-${part.edge_type}-${part.stop_id}`;
};

export const focusOnRoutePart = (routePart: RoutePart, map: Map) => {
  if (!routePart.geometry || !routePart.geometry.coordinates) {
    return;
  }

  const layer = map
    .getLayers()
    .getArray()
    .find(
      (layer) => layer.get("name") === BUILT_PATH_ROUTE_LAYER_NAME
    ) as VectorLayer;

  if (!layer) {
    return;
  }

  const feature = layer
    .getSource()
    ?.getFeatureById(builtRoutePartFeatureId(routePart));

  if (!feature) {
    return;
  }

  const geometry = feature.getGeometry();
  if (!geometry) {
    return;
  }

  const extent = geometry.getExtent();

  map.getView().fit(extent, {
    padding: [50, 50, 50, 50],
    maxZoom: 16,
  });
};
