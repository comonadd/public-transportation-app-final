import { RoutePart } from "./app/hooks/useBuildPath";

export interface Coords {
  lon: number;
  lat: number;
}

export type Geometry = string;

export interface PointGeometry {
  type: "Point";
  coordinates: [number, number];
}

export interface RouteGeometry {
  type: "LineString" | "MultiLineString";
  coordinates: [number, number][];
}

export interface Stop {
  stop_id: string;
  stop_name: string;
  stop_desc: string;
  geometry: PointGeometry;
}

export interface Route {
  route_name: string;
  route_id: string;
  geometry: Geometry;
  route_long_name: string;
}

export interface Path {
  routeParts: RoutePart[];
  enter_stop: Stop;
  exit_stop: Stop;
}

export interface VehicleResponse {
  vehicle_id: string;
  trip_id?: string;
  route_id?: string;
  direction_id?: number;
  start_time?: string;
  start_date?: string;
  schedule_relationship?: number;
  current_stop_sequence?: number;
  stop_id?: string;
  current_status?: number;
  timestamp: string;
  congestion_level?: number;
  occupancy_status?: number;
  latitude: number;
  longitude: number;
}

export interface TooltipState {
  content: string;
  x: number;
  y: number;
}

export interface PartialStop {
  stop_id: string;
  stop_name: string;
}
